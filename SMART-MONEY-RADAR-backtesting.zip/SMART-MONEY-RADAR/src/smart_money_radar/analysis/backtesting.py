"""Backtesting cronológico e offline; nunca envia ordens nem usa dados futuros na entrada."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Iterable, Sequence

from smart_money_radar.analysis.decision_engine import (
    DecisionCandidate, DecisionPolicy, DecisionStatus, EntryMode, evaluate_candidate,
)


@dataclass(frozen=True)
class MarketBar:
    token_mint: str
    timestamp: datetime
    price: Decimal

    def __post_init__(self) -> None:
        if not self.token_mint.strip():
            raise ValueError("token_mint obrigatório")
        if self.timestamp.tzinfo is None or self.timestamp.utcoffset() is None:
            raise ValueError("timestamp precisa conter fuso horário")
        if not self.price.is_finite() or self.price <= 0:
            raise ValueError("price deve ser positivo e finito")


@dataclass(frozen=True)
class BacktestConfig:
    initial_equity: Decimal = Decimal("1000")
    position_fraction: Decimal = Decimal("0.10")
    fee_rate: Decimal = Decimal("0.001")
    slippage_rate: Decimal = Decimal("0.002")
    holding_period: timedelta = timedelta(minutes=15)
    entry_mode: EntryMode = EntryMode.IMMEDIATE

    def __post_init__(self) -> None:
        if not self.initial_equity.is_finite() or self.initial_equity <= 0:
            raise ValueError("initial_equity deve ser positivo")
        if not self.position_fraction.is_finite() or not Decimal(0) < self.position_fraction <= Decimal(1):
            raise ValueError("position_fraction deve estar em (0, 1]")
        for name, value in (("fee_rate", self.fee_rate), ("slippage_rate", self.slippage_rate)):
            if not value.is_finite() or not Decimal(0) <= value < Decimal(1):
                raise ValueError(f"{name} deve estar em [0, 1)")
        if self.holding_period.total_seconds() <= 0:
            raise ValueError("holding_period precisa ser positivo")
        object.__setattr__(self, "entry_mode", EntryMode(self.entry_mode))


@dataclass(frozen=True)
class BacktestTrade:
    candidate_id: str
    token_mint: str
    entry_time: datetime
    exit_time: datetime
    entry_price: Decimal
    exit_price: Decimal
    position_quote: Decimal
    gross_return_pct: Decimal
    net_return_pct: Decimal
    pnl_quote: Decimal


@dataclass(frozen=True)
class BacktestReport:
    entry_mode: EntryMode
    initial_equity: Decimal
    final_equity: Decimal
    total_return_pct: Decimal
    max_drawdown_pct: Decimal
    trade_count: int
    wins: int
    losses: int
    win_rate_pct: Decimal
    unresolved_candidates: int
    blocked_candidates: int
    trades: tuple[BacktestTrade, ...]


def run_backtest(candidates: Iterable[DecisionCandidate], bars: Sequence[MarketBar], *,
                 config: BacktestConfig = BacktestConfig(),
                 policy: DecisionPolicy = DecisionPolicy()) -> BacktestReport:
    """Avalia sinais na sua hora e encerra cada posição na primeira barra após o horizonte.

    Cada candidato é uma oportunidade independente. A alocação é uma fração do
    patrimônio corrente; não há reinvestimento intrabar nem execução real.
    """
    ordered_bars = sorted(bars, key=lambda b: b.timestamp)
    if any(ordered_bars[i].timestamp > ordered_bars[i + 1].timestamp for i in range(len(ordered_bars) - 1)):
        raise ValueError("barras fora de ordem")
    by_mint: dict[str, list[MarketBar]] = {}
    for bar in ordered_bars:
        by_mint.setdefault(bar.token_mint, []).append(bar)

    ordered_candidates = sorted(candidates, key=lambda c: c.evaluated_at)
    equity = config.initial_equity
    peak = equity
    max_dd = Decimal(0)
    trades: list[BacktestTrade] = []
    unresolved = blocked = wins = 0

    for candidate in ordered_candidates:
        decision = evaluate_candidate(candidate, config.entry_mode, policy)
        if decision.status is not DecisionStatus.APPROVED_FOR_SIMULATION:
            blocked += 1
            continue
        future = next((b for b in by_mint.get(candidate.token_mint, ())
                       if b.timestamp >= candidate.evaluated_at + config.holding_period), None)
        if future is None:
            unresolved += 1
            continue
        entry = candidate.current_price * (Decimal(1) + config.slippage_rate)
        exit_price = future.price * (Decimal(1) - config.slippage_rate)
        allocation = equity * config.position_fraction
        gross = exit_price / entry - Decimal(1)
        # Fee charged on entry and exit notionals.
        net_factor = (exit_price / entry) * (Decimal(1) - config.fee_rate) ** 2
        net = net_factor - Decimal(1)
        pnl = allocation * net
        trade = BacktestTrade(candidate.candidate_id, candidate.token_mint,
                              candidate.evaluated_at, future.timestamp, entry, exit_price,
                              allocation, gross * 100, net * 100, pnl)
        trades.append(trade)
        equity += pnl
        if pnl > 0:
            wins += 1
        peak = max(peak, equity)
        drawdown = (peak - equity) / peak if peak else Decimal(0)
        max_dd = max(max_dd, drawdown)

    count = len(trades)
    total_return = (equity / config.initial_equity - 1) * 100
    win_rate = Decimal(wins) / count * 100 if count else Decimal(0)
    return BacktestReport(config.entry_mode, config.initial_equity, equity, total_return,
                          max_dd * 100, count, wins, count - wins, win_rate,
                          unresolved, blocked, tuple(trades))
