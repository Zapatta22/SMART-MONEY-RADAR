"""Detecção determinística de anomalias em séries de snapshots; somente leitura."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable

from smart_money_radar.data_sources.market_feed import MarketDataSnapshot


@dataclass(frozen=True)
class MarketAnomalyFinding:
    pool_address: str
    token_mint: str
    state: str
    reasons: tuple[str, ...]
    price_change_pct: Decimal | None
    volume_multiple: Decimal | None
    liquidity_change_pct: Decimal | None
    buy_sell_imbalance: Decimal | None
    samples: int


class MarketAnomalyDetector:
    """Compara o snapshot mais recente com histórico do mesmo pool.

    Volume é comparado ao snapshot anterior (não é volume incremental se o
    provedor reportar janela móvel). Por isso o sinal é apenas alerta de
    anomalia, nunca prova isolada de manipulação.
    """
    def __init__(self, *, max_abs_price_change_pct: Decimal = Decimal("0.50"),
                 max_volume_multiple: Decimal = Decimal("5"),
                 max_liquidity_drop_pct: Decimal = Decimal("0.30"),
                 max_trade_imbalance: Decimal = Decimal("0.90"),
                 minimum_samples: int = 2) -> None:
        values = (max_abs_price_change_pct, max_volume_multiple,
                  max_liquidity_drop_pct, max_trade_imbalance)
        if any(not v.is_finite() or v <= 0 for v in values):
            raise ValueError("Limites precisam ser positivos e finitos")
        if max_trade_imbalance > 1:
            raise ValueError("max_trade_imbalance deve ser <= 1")
        if minimum_samples < 2:
            raise ValueError("minimum_samples precisa ser >= 2")
        self.max_abs_price_change_pct = max_abs_price_change_pct
        self.max_volume_multiple = max_volume_multiple
        self.max_liquidity_drop_pct = max_liquidity_drop_pct
        self.max_trade_imbalance = max_trade_imbalance
        self.minimum_samples = minimum_samples

    def analyze(self, snapshots: Iterable[MarketDataSnapshot]) -> tuple[MarketAnomalyFinding, ...]:
        groups: dict[tuple[str, str], list[MarketDataSnapshot]] = {}
        for snap in snapshots:
            groups.setdefault((snap.pool_address, snap.token_mint), []).append(snap)
        findings = []
        for (pool, mint), rows in sorted(groups.items()):
            rows.sort(key=lambda x: x.observed_at)
            # Deduplica timestamps por fonte, preservando o último item recebido.
            dedup: dict[tuple[str, object], MarketDataSnapshot] = {}
            for row in rows:
                dedup[(row.source, row.observed_at)] = row
            rows = sorted(dedup.values(), key=lambda x: x.observed_at)
            latest = rows[-1]
            previous_rows = [r for r in rows[:-1] if r.source == latest.source]
            previous = previous_rows[-1] if previous_rows else (rows[-2] if len(rows) > 1 else None)
            reasons: list[str] = []
            price_change = volume_multiple = liquidity_change = imbalance = None
            if len(rows) < self.minimum_samples or previous is None:
                state = "inconclusivo"
                reasons.append("historico_insuficiente")
            else:
                price_change = (latest.price_quote - previous.price_quote) / previous.price_quote
                if abs(price_change) > self.max_abs_price_change_pct:
                    reasons.append("variacao_abrupta_de_preco")
                if latest.volume_24h_quote is not None and previous.volume_24h_quote is not None:
                    base = previous.volume_24h_quote
                    if base > 0:
                        volume_multiple = latest.volume_24h_quote / base
                        if volume_multiple > self.max_volume_multiple:
                            reasons.append("pico_anormal_de_volume")
                    elif latest.volume_24h_quote > 0:
                        volume_multiple = Decimal("Infinity")
                        reasons.append("pico_anormal_de_volume")
                if latest.liquidity_quote is not None and previous.liquidity_quote is not None and previous.liquidity_quote > 0:
                    liquidity_change = (latest.liquidity_quote - previous.liquidity_quote) / previous.liquidity_quote
                    if liquidity_change < -self.max_liquidity_drop_pct:
                        reasons.append("queda_brusca_de_liquidez")
                if latest.buys_24h is not None and latest.sells_24h is not None:
                    total = latest.buys_24h + latest.sells_24h
                    if total:
                        imbalance = abs(Decimal(latest.buys_24h - latest.sells_24h)) / Decimal(total)
                        if imbalance > self.max_trade_imbalance:
                            reasons.append("desequilibrio_extremo_de_negociacoes")
                state = "anomalia" if reasons else "normal"
            findings.append(MarketAnomalyFinding(pool, mint, state, tuple(reasons),
                price_change, volume_multiple, liquidity_change, imbalance, len(rows)))
        return tuple(findings)

    @staticmethod
    def blocked_token_mints(findings: Iterable[MarketAnomalyFinding]) -> frozenset[str]:
        return frozenset(f.token_mint for f in findings if f.state == "anomalia")
