"""Auditoria determinística de consistência entre fontes de mercado; somente leitura."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable

from smart_money_radar.data_sources.market_feed import MarketDataSnapshot


@dataclass(frozen=True)
class MarketIntegrityFinding:
    pool_address: str
    token_mint: str
    quote_mint: str
    state: str
    sources: tuple[str, ...]
    price_deviation_pct: Decimal | None
    liquidity_deviation_pct: Decimal | None
    reasons: tuple[str, ...]


class MarketDataIntegrityAnalyzer:
    """Compara snapshots equivalentes de fontes independentes.

    Divergência é calculada contra a mediana das fontes. O analisador não altera
    snapshots, não descarta dados silenciosamente e não executa ordens.
    """
    def __init__(self, *, max_price_deviation_pct: Decimal = Decimal("0.05"),
                 max_liquidity_deviation_pct: Decimal = Decimal("0.50"),
                 minimum_sources: int = 2) -> None:
        if not max_price_deviation_pct.is_finite() or max_price_deviation_pct <= 0:
            raise ValueError("max_price_deviation_pct precisa ser positivo e finito")
        if not max_liquidity_deviation_pct.is_finite() or max_liquidity_deviation_pct <= 0:
            raise ValueError("max_liquidity_deviation_pct precisa ser positivo e finito")
        if minimum_sources < 2:
            raise ValueError("minimum_sources precisa ser >= 2")
        self.max_price_deviation_pct = max_price_deviation_pct
        self.max_liquidity_deviation_pct = max_liquidity_deviation_pct
        self.minimum_sources = minimum_sources

    @staticmethod
    def _deviation(value: Decimal, reference: Decimal) -> Decimal:
        if reference == 0:
            return Decimal(0) if value == 0 else Decimal("Infinity")
        return abs(value - reference) / abs(reference)

    def analyze(self, snapshots: Iterable[MarketDataSnapshot]) -> tuple[MarketIntegrityFinding, ...]:
        groups: dict[tuple[str, str, str], dict[str, MarketDataSnapshot]] = {}
        for item in snapshots:
            key = (item.pool_address, item.token_mint, item.quote_mint)
            previous = groups.setdefault(key, {}).get(item.source)
            if previous is None or item.observed_at > previous.observed_at:
                groups[key][item.source] = item

        findings: list[MarketIntegrityFinding] = []
        for (pool, mint, quote), by_source in sorted(groups.items()):
            rows = tuple(by_source.values())
            reasons: list[str] = []
            price_dev: Decimal | None = None
            liquidity_dev: Decimal | None = None
            if len(rows) < self.minimum_sources:
                reasons.append("fontes_independentes_insuficientes")
            else:
                prices = sorted(row.price_quote for row in rows)
                middle = len(prices) // 2
                median_price = prices[middle] if len(prices) % 2 else (prices[middle - 1] + prices[middle]) / 2
                price_dev = max(self._deviation(row.price_quote, median_price) for row in rows)
                if price_dev > self.max_price_deviation_pct:
                    reasons.append("divergencia_de_preco_entre_fontes")

                liquidities = [row.liquidity_quote for row in rows if row.liquidity_quote is not None]
                if len(liquidities) >= self.minimum_sources:
                    liquidities.sort()
                    mid = len(liquidities) // 2
                    median_liquidity = liquidities[mid] if len(liquidities) % 2 else (liquidities[mid - 1] + liquidities[mid]) / 2
                    liquidity_dev = max(self._deviation(value, median_liquidity) for value in liquidities)
                    if liquidity_dev > self.max_liquidity_deviation_pct:
                        reasons.append("divergencia_de_liquidez_entre_fontes")

            findings.append(MarketIntegrityFinding(
                pool, mint, quote, ("inconclusivo" if len(rows) < self.minimum_sources else
                ("inconsistente" if reasons else "consistente")), tuple(sorted(by_source)), price_dev, liquidity_dev, tuple(reasons)
            ))
        return tuple(findings)

    def blocked_token_mints(self, findings: Iterable[MarketIntegrityFinding]) -> frozenset[str]:
        return frozenset(item.token_mint for item in findings if item.state == "inconsistente")
