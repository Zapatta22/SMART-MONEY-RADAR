"""Watchdog determinístico de atualidade por pool; não executa ordens."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Iterable

from smart_money_radar.data_sources.market_feed import MarketDataSnapshot


@dataclass(frozen=True)
class PoolFeedStatus:
    pool_address: str
    state: str  # sem_dados, saudavel, desatualizado, intervalo_anormal
    last_observed_at: datetime | None
    age_seconds: float | None
    expected_interval_seconds: float
    refresh_due: bool
    reason: str


class MarketFeedWatchdog:
    """Acompanha timestamps do provedor, nunca timestamps de leitura do cache.

    A janela de frescor é dinâmica: max(minimum_stale_after,
    expected_interval * stale_after_intervals). Reconsultas são apenas
    sinalizadas e limitadas por cooldown; o serviço de polling decide executá-las
    respeitando seu limitador global de requests.
    """
    def __init__(self, *, expected_interval: timedelta = timedelta(seconds=20),
                 stale_after_intervals: float = 3.0,
                 minimum_stale_after: timedelta = timedelta(seconds=60),
                 refresh_cooldown: timedelta = timedelta(seconds=30),
                 abnormal_fast_factor: float = 0.10) -> None:
        if expected_interval <= timedelta(0) or stale_after_intervals <= 0:
            raise ValueError("intervalo esperado e multiplicador devem ser positivos")
        if minimum_stale_after <= timedelta(0) or refresh_cooldown < timedelta(0):
            raise ValueError("limites temporais inválidos")
        if not 0 < abnormal_fast_factor < 1:
            raise ValueError("abnormal_fast_factor deve ficar entre 0 e 1")
        self.expected_interval = expected_interval.total_seconds()
        self.stale_after_intervals = stale_after_intervals
        self.minimum_stale_after = minimum_stale_after.total_seconds()
        self.refresh_cooldown = refresh_cooldown.total_seconds()
        self.abnormal_fast_factor = abnormal_fast_factor
        self._last_observed: dict[str, datetime] = {}
        self._last_refresh_signal: dict[str, datetime] = {}
        self._previous_observed: dict[str, datetime] = {}
        self._abnormal: set[str] = set()
        self._known: set[str] = set()

    def register(self, pools: Iterable[str]) -> None:
        self._known.update(pools)

    def observe(self, snapshots: Iterable[MarketDataSnapshot]) -> None:
        # Um pool pode gerar vários snapshots por ciclo (um por token/par).
        # Consolidamos o timestamp para não confundir duplicidade com frequência.
        newest_by_pool: dict[str, datetime] = {}
        for item in snapshots:
            current = newest_by_pool.get(item.pool_address)
            if current is None or item.observed_at > current:
                newest_by_pool[item.pool_address] = item.observed_at
        for pool, observed_at in newest_by_pool.items():
            previous = self._last_observed.get(pool)
            if previous is not None:
                interval = (observed_at - previous).total_seconds()
                if interval < 0 or interval < self.expected_interval * self.abnormal_fast_factor:
                    self._abnormal.add(pool)
                else:
                    self._abnormal.discard(pool)
            self._previous_observed[pool] = previous or observed_at
            # Não regredir o relógio em caso de snapshot fora de ordem.
            if previous is None or observed_at > previous:
                self._last_observed[pool] = observed_at
            self._known.add(pool)

    def status(self, pool: str, *, now: datetime | None = None) -> PoolFeedStatus:
        current = now or datetime.now(timezone.utc)
        if current.tzinfo is None or current.utcoffset() is None:
            raise ValueError("now precisa conter fuso horário")
        last = self._last_observed.get(pool)
        if last is None:
            return PoolFeedStatus(pool, "sem_dados", None, None, self.expected_interval,
                                  True, "pool ainda não possui atualização confirmada do provedor")
        age = max(0.0, (current - last).total_seconds())
        stale_after = max(self.minimum_stale_after,
                          self.expected_interval * self.stale_after_intervals)
        if age > stale_after:
            state, reason = "desatualizado", "última atualização excedeu a janela de frescor"
        elif pool in self._abnormal:
            state, reason = "intervalo_anormal", "intervalo entre atualizações fora do padrão esperado"
        else:
            state, reason = "saudavel", "atualização dentro da janela esperada"
        due = state in {"sem_dados", "desatualizado", "intervalo_anormal"}
        signaled = self._last_refresh_signal.get(pool)
        if due and signaled is not None and (current - signaled).total_seconds() < self.refresh_cooldown:
            due = False
        return PoolFeedStatus(pool, state, last, age, self.expected_interval, due, reason)

    def unhealthy_pools(self, *, now: datetime | None = None) -> frozenset[str]:
        return frozenset(pool for pool in self._known
                         if self.status(pool, now=now).state != "saudavel")

    def pools_due_for_refresh(self, *, now: datetime | None = None) -> tuple[str, ...]:
        current = now or datetime.now(timezone.utc)
        due = tuple(sorted(pool for pool in self._known
                           if self.status(pool, now=current).refresh_due))
        for pool in due:
            self._last_refresh_signal[pool] = current
        return due

    def blocked_token_mints(self, pool_tokens: dict[str, set[str]], *,
                            now: datetime | None = None) -> frozenset[str]:
        """Converte pools não saudáveis nos mints que devem ser bloqueados."""
        unhealthy = self.unhealthy_pools(now=now)
        return frozenset(mint for pool, mints in pool_tokens.items()
                         if pool in unhealthy for mint in mints)
