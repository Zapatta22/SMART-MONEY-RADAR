"""Diagnóstico determinístico da qualidade operacional do Market Radar."""
from __future__ import annotations
from dataclasses import dataclass
from statistics import median
from typing import Any, Sequence


@dataclass(frozen=True)
class MarketPollingHealthReport:
    status: str
    cycles_analyzed: int
    failure_rate: float
    rejection_rate: float
    cache_rate: float
    median_duration_ms: float
    reasons: tuple[str, ...]


class MarketPollingHealthAnalyzer:
    """Avalia ciclos recentes; não altera limites, cache nem decisões de trading."""
    def __init__(self, *, degraded_failure_rate: float = 0.05,
                 critical_failure_rate: float = 0.25,
                 degraded_rejection_rate: float = 0.20,
                 critical_rejection_rate: float = 0.50,
                 slow_cycle_ms: int = 5000) -> None:
        for value in (degraded_failure_rate, critical_failure_rate,
                      degraded_rejection_rate, critical_rejection_rate):
            if not 0 <= value <= 1:
                raise ValueError("taxas devem estar entre 0 e 1")
        if degraded_failure_rate > critical_failure_rate or degraded_rejection_rate > critical_rejection_rate:
            raise ValueError("limites degradados devem ser menores ou iguais aos críticos")
        if slow_cycle_ms < 1:
            raise ValueError("slow_cycle_ms deve ser positivo")
        self.degraded_failure_rate=degraded_failure_rate
        self.critical_failure_rate=critical_failure_rate
        self.degraded_rejection_rate=degraded_rejection_rate
        self.critical_rejection_rate=critical_rejection_rate
        self.slow_cycle_ms=slow_cycle_ms

    def analyze(self, cycles: Sequence[dict[str, Any]]) -> MarketPollingHealthReport:
        if not cycles:
            return MarketPollingHealthReport("sem_dados", 0, 0.0, 0.0, 0.0, 0.0,
                ("Nenhum ciclo registrado; ainda não há base para avaliar a saúde do feed.",))
        requested=sum(int(c.get("requested_pools",0)) for c in cycles)
        failed=sum(int(c.get("failed_pools",0)) for c in cycles)
        received=sum(int(c.get("ingestion_received",0)) for c in cycles)
        rejected=sum(len(c.get("rejected_details",())) for c in cycles)
        cached=sum(int(c.get("cached_pools",0)) for c in cycles)
        durations=[int(c.get("duration_ms",0)) for c in cycles]
        failure_rate=failed/requested if requested else 0.0
        rejection_rate=rejected/received if received else 0.0
        cache_rate=cached/requested if requested else 0.0
        median_ms=float(median(durations)) if durations else 0.0
        reasons=[]; severity=0
        if failure_rate >= self.critical_failure_rate and requested:
            severity=2; reasons.append(f"Falhas em {failure_rate:.1%} das consultas de pools (nível crítico).")
        elif failure_rate >= self.degraded_failure_rate and requested:
            severity=max(severity,1); reasons.append(f"Falhas em {failure_rate:.1%} das consultas de pools.")
        if rejection_rate >= self.critical_rejection_rate and received:
            severity=2; reasons.append(f"Snapshots rejeitados em {rejection_rate:.1%} dos recebidos (nível crítico).")
        elif rejection_rate >= self.degraded_rejection_rate and received:
            severity=max(severity,1); reasons.append(f"Snapshots rejeitados em {rejection_rate:.1%} dos recebidos.")
        if median_ms > self.slow_cycle_ms:
            severity=max(severity,1); reasons.append(f"Duração mediana elevada: {median_ms:.0f} ms.")
        if not reasons:
            reasons.append("Sem sinais de degradação pelos limites operacionais configurados.")
        status="critico" if severity==2 else "degradado" if severity==1 else "saudavel"
        return MarketPollingHealthReport(status,len(cycles),failure_rate,rejection_rate,cache_rate,median_ms,tuple(reasons))
