"""Interface de linha de comando do SMR."""

import argparse
import asyncio
import logging
import signal
from pathlib import Path
from collections.abc import Sequence

from smart_money_radar.data_sources.helius import HeliusDataSource
from smart_money_radar.analysis.wallet_intelligence import WalletIntelligenceAnalyzer
from smart_money_radar.analysis.swap_performance import evaluate_swap_performance
from smart_money_radar.domain.models import Wallet
from smart_money_radar.services.wallet_monitor import WalletMonitor
from smart_money_radar.settings import HeliusSettings, SettingsError
from smart_money_radar.storage.event_store import SQLiteEventStore
from smart_money_radar.storage.telemetry_store import TelemetryStore
from smart_money_radar.storage.wallet_intelligence_store import WalletIntelligenceStore
from smart_money_radar.storage.swap_store import SQLiteSwapStore
from smart_money_radar.analysis.market_polling_health import MarketPollingHealthAnalyzer
from smart_money_radar.storage.market_polling_cycle_store import SQLiteMarketPollingCycleStore


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="smr",
        description="Monitoramento local, somente leitura, de carteiras públicas Solana.",
    )
    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("check", help="verifica uma resposta do endpoint Helius RPC")
    intelligence_parser = subparsers.add_parser(
        "intelligence", help="analisa o histórico SQLite local sem acessar a rede"
    )
    intelligence_parser.add_argument(
        "--database", default="data/smr_history.sqlite3",
        help="caminho do banco SQLite local (padrão: data/smr_history.sqlite3)",
    )
    intelligence_parser.add_argument(
        "--limit", type=int, default=100000,
        help="máximo de eventos históricos a analisar (padrão: 100000)",
    )
    health_parser = subparsers.add_parser(
        "market-health", help="avalia a qualidade dos ciclos locais do Market Radar"
    )
    health_parser.add_argument("--database", default="data/smr_history.sqlite3",
        help="caminho do banco SQLite local")
    health_parser.add_argument("--limit", type=int, default=100,
        help="quantidade de ciclos recentes a avaliar (1 a 10000)")
    watch_parser = subparsers.add_parser(
        "watch", help="monitora endereços públicos via WebSocket"
    )
    watch_parser.add_argument(
        "addresses",
        nargs="+",
        metavar="PUBLIC_ADDRESS",
        help="um ou mais endereços públicos Solana",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    """Executa a ação solicitada; a execução sem comando não acessa a rede."""
    args = _parser().parse_args(argv)
    if args.command == "market-health":
        if not 1 <= args.limit <= 10000:
            raise SystemExit("--limit deve ficar entre 1 e 10000.")
        cycles = SQLiteMarketPollingCycleStore(args.database).list_recent(args.limit)
        report = MarketPollingHealthAnalyzer().analyze(cycles)
        print(f"Market Radar — saúde operacional: {report.status}")
        print(f"Ciclos analisados: {report.cycles_analyzed}")
        print(f"Taxa de falhas: {report.failure_rate:.1%} | rejeição: {report.rejection_rate:.1%} | cache: {report.cache_rate:.1%}")
        print(f"Duração mediana: {report.median_duration_ms:.0f} ms")
        for reason in report.reasons:
            print(f"- {reason}")
        print("Diagnóstico somente leitura: nenhuma regra de entrada ou execução foi alterada.")
        return
    if args.command is None:
        print("SMART MONEY RADAR (SMR)")
        print("Modo somente leitura. Nenhuma conexão de rede será iniciada sem comando.")
        print("Use 'smr intelligence' para analisar o histórico local sem rede.")
        print("Use 'smr check' ou 'smr watch PUBLIC_ADDRESS' somente após habilitar o acesso.")
        return

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    if args.command == "intelligence":
        if args.limit < 1:
            raise SystemExit("--limit deve ser maior que zero.")
        database_path = Path(args.database).expanduser()
        event_store = SQLiteEventStore(database_path)
        events = event_store.get_events(limit=args.limit)
        swaps = SQLiteSwapStore(database_path).get_executions(limit=args.limit)
        report = WalletIntelligenceAnalyzer().analyze(events)
        saved_profiles, saved_relationships, saved_performances = WalletIntelligenceStore(database_path).save_report(report)
        print(f"Wallet Intelligence — {report.generated_at.isoformat()}")
        print(f"Eventos analisados: {report.event_count}")
        print(f"Swaps normalizados armazenados: {len(swaps)} (preço na unidade de cotação original)")
        for performance in evaluate_swap_performance(swaps):
            win_rate = "indisponível" if performance.win_rate is None else f"{performance.win_rate:.1%}"
            print(
                f"- Swap Performance {performance.wallet_address} [{performance.quote_mint}]: "
                f"PnL realizado {performance.realized_pnl_quote} {performance.quote_mint}; "
                f"win rate {win_rate}; taxas de rede incluídas: {performance.network_fees_included}; "
                f"vendas conciliadas {performance.matched_sell_fills}; "
                f"posições abertas {performance.open_positions}; "
                f"vendas não conciliadas {performance.unmatched_sell_quantities}"
            )
        print(f"Carteiras: {len(report.profiles)} | relações heurísticas: {len(report.relationships)}")
        for profile in report.profiles:
            print(
                f"- {profile.wallet_address}: {profile.event_count} eventos, "
                f"{profile.unique_tokens} mints, {profile.active_days} dias ativos, "
                f"{profile.transactions_per_active_day:.2f} transações/dia ativo"
            )
        for relationship in report.relationships:
            print(
                f"- Relação {relationship.wallet_a} ↔ {relationship.wallet_b}: "
                f"score heurístico {relationship.association_score}/100; "
                + "; ".join(relationship.evidence)
            )
        for performance in report.performances:
            win_rate = "indisponível" if performance.win_rate is None else f"{performance.win_rate:.1%}"
            print(
                f"- Desempenho {performance.wallet_address}: PnL realizado "
                f"US$ {performance.realized_pnl_usd}, win rate {win_rate}; "
                f"posições abertas por mint: {performance.open_positions_by_mint}"
            )
        print(f"Snapshots gravados: {saved_profiles} perfis, {saved_relationships} relações, {saved_performances} métricas de desempenho.")
        print("Atenção: score de associação não calibrado; sem fills precificados não há PnL ou qualidade financeira confirmada.")
        return
    try:
        settings = HeliusSettings.from_environment()
        telemetry_store = TelemetryStore(settings.database_path)
        source = HeliusDataSource(settings, telemetry_store=telemetry_store)
        if args.command == "check":
            result = source.get_version()
            print(f"Resposta RPC Helius confirmada: Solana {result.get('solana-core', 'versão desconhecida')}.")
            return
        if args.command == "watch":
            _run_monitor(settings, source, args.addresses, telemetry_store)
            return
    except (SettingsError, RuntimeError, ValueError) as exc:
        raise SystemExit(str(exc)) from None


def _run_monitor(
    settings: HeliusSettings,
    source: HeliusDataSource,
    addresses: list[str],
    telemetry_store: TelemetryStore,
) -> None:
    wallets = [Wallet(address=address) for address in addresses]
    event_store = SQLiteEventStore(settings.database_path)
    monitor = WalletMonitor(
        settings, source, event_store, telemetry_store=telemetry_store,
        swap_store=SQLiteSwapStore(settings.database_path),
    )
    stop_event = asyncio.Event()
    loop = asyncio.new_event_loop()
    for signal_name in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(signal_name, stop_event.set)
        except (NotImplementedError, RuntimeError):
            pass
    try:
        loop.run_until_complete(monitor.run_forever(wallets, stop_event))
    except KeyboardInterrupt:
        stop_event.set()
    finally:
        loop.close()
