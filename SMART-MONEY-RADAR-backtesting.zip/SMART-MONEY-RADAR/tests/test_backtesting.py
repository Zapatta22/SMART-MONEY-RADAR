import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal as D

from smart_money_radar.analysis.backtesting import BacktestConfig, MarketBar, run_backtest
from smart_money_radar.analysis.decision_engine import DecisionCandidate, DecisionPolicy, EntryMode

T = datetime(2026, 1, 1, tzinfo=timezone.utc)
CHECKS = {"mint_authority_disabled": True, "freeze_authority_disabled": True,
          "liquidity_lock_verified": True, "honeypot_check": True}

def candidate(cid="c1", mint="mint", price="10", mode_time=0):
    return DecisionCandidate(cid, mint, T, T + timedelta(seconds=mode_time), D(price), D(price),
        D("20000"), D("2000"), D("1000"), D("0.02"), 90, CHECKS)

class BacktestingTests(unittest.TestCase):
    def test_profitable_trade_includes_costs(self):
        bars = [MarketBar("mint", T + timedelta(minutes=16), D("12"))]
        report = run_backtest([candidate()], bars)
        self.assertEqual(report.trade_count, 1)
        self.assertGreater(report.final_equity, report.initial_equity)
        self.assertLess(report.trades[0].net_return_pct, report.trades[0].gross_return_pct)

    def test_loss_and_drawdown(self):
        report = run_backtest([candidate()], [MarketBar("mint", T + timedelta(minutes=15), D("8"))])
        self.assertEqual(report.losses, 1)
        self.assertGreater(report.max_drawdown_pct, 0)

    def test_missing_future_bar_is_unresolved(self):
        report = run_backtest([candidate()], [])
        self.assertEqual(report.unresolved_candidates, 1)
        self.assertEqual(report.trade_count, 0)

    def test_failed_safety_gate_is_blocked(self):
        bad = dict(CHECKS); bad["honeypot_check"] = False
        c = DecisionCandidate("bad", "mint", T, T, D("10"), D("10"), D("20000"), D("2000"), D("1000"), D("0.02"), 90, bad)
        report = run_backtest([c], [MarketBar("mint", T + timedelta(minutes=15), D("12"))])
        self.assertEqual(report.blocked_candidates, 1)
        self.assertEqual(report.trade_count, 0)

    def test_confirmed_mode_requires_price_and_volume(self):
        report = run_backtest([candidate()], [MarketBar("mint", T + timedelta(minutes=15), D("12"))],
                              config=BacktestConfig(entry_mode=EntryMode.CONFIRMED))
        self.assertEqual(report.blocked_candidates, 1)

    def test_candidate_order_is_chronological(self):
        c2 = candidate("c2", mode_time=1)
        bars = [MarketBar("mint", T + timedelta(minutes=16), D("11")),
                MarketBar("mint", T + timedelta(minutes=17), D("12"))]
        report = run_backtest([c2, candidate()], bars)
        self.assertEqual([t.candidate_id for t in report.trades], ["c1", "c2"])

    def test_invalid_bar_and_config_rejected(self):
        with self.assertRaises(ValueError): MarketBar("mint", T, D("0"))
        with self.assertRaises(ValueError): BacktestConfig(fee_rate=D("1"))

    def test_no_lookahead_exit_before_holding_period(self):
        bars = [MarketBar("mint", T + timedelta(minutes=14), D("50")),
                MarketBar("mint", T + timedelta(minutes=15), D("11"))]
        report = run_backtest([candidate()], bars)
        self.assertEqual(report.trades[0].exit_price, D("11") * (D(1)-D("0.002")))

if __name__ == "__main__": unittest.main()
