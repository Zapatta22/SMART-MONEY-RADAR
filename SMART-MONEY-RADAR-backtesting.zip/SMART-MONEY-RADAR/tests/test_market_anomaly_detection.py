import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from smart_money_radar.analysis.market_anomaly_detection import MarketAnomalyDetector
from smart_money_radar.data_sources.market_feed import MarketDataSnapshot

class MarketAnomalyDetectionTests(unittest.TestCase):
    def setUp(self):
        self.t0 = datetime(2026, 11, 16, 12, tzinfo=timezone.utc)
        self.detector = MarketAnomalyDetector()

    def snap(self, minute, price='1', volume='100', liquidity='1000', buys=50, sells=50):
        return MarketDataSnapshot('dex-a', 'pool-a', 'mint-a', 'sol', self.t0 + timedelta(minutes=minute),
            Decimal(price), volume_24h_quote=Decimal(volume), liquidity_quote=Decimal(liquidity),
            buys_24h=buys, sells_24h=sells)

    def test_normal_series(self):
        finding = self.detector.analyze([self.snap(0), self.snap(1, '1.05', '120', '950')])[0]
        self.assertEqual(finding.state, 'normal')

    def test_abrupt_price_volume_and_liquidity_are_flagged(self):
        finding = self.detector.analyze([self.snap(0), self.snap(1, '2', '900', '500', 99, 1)])[0]
        self.assertEqual(finding.state, 'anomalia')
        self.assertIn('variacao_abrupta_de_preco', finding.reasons)
        self.assertIn('pico_anormal_de_volume', finding.reasons)
        self.assertIn('queda_brusca_de_liquidez', finding.reasons)
        self.assertIn('desequilibrio_extremo_de_negociacoes', finding.reasons)
        self.assertEqual(self.detector.blocked_token_mints([finding]), frozenset({'mint-a'}))

    def test_single_snapshot_is_inconclusive(self):
        finding = self.detector.analyze([self.snap(0)])[0]
        self.assertEqual(finding.state, 'inconclusivo')
        self.assertFalse(self.detector.blocked_token_mints([finding]))

    def test_invalid_threshold(self):
        with self.assertRaises(ValueError):
            MarketAnomalyDetector(max_trade_imbalance=Decimal('1.1'))

if __name__ == '__main__':
    unittest.main()
