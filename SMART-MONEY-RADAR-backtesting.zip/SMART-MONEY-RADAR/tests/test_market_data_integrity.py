import unittest
from datetime import datetime, timezone
from decimal import Decimal

from smart_money_radar.analysis.market_data_integrity import MarketDataIntegrityAnalyzer
from smart_money_radar.data_sources.market_feed import MarketDataSnapshot


class MarketDataIntegrityTests(unittest.TestCase):
    def setUp(self):
        self.now = datetime(2026, 11, 16, 12, tzinfo=timezone.utc)
        self.analyzer = MarketDataIntegrityAnalyzer()

    def snap(self, source, price, liquidity="1000", mint="mint-a"):
        return MarketDataSnapshot(source, "pool-a", mint, "quote", self.now,
                                  Decimal(price), liquidity_quote=Decimal(liquidity))

    def test_consistent_independent_sources(self):
        result = self.analyzer.analyze([self.snap("dex-a", "1.00"), self.snap("dex-b", "1.02")])
        self.assertEqual(result[0].state, "consistente")
        self.assertEqual(result[0].reasons, ())

    def test_price_divergence_is_flagged_and_token_blocked(self):
        result = self.analyzer.analyze([self.snap("dex-a", "1"), self.snap("dex-b", "1.30")])
        self.assertIn("divergencia_de_preco_entre_fontes", result[0].reasons)
        self.assertEqual(self.analyzer.blocked_token_mints(result), frozenset({"mint-a"}))

    def test_liquidity_divergence_is_flagged(self):
        result = self.analyzer.analyze([self.snap("dex-a", "1", "100"), self.snap("dex-b", "1", "1000")])
        self.assertIn("divergencia_de_liquidez_entre_fontes", result[0].reasons)

    def test_one_source_is_inconclusive_not_auto_blocked(self):
        result = self.analyzer.analyze([self.snap("dex-a", "1")])
        self.assertEqual(result[0].state, "inconclusivo")
        self.assertEqual(self.analyzer.blocked_token_mints(result), frozenset())

    def test_latest_snapshot_per_source_is_used(self):
        old = MarketDataSnapshot("dex-a", "pool-a", "mint-a", "quote", self.now,
                                 Decimal("9"), liquidity_quote=Decimal("100"))
        newer = MarketDataSnapshot("dex-a", "pool-a", "mint-a", "quote", self.now.replace(minute=1),
                                   Decimal("1"), liquidity_quote=Decimal("1000"))
        result = self.analyzer.analyze([old, newer, self.snap("dex-b", "1.01")])
        self.assertEqual(result[0].reasons, ())

    def test_invalid_threshold_rejected(self):
        with self.assertRaises(ValueError):
            MarketDataIntegrityAnalyzer(minimum_sources=1)


if __name__ == "__main__":
    unittest.main()
