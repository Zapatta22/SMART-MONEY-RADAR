import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from smart_money_radar.analysis.market_feed_watchdog import MarketFeedWatchdog
from smart_money_radar.data_sources.market_feed import MarketDataSnapshot


class WatchdogTests(unittest.TestCase):
    def setUp(self):
        self.now = datetime(2026, 11, 16, 12, tzinfo=timezone.utc)
        self.watchdog = MarketFeedWatchdog(
            expected_interval=timedelta(seconds=20),
            minimum_stale_after=timedelta(seconds=60),
            refresh_cooldown=timedelta(seconds=30),
        )

    def snapshot(self, at, pool="pool-a", mint="mint-a"):
        return MarketDataSnapshot("test", pool, mint, "quote", at, Decimal("1"))

    def test_unknown_pool_is_blocked_and_refresh_is_suggested(self):
        self.watchdog.register(["pool-a"])
        status = self.watchdog.status("pool-a", now=self.now)
        self.assertEqual(status.state, "sem_dados")
        self.assertTrue(status.refresh_due)
        self.assertEqual(self.watchdog.unhealthy_pools(now=self.now), frozenset({"pool-a"}))

    def test_fresh_provider_update_is_healthy(self):
        self.watchdog.observe([self.snapshot(self.now)])
        self.assertEqual(self.watchdog.status("pool-a", now=self.now).state, "saudavel")

    def test_stale_data_triggers_refresh_with_cooldown(self):
        self.watchdog.observe([self.snapshot(self.now - timedelta(minutes=2))])
        status = self.watchdog.status("pool-a", now=self.now)
        self.assertEqual(status.state, "desatualizado")
        self.assertTrue(status.refresh_due)
        self.assertEqual(self.watchdog.pools_due_for_refresh(now=self.now), ("pool-a",))
        self.assertFalse(self.watchdog.status("pool-a", now=self.now + timedelta(seconds=5)).refresh_due)
        self.assertTrue(self.watchdog.status("pool-a", now=self.now + timedelta(seconds=31)).refresh_due)

    def test_abnormally_fast_updates_are_flagged(self):
        self.watchdog.observe([self.snapshot(self.now - timedelta(seconds=1))])
        self.watchdog.observe([self.snapshot(self.now)])
        self.assertEqual(self.watchdog.status("pool-a", now=self.now).state, "intervalo_anormal")

    def test_multiple_token_snapshots_same_cycle_are_not_abnormal(self):
        self.watchdog.observe([
            self.snapshot(self.now - timedelta(seconds=20), mint="mint-a"),
            self.snapshot(self.now - timedelta(seconds=20), mint="mint-b"),
        ])
        self.watchdog.observe([
            self.snapshot(self.now, mint="mint-a"),
            self.snapshot(self.now, mint="mint-b"),
        ])
        self.assertEqual(self.watchdog.status("pool-a", now=self.now).state, "saudavel")

    def test_unhealthy_pool_mints_are_exposed_for_decision_gate(self):
        self.watchdog.register(["pool-a", "pool-b"])
        self.watchdog.observe([self.snapshot(self.now)])
        blocked = self.watchdog.blocked_token_mints({
            "pool-a": {"mint-a", "mint-b"}, "pool-b": {"mint-c", "mint-d"}
        }, now=self.now)
        self.assertEqual(blocked, frozenset({"mint-c", "mint-d"}))

    def test_naive_clock_is_rejected(self):
        with self.assertRaises(ValueError):
            self.watchdog.status("pool-a", now=datetime(2026, 1, 1))


if __name__ == "__main__":
    unittest.main()
