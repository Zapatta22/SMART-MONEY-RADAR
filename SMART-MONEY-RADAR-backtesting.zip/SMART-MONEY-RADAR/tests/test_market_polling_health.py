import unittest
from smart_money_radar.analysis.market_polling_health import MarketPollingHealthAnalyzer


class MarketPollingHealthTests(unittest.TestCase):
    def test_no_history_is_not_reported_as_healthy(self):
        report = MarketPollingHealthAnalyzer().analyze([])
        self.assertEqual(report.status, 'sem_dados')

    def test_healthy_cycles(self):
        cycles = [dict(requested_pools=10, failed_pools=0, ingestion_received=10,
                       rejected_details=[], cached_pools=3, duration_ms=120)]
        report = MarketPollingHealthAnalyzer().analyze(cycles)
        self.assertEqual(report.status, 'saudavel')
        self.assertAlmostEqual(report.cache_rate, .3)

    def test_failure_rate_can_mark_critical(self):
        cycles = [dict(requested_pools=10, failed_pools=3, ingestion_received=0,
                       rejected_details=[], cached_pools=0, duration_ms=100)]
        report = MarketPollingHealthAnalyzer().analyze(cycles)
        self.assertEqual(report.status, 'critico')

    def test_rejections_and_slow_cycles_mark_degraded(self):
        cycles = [dict(requested_pools=10, failed_pools=0, ingestion_received=10,
                       rejected_details=[('p', 'stale')] * 3, cached_pools=0, duration_ms=6000)]
        report = MarketPollingHealthAnalyzer().analyze(cycles)
        self.assertEqual(report.status, 'degradado')
        self.assertEqual(len(report.reasons), 2)

    def test_invalid_thresholds_are_rejected(self):
        with self.assertRaises(ValueError):
            MarketPollingHealthAnalyzer(degraded_failure_rate=.3, critical_failure_rate=.2)


if __name__ == '__main__':
    unittest.main()
