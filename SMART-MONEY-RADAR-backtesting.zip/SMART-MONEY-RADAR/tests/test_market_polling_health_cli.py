import contextlib
import io
import tempfile
import unittest
from pathlib import Path
from smart_money_radar.cli import main


class MarketPollingHealthCliTests(unittest.TestCase):
    def test_command_reports_empty_history_without_network(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                main(['market-health', '--database', str(Path(tmp) / 'health.sqlite3')])
            self.assertIn('saúde operacional: sem_dados', output.getvalue())
            self.assertIn('somente leitura', output.getvalue())

    def test_command_rejects_invalid_limit(self):
        with self.assertRaises(SystemExit):
            main(['market-health', '--limit', '0'])


if __name__ == '__main__':
    unittest.main()
