# SMART MONEY RADAR (SMR)

Infraestrutura local para observar atividade pública de carteiras na blockchain
Solana. A integração Helius usa JSON-RPC e WebSocket padrão, enriquece
notificações com detalhes de transação e grava eventos em SQLite.

## Garantias e limites

- Somente leitura: são usados `getVersion`, `getSignaturesForAddress`,
  `getTransaction` e `logsSubscribe`. Não existe envio ou assinatura de
  transações.
- O monitor acompanha somente endereços públicos passados explicitamente.
- Nenhuma chave privada ou frase-semente é aceita ou armazenada.
- Chamadas externas ficam bloqueadas por padrão. `SMR_ALLOW_NETWORK=true` é uma
  autorização explícita para o SMR fazer requisições; antes disso, verifique os
  limites e possíveis custos do seu plano Helius. Este projeto não contrata um
  plano nem faz uma conexão automaticamente.
- A API key é lida de `HELIUS_API_KEY`, nunca impressa em logs ou incluída no
  README.
- O arquivo `.env` local e o banco SQLite são ignorados pelo Git.

## Estrutura e módulos

```text
smart-money-radar/
├── .env.example
├── README.md
├── pyproject.toml
├── src/smart_money_radar/
│   ├── cli.py
│   ├── settings.py
│   ├── analysis/
│   │   ├── metrics.py
│   │   └── wallet_intelligence.py
│   ├── data_sources/
│   │   ├── base.py
│   │   ├── helius.py
│   │   ├── solana.py
│   │   └── transaction_parser.py
│   ├── domain/models.py
│   ├── services/
│   │   ├── wallet_monitor.py
│   │   └── wallet_tracker.py
│   └── storage/
│       ├── event_store.py
│       ├── telemetry_store.py
│       └── wallet_intelligence_store.py
└── tests/
```

- `settings.py`: carrega ambiente/`.env`, valida cluster e bloqueia acesso de
  rede sem autorização explícita.
- `data_sources/helius.py`: cliente HTTP JSON-RPC de leitura, valida respostas
  e evita expor a URL que contém a API key.
- `data_sources/transaction_parser.py`: extrai deltas por token a partir dos
  saldos pré/pós e transferências SOL identificadas em instruções decodificadas.
  O mint sentinela `SOL` representa SOL nativo, não um mint SPL.
- `data_sources/solana.py`: mantém o nome da classe inicial e encaminha para o
  adaptador Helius quando recebe configuração.
- `services/wallet_monitor.py`: abre WebSocket com `logsSubscribe` por endereço,
  consulta detalhes das assinaturas e reconecta com backoff exponencial. O
  WebSocket envia ping periódico para manter a sessão ativa.
- `storage/event_store.py`: histórico SQLite local, com deduplicação por
  carteira, assinatura, mint e direção.
- `storage/telemetry_store.py`: marcos de detecção/análise/persistência,
  latências médias, eventos de conexão/reconexão e contagem de chamadas RPC.
  A telemetria compartilha o banco SQLite configurado em `SMR_DB_PATH`.
- `domain/models.py`: modelos para carteiras públicas e eventos observados.
- `analysis/metrics.py`: contagens descritivas por mint.
- `analysis/wallet_intelligence.py`: perfis históricos, frequência por assinatura,
  métricas por mint, tamanho relativo de eventos e relações heurísticas entre
  carteiras. Inclui um avaliador FIFO de PnL realizado para fills normalizados
  com preço, sem presumir que deltas de saldo sejam trades.
- `storage/wallet_intelligence_store.py`: snapshots históricos SQLite dos perfis,
  relações e métricas de desempenho fornecidas.
- `services/wallet_tracker.py`: serviço existente preservado para consultas
  através de uma fonte compatível.
- `tests/`: testes `unittest` com respostas HTTP/WebSocket simuladas; não
  conectam à blockchain.

## Instalação e configuração

Na pasta `smart-money-radar`:

```bash
python -m pip install -e .
cp .env.example .env
```

Preencha `HELIUS_API_KEY` somente no arquivo local `.env` ou no mecanismo de
Secrets do ambiente. Nunca envie a chave pelo chat nem a grave no código. Para
autorizar acesso externo, revise as condições da sua conta Helius e então altere
`SMR_ALLOW_NETWORK` para `true`. O valor de exemplo é `false`.

`SOLANA_CLUSTER` aceita `mainnet` ou `devnet`. O histórico fica em
`data/smr_history.sqlite3`, salvo se `SMR_DB_PATH` apontar para outro local.

## Comandos

Sem argumentos, o SMR mostra ajuda de estado e não faz chamadas de rede:

```bash
smr
```

`check` faz uma consulta RPC `getVersion` e só informa sucesso após receber uma
resposta válida:

```bash
smr check
```

`intelligence` analisa o histórico SQLite existente, grava snapshots de perfis
e relações e não precisa de API key nem de autorização de rede:

```bash
smr intelligence
smr intelligence --database data/smr_history.sqlite3 --limit 100000
```

O comando informa eventos analisados, carteiras, frequência de transações por
dia ativo, relações heurísticas e snapshots gravados. Ele cria o banco vazio se
ainda não existir; nesse caso, naturalmente, não haverá carteiras para analisar.

`watch` abre um monitor WebSocket para endereços públicos e grava novos eventos
no banco local. Encerre com `Ctrl+C`:

```bash
smr watch <ENDERECO_PUBLICO> [OUTRO_ENDERECO_PUBLICO ...]
```

O método padrão `logsSubscribe` aceita um endereço por assinatura; o SMR cria
uma assinatura para cada endereço informado na mesma conexão. Para eventos
confirmados, consulta `getTransaction` e extrai o mint, assinatura, horário
quando fornecido pelo RPC, direção e quantidade quando os dados permitem. SOL é
extraído apenas de instruções `system` decodificadas; taxas não são tratadas como
transferências.

Referências do protocolo:

- [Helius `logsSubscribe`](https://www.helius.dev/docs/api-reference/rpc/websocket/logssubscribe)
- [Helius endpoints RPC e WebSocket](https://www.helius.dev/docs/api-reference/endpoints)
- [Solana `getTransaction`](https://solana.com/docs/rpc/http/gettransaction)

## Testes

```bash
python -m unittest discover -s tests -v
```

Os testes simulam RPC, notificações WebSocket, reconexão, parser, telemetria e SQLite. Não
fazem requisições reais e, portanto, não verificam credenciais, disponibilidade
do Helius ou conexão com a blockchain. A conexão real só deve ser verificada
executando `smr check` ou `smr watch` após habilitar a rede e configurar uma API
key válida.

## Telemetria e limites de estimativa

Durante `smr watch`, o SMR grava no mesmo SQLite: horário de detecção da
notificação, fim da análise, fim da gravação, eventos de conexão/reconexão e
chamadas HTTP JSON-RPC por método. O cliente aceita uma tabela de estimativas
por método (`rpc_credit_estimates`) para calcular créditos aproximados. Na CLI,
como nenhum preço de crédito é presumido, a estimativa permanece em zero até
que uma tabela validada para o plano Helius seja configurada no código. Isso
**não** substitui o painel oficial de uso da Helius nem representa cobrança
confirmada.

A telemetria é local e não envia dados adicionais à Helius. Erros ao gravá-la
são registrados no log e não interrompem o monitoramento. As médias de latência
só incluem assinaturas com os três marcos concluídos.

## Wallet Intelligence — escopo da primeira versão

A análise atual é descritiva e rastreável:

- Perfil por carteira: quantidade de eventos, mints distintos, dias ativos,
  primeira/última observação e frequência de assinaturas únicas por dia ativo.
- Por mint: entradas/saídas em unidades daquele mint, contagens, mediana e
  percentil 90 dos tamanhos observados. Unidades de tokens diferentes nunca
  são somadas ou comparadas como se fossem dólares.
- Relevância relativa: eventos no percentil 90 são destacados somente quando
  existem pelo menos cinco observações daquele mint para a carteira.
- Relações: considera assinaturas compartilhadas e coatividade no mesmo mint e
  direção dentro de uma janela temporal (padrão: 120 segundos), além de mints
  em comum. O score é uma **heurística não calibrada**, não uma probabilidade
  estatística; não prova identidade, coordenação ou controle comum. Mints em
  comum isoladamente não bastam para sinalizar uma relação.
- Snapshots: perfis e relações são gravados em tabelas próprias, sem alterar o
  histórico bruto `activity_events`.

O avaliador `evaluate_wallet_performance` recebe `PricedExecution` normalizadas
(quantidade, preço USD, taxa, lado, mint, assinatura e horário) e calcula PnL
realizado por FIFO, win rate por venda conciliada, tempo de retenção e quantidades
abertas/não conciliadas separadas por mint. Isso evita somar unidades de tokens
diferentes. **Essa entrada de fills precificados ainda não está conectada ao
parser Helius**; portanto, a versão atual não calcula PnL real das carteiras
monitoradas nem julga a qualidade efetiva de entradas/saídas a partir dos deltas
brutos. Também não calcula PnL não realizado, drawdown, slippage ou retorno
líquido completo.

O parser atual não identifica com segurança todo swap/roteamento de DEX. Um delta
de saldo pode ser transferência, airdrop, depósito/retirada de pool ou outra
atividade; não deve ser tratado automaticamente como compra/venda. A cobertura
histórica depende dos endereços e do período efetivamente monitorados.

A análise local pode ser executada sem rede e sem gastar créditos Helius:

```bash
smr intelligence --database data/smr_history.sqlite3
```

## Decodificador conservador de swaps (local e somente leitura)

`parse_swap_execution(transaction, wallet_address, signature)` tenta normalizar uma operação somente quando há exatamente um delta de token não-SOL pertencente à carteira e um delta oposto de SOL nativo identificável pelos índices `accountKeys`/`preBalances`/`postBalances`. Quando a carteira é a pagadora da taxa, a taxa de rede é adicionada de volta ao delta de SOL para não distorcer a contraprestação. O resultado informa lado (`buy`/`sell`), quantidade do token, quantidade de SOL, preço implícito em SOL por token, taxa SOL, horário e evidência de origem.

O decodificador retorna `None` diante de dados ausentes ou ambíguos. Ele não interpreta automaticamente transações com múltiplos tokens, wrapped SOL, roteadores/transferências adicionais, SOL recebido/enviado por motivos não relacionados ao swap ou timestamps ausentes. O preço calculado é **SOL por token**, nunca USD; não há oráculo de preço neste módulo. A normalização é uma inferência conservadora baseada em deltas, não uma decodificação completa de instruções de todos os AMMs/aggregators. Os eventos de saldo originais e a telemetria permanecem inalterados.

Exemplo de uso offline:

```python
from smart_money_radar.data_sources.transaction_parser import parse_swap_execution
swap = parse_swap_execution(transaction_fixture, public_wallet, signature)
if swap is not None:
    print(swap.side, swap.token_quantity, swap.quote_quantity, swap.price_quote)
```

Os testes usam fixtures sintéticas. Nenhuma chamada RPC/Helius, acesso à rede, chave privada ou execução financeira é necessária.


## Persistência integrada de swaps (etapa incremental)

O monitor agora executa o parser conservador `parse_swap_execution` em paralelo à extração de eventos e grava swaps inequívocos em `swap_executions`, no mesmo arquivo SQLite do histórico. A chave de deduplicação é carteira + assinatura + mint. O comando `smr intelligence` informa quantos swaps normalizados estão armazenados.

O preço é mantido em SOL por token e a taxa de rede em SOL. Não há conversão para USD nem cálculo de PnL a partir desses valores sem uma fonte de cotação/normalização validada. Transações ambíguas continuam no histórico de eventos, mas não são gravadas como swaps. A integração é testada com fixtures simuladas e não exige chamadas de rede durante os testes.


### Swap Performance Engine (FIFO)

O comando `smr intelligence --database CAMINHO` também calcula desempenho FIFO
a partir dos swaps normalizados persistidos. O resultado é agrupado por carteira
e ativo de cotação, sem somar unidades incompatíveis. O PnL é expresso na unidade
de cotação original (por exemplo, SOL), nunca convertido implicitamente para USD.
Taxas de rede em SOL são incluídas somente quando a cotação do grupo é SOL; para
outros ativos de cotação, o relatório identifica que as taxas de rede não foram
incluídas por falta de conversão validada. Vendas sem inventário conhecido são
reportadas separadamente e não são classificadas como perdas. Posições abertas
são quantidades remanescentes, não PnL não realizado: para isso ainda será
necessário obter uma cotação de mercado independente, datada e validada.

A métrica de win rate é calculada por fill de venda que tenha ao menos uma
quantidade conciliada. Não equivale a taxa de sucesso por posição fechada.
O módulo é analítico e não emite ordens nem habilita execução financeira.

### Wallet Ranking Engine (heurístico e somente analítico)

`rank_wallets` combina perfis de atividade, execuções precificadas e relações heurísticas. O score 0–100 usa taxa de acerto (30), suficiência amostral (25), PnL realizado positivo (20), padrão de frequência (15) e cobertura temporal (10). Relações entre carteiras geram sinalização para revisão e reduzem a confiança; não provam controle comum. Sem preços independentes e capital de referência, não são calculados ROI, drawdown nem PnL não realizado. O ranking não é probabilidade nem habilita execução financeira.

## Market Context Engine — primeira camada offline

`analysis/market_context.py` calcula contexto por par token/cotação a partir de
observações históricas explicitamente fornecidas: retorno total, volatilidade
realizada não anualizada, drawdown máximo observado, variação da liquidez
informada e volume médio informado. `assess_trade_vs_market` compara o retorno
bruto de uma operação com o retorno do token no mesmo intervalo e devolve o
excesso de retorno. `storage/market_context_store.py` persiste observações em
SQLite com chave idempotente por token, cotação e timestamp.

Esta etapa não coleta preços automaticamente e não consulta oráculos, DEXs,
Helius ou blockchain. Os resultados só são válidos na qualidade e frequência
das observações de entrada. A liquidez e o volume são proxies da fonte, não
medidas de profundidade executável; não há cálculo de slippage, previsão,
causalidade ou conversão USD. A comparação de excesso de retorno é bruta e
não inclui taxas da carteira. O módulo ainda não está acoplado ao monitor
Helius nem ao ranking automático: isso exige uma fonte histórica de mercado
validada e uma política de alinhamento temporal antes de influenciar decisões.

Os testes usam séries sintéticas locais e não fazem chamadas externas.

## Decision Engine (offline, simulação)

A camada `analysis/decision_engine.py` implementa dois modos configuráveis:

- `immediate`: avalia todos os bloqueios comuns e, se aprovados, libera somente
  uma decisão `approved_for_simulation`, sem esperar confirmação adicional;
- `confirmed`: exige os mesmos bloqueios e também confirmação mínima de preço e
  volume em relação à observação-base.

Os bloqueios comuns incluem idade do sinal, verificações de segurança,
liquidez mínima, volatilidade máxima, score Smart Money mínimo, risco de rug
pull e risco heurístico de relação entre carteiras. Os limites são configuráveis
por `DecisionPolicy`. A auditoria SQLite em `storage/decision_store.py` é
idempotente e impõe `order_created = 0`.

**Limite importante:** isto é um motor determinístico offline, não conectado a
feed de preços, Launch Radar, Market Radar, Helius ou executor. Os valores e
limites precisam ser calibrados com dados históricos e simulação; aprovação
não é recomendação nem ordem. As quatro verificações obrigatórias são exigidas no objeto de entrada:
`mint_authority_disabled`, `freeze_authority_disabled`,
`liquidity_lock_verified` e `honeypot_check`; a ausência de qualquer uma
rejeita a entrada antes da avaliação. Nenhuma chave privada ou credencial é necessária.
