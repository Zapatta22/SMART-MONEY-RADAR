# SMART MONEY RADAR (SMR)

Infraestrutura local para observar atividade pública de carteiras na blockchain
Solana. A integração Helius usa JSON-RPC e WebSocket padrão, enriquece
notificações com detalhes de transação e grava eventos em SQLite.

## Garantias e limites

- Somente leitura: são usados `getVersion`, `getSignaturesForAddress`,
  `getTransaction` e `logsSubscribe`. Não existe envio ou assinatura de
  transações.
- O monitor acompanha somente endereços públicos passados explicitamente.
- Nenhuma chave privada ou frase-semente é aceita ou armazenada.
- Chamadas externas ficam bloqueadas por padrão. `SMR_ALLOW_NETWORK=true` é uma
  autorização explícita para o SMR fazer requisições; antes disso, verifique os
  limites e possíveis custos do seu plano Helius. Este projeto não contrata um
  plano nem faz uma conexão automaticamente.
- A API key é lida de `HELIUS_API_KEY`, nunca impressa em logs ou incluída no
  README.
- O arquivo `.env` local e o banco SQLite são ignorados pelo Git.

## Estrutura e módulos

```text
smart-money-radar/
├── .env.example
├── README.md
├── pyproject.toml
├── src/smart_money_radar/
│   ├── cli.py
│   ├── settings.py
│   ├── analysis/metrics.py
│   ├── data_sources/
│   │   ├── base.py
│   │   ├── helius.py
│   │   ├── solana.py
│   │   └── transaction_parser.py
│   ├── domain/models.py
│   ├── services/
│   │   ├── wallet_monitor.py
│   │   └── wallet_tracker.py
│   └── storage/
│       ├── event_store.py
│       └── telemetry_store.py
└── tests/
```

- `settings.py`: carrega ambiente/`.env`, valida cluster e bloqueia acesso de
  rede sem autorização explícita.
- `data_sources/helius.py`: cliente HTTP JSON-RPC de leitura, valida respostas
  e evita expor a URL que contém a API key.
- `data_sources/transaction_parser.py`: extrai deltas por token a partir dos
  saldos pré/pós e transferências SOL identificadas em instruções decodificadas.
  O mint sentinela `SOL` representa SOL nativo, não um mint SPL.
- `data_sources/solana.py`: mantém o nome da classe inicial e encaminha para o
  adaptador Helius quando recebe configuração.
- `services/wallet_monitor.py`: abre WebSocket com `logsSubscribe` por endereço,
  consulta detalhes das assinaturas e reconecta com backoff exponencial. O
  WebSocket envia ping periódico para manter a sessão ativa.
- `storage/event_store.py`: histórico SQLite local, com deduplicação por
  carteira, assinatura, mint e direção.
- `storage/telemetry_store.py`: marcos de detecção/análise/persistência,
  latências médias, eventos de conexão/reconexão e contagem de chamadas RPC.
  A telemetria compartilha o banco SQLite configurado em `SMR_DB_PATH`.
- `domain/models.py`: modelos para carteiras públicas e eventos observados.
- `analysis/metrics.py`: contagens descritivas por mint; não classifica
  carteiras nem fornece recomendação financeira.
- `services/wallet_tracker.py`: serviço existente preservado para consultas
  através de uma fonte compatível.
- `tests/`: testes `unittest` com respostas HTTP/WebSocket simuladas; não
  conectam à blockchain.

## Instalação e configuração

Na pasta `smart-money-radar`:

```bash
python -m pip install -e .
cp .env.example .env
```

Preencha `HELIUS_API_KEY` somente no arquivo local `.env` ou no mecanismo de
Secrets do ambiente. Nunca envie a chave pelo chat nem a grave no código. Para
autorizar acesso externo, revise as condições da sua conta Helius e então altere
`SMR_ALLOW_NETWORK` para `true`. O valor de exemplo é `false`.

`SOLANA_CLUSTER` aceita `mainnet` ou `devnet`. O histórico fica em
`data/smr_history.sqlite3`, salvo se `SMR_DB_PATH` apontar para outro local.

## Comandos

Sem argumentos, o SMR mostra ajuda de estado e não faz chamadas de rede:

```bash
smr
```

`check` faz uma consulta RPC `getVersion` e só informa sucesso após receber uma
resposta válida:

```bash
smr check
```

`watch` abre um monitor WebSocket para endereços públicos e grava novos eventos
no banco local. Encerre com `Ctrl+C`:

```bash
smr watch <ENDERECO_PUBLICO> [OUTRO_ENDERECO_PUBLICO ...]
```

O método padrão `logsSubscribe` aceita um endereço por assinatura; o SMR cria
uma assinatura para cada endereço informado na mesma conexão. Para eventos
confirmados, consulta `getTransaction` e extrai o mint, assinatura, horário
quando fornecido pelo RPC, direção e quantidade quando os dados permitem. SOL é
extraído apenas de instruções `system` decodificadas; taxas não são tratadas como
transferências.

Referências do protocolo:

- [Helius `logsSubscribe`](https://www.helius.dev/docs/api-reference/rpc/websocket/logssubscribe)
- [Helius endpoints RPC e WebSocket](https://www.helius.dev/docs/api-reference/endpoints)
- [Solana `getTransaction`](https://solana.com/docs/rpc/http/gettransaction)

## Testes

```bash
python -m unittest discover -s tests -v
```

Os testes simulam RPC, notificações WebSocket, reconexão, parser, telemetria e SQLite. Não
fazem requisições reais e, portanto, não verificam credenciais, disponibilidade
do Helius ou conexão com a blockchain. A conexão real só deve ser verificada
executando `smr check` ou `smr watch` após habilitar a rede e configurar uma API
key válida.

## Telemetria e limites de estimativa

Durante `smr watch`, o SMR grava no mesmo SQLite: horário de detecção da
notificação, fim da análise, fim da gravação, eventos de conexão/reconexão e
chamadas HTTP JSON-RPC por método. O cliente aceita uma tabela de estimativas
por método (`rpc_credit_estimates`) para calcular créditos aproximados. Na CLI,
como nenhum preço de crédito é presumido, a estimativa permanece em zero até
que uma tabela validada para o plano Helius seja configurada no código. Isso
**não** substitui o painel oficial de uso da Helius nem representa cobrança
confirmada.

A telemetria é local e não envia dados adicionais à Helius. Erros ao gravá-la
são registrados no log e não interrompem o monitoramento. As médias de latência
só incluem assinaturas com os três marcos concluídos.
