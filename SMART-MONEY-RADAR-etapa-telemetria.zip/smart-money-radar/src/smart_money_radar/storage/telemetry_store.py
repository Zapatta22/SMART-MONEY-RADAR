"""Persistência local de latência do pipeline e consumo estimado de RPC."""

import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path


def _utc(value: datetime | None = None) -> datetime:
    result = value or datetime.now(timezone.utc)
    if result.tzinfo is None:
        raise ValueError("Os horários de telemetria devem conter fuso horário.")
    return result.astimezone(timezone.utc)


class TelemetryStore:
    """Registra marcos do processamento e chamadas RPC sem guardar credenciais.

    A estimativa de créditos é configurável por método e permanece apenas uma
    estimativa local; não representa a cobrança oficial da Helius.
    """

    def __init__(self, database_path: Path | str) -> None:
        self.database_path = Path(database_path)
        if str(self.database_path) != ":memory:":
            self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.database_path)

    def _initialize(self) -> None:
        with closing(self._connect()) as db, db:
            db.execute("""
                CREATE TABLE IF NOT EXISTS smr_telemetry (
                    wallet_address TEXT NOT NULL,
                    signature TEXT NOT NULL,
                    detected_at TEXT NOT NULL,
                    analyzed_at TEXT,
                    persisted_at TEXT,
                    event_count INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (wallet_address, signature)
                )
            """)
            db.execute("""
                CREATE TABLE IF NOT EXISTS smr_rpc_usage (
                    id INTEGER PRIMARY KEY,
                    occurred_at TEXT NOT NULL,
                    method TEXT NOT NULL,
                    request_count INTEGER NOT NULL DEFAULT 1,
                    estimated_credits REAL NOT NULL DEFAULT 0
                )
            """)
            db.execute("CREATE INDEX IF NOT EXISTS idx_smr_telemetry_detected ON smr_telemetry(detected_at)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_smr_rpc_occurred ON smr_rpc_usage(occurred_at)")

    def record_detection(self, wallet_address: str, signature: str, at: datetime | None = None) -> None:
        if not wallet_address.strip() or not signature.strip():
            raise ValueError("Carteira e assinatura são obrigatórias para telemetria.")
        stamp = _utc(at).isoformat()
        with closing(self._connect()) as db, db:
            db.execute("""
                INSERT INTO smr_telemetry(wallet_address, signature, detected_at)
                VALUES (?, ?, ?)
                ON CONFLICT(wallet_address, signature) DO NOTHING
            """, (wallet_address, signature, stamp))

    def record_analysis(self, wallet_address: str, signature: str, event_count: int, at: datetime | None = None) -> None:
        if event_count < 0:
            raise ValueError("event_count não pode ser negativo.")
        with closing(self._connect()) as db, db:
            db.execute("""
                UPDATE smr_telemetry SET analyzed_at = ?, event_count = ?
                WHERE wallet_address = ? AND signature = ?
            """, (_utc(at).isoformat(), event_count, wallet_address, signature))

    def record_persisted(self, wallet_address: str, signature: str, at: datetime | None = None) -> None:
        with closing(self._connect()) as db, db:
            db.execute("""
                UPDATE smr_telemetry SET persisted_at = ?
                WHERE wallet_address = ? AND signature = ?
            """, (_utc(at).isoformat(), wallet_address, signature))

    def record_rpc(self, method: str, *, estimated_credits: float = 0, request_count: int = 1, at: datetime | None = None) -> None:
        if not method.strip() or request_count < 1 or estimated_credits < 0:
            raise ValueError("Método, quantidade de chamadas e créditos estimados inválidos.")
        with closing(self._connect()) as db, db:
            db.execute("""
                INSERT INTO smr_rpc_usage(occurred_at, method, request_count, estimated_credits)
                VALUES (?, ?, ?, ?)
            """, (_utc(at).isoformat(), method, request_count, estimated_credits))

    def latency_summary(self) -> dict[str, float | int]:
        with closing(self._connect()) as db:
            rows = db.execute("""
                SELECT detected_at, analyzed_at, persisted_at
                FROM smr_telemetry
                WHERE analyzed_at IS NOT NULL AND persisted_at IS NOT NULL
            """).fetchall()
        detection_to_analysis: list[float] = []
        analysis_to_persist: list[float] = []
        for detected, analyzed, persisted in rows:
            d, a, p = (datetime.fromisoformat(v) for v in (detected, analyzed, persisted))
            detection_to_analysis.append(max(0.0, (a - d).total_seconds() * 1000))
            analysis_to_persist.append(max(0.0, (p - a).total_seconds() * 1000))
        return {
            "completed_events": len(rows),
            "avg_detection_to_analysis_ms": round(sum(detection_to_analysis) / len(rows), 3) if rows else 0.0,
            "avg_analysis_to_persist_ms": round(sum(analysis_to_persist) / len(rows), 3) if rows else 0.0,
        }

    def rpc_usage_summary(self) -> dict[str, float | int]:
        with closing(self._connect()) as db:
            row = db.execute("""
                SELECT COALESCE(SUM(request_count), 0),
                       COALESCE(SUM(estimated_credits), 0)
                FROM smr_rpc_usage
            """).fetchone()
        return {"requests": int(row[0]), "estimated_credits": round(float(row[1]), 6)}
