import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from smart_money_radar.storage.telemetry_store import TelemetryStore


class TelemetryStoreTests(unittest.TestCase):
    def test_records_pipeline_milestones_and_latency(self):
        with tempfile.TemporaryDirectory() as directory:
            store = TelemetryStore(Path(directory) / "telemetry.sqlite3")
            base = datetime(2026, 11, 16, 5, 0, tzinfo=timezone.utc)
            store.record_detection("wallet", "sig", base)
            store.record_analysis("wallet", "sig", 2, base.replace(second=0, microsecond=120000))
            store.record_persisted("wallet", "sig", base.replace(second=0, microsecond=170000))
            self.assertEqual(store.latency_summary(), {
                "completed_events": 1,
                "avg_detection_to_analysis_ms": 120.0,
                "avg_analysis_to_persist_ms": 50.0,
            })

    def test_tracks_estimated_rpc_usage_without_credentials(self):
        with tempfile.TemporaryDirectory() as directory:
            store = TelemetryStore(Path(directory) / "telemetry.sqlite3")
            store.record_rpc("getTransaction", estimated_credits=2.5, request_count=3)
            self.assertEqual(store.rpc_usage_summary(), {"requests": 3, "estimated_credits": 2.5})

    def test_rejects_naive_timestamps(self):
        with tempfile.TemporaryDirectory() as directory:
            store = TelemetryStore(Path(directory) / "telemetry.sqlite3")
            with self.assertRaisesRegex(ValueError, "fuso horário"):
                store.record_detection("wallet", "sig", datetime(2026, 11, 16))


if __name__ == "__main__":
    unittest.main()
