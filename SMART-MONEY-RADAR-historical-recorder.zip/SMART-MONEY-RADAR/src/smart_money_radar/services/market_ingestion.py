"""Validação de qualidade e ingestão offline de snapshots de mercado."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Iterable

from smart_money_radar.data_sources.market_feed import MarketDataSnapshot
from smart_money_radar.storage.market_data_store import SQLiteMarketDataStore
from smart_money_radar.storage.historical_data_recorder import SQLiteHistoricalDataRecorder


@dataclass(frozen=True)
class MarketIngestionResult:
    received: int
    accepted: int
    inserted: int
    rejected: tuple[tuple[str, str], ...]


class MarketDataIngestor:
    """Aplica controles de frescor e vínculo pool-token antes de persistir."""

    def __init__(self, store: SQLiteMarketDataStore, *, max_age: timedelta = timedelta(minutes=3), future_tolerance: timedelta = timedelta(seconds=30), historical_recorder: SQLiteHistoricalDataRecorder | None = None):
        if max_age <= timedelta(0) or future_tolerance < timedelta(0):
            raise ValueError("limites temporais inválidos")
        self.store = store
        self.max_age = max_age
        self.future_tolerance = future_tolerance
        self.historical_recorder = historical_recorder

    def ingest(self, snapshots: Iterable[MarketDataSnapshot], *, known_pool_tokens: dict[str, set[str]], now: datetime | None = None) -> MarketIngestionResult:
        current = now or datetime.now(timezone.utc)
        if current.tzinfo is None or current.utcoffset() is None:
            raise ValueError("now precisa conter fuso horário")
        received = accepted = inserted = 0
        rejected: list[tuple[str, str]] = []
        for item in snapshots:
            received += 1
            pool_tokens = known_pool_tokens.get(item.pool_address)
            reason = None
            if pool_tokens is None:
                reason = "pool_desconhecido"
            elif item.token_mint not in pool_tokens or item.quote_mint not in pool_tokens:
                reason = "mints_nao_correspondem_ao_pool"
            elif item.observed_at > current + self.future_tolerance:
                reason = "timestamp_no_futuro"
            elif current - item.observed_at > self.max_age:
                reason = "snapshot_desatualizado"
            if reason:
                rejected.append((item.pool_address, reason))
                continue
            accepted += 1
            inserted += int(self.store.save(item))
            if self.historical_recorder is not None:
                self.historical_recorder.record_snapshot(item, recorded_at=current)
        return MarketIngestionResult(received, accepted, inserted, tuple(rejected))
