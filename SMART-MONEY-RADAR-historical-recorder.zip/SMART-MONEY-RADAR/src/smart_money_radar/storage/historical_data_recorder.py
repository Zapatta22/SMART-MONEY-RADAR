"""Registro append-only de evidências históricas com corte temporal point-in-time."""
from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import closing
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterable

from smart_money_radar.data_sources.market_feed import MarketDataSnapshot


def _aware(value: datetime, name: str) -> None:
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError(f"{name} precisa conter fuso horário")


@dataclass(frozen=True)
class HistoricalRecord:
    record_type: str
    entity_key: str
    source: str
    observed_at: datetime
    recorded_at: datetime
    payload: dict[str, Any]


@dataclass(frozen=True)
class HistoryQuality:
    records: int
    expected_intervals: int
    missing_intervals: int
    coverage_pct: Decimal


class SQLiteHistoricalDataRecorder:
    """Persiste snapshots e sinais sem sobrescrever evidências anteriores.

    `recorded_at` representa quando o SMR efetivamente conheceu o dado. Consultas
    point-in-time usam esse campo, evitando look-ahead em backtests.
    """
    def __init__(self, database: str | Path):
        self.database = str(database)
        if self.database != ':memory:':
            Path(self.database).parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(self.database)) as conn, conn:
            conn.execute('''CREATE TABLE IF NOT EXISTS historical_records (
                id INTEGER PRIMARY KEY, record_type TEXT NOT NULL, entity_key TEXT NOT NULL,
                source TEXT NOT NULL, observed_at TEXT NOT NULL, recorded_at TEXT NOT NULL,
                payload TEXT NOT NULL, fingerprint TEXT NOT NULL UNIQUE)''')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_history_entity_time ON historical_records(record_type, entity_key, observed_at)')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_history_known_time ON historical_records(recorded_at)')

    def record(self, record_type: str, entity_key: str, source: str, observed_at: datetime,
               payload: dict[str, Any], *, recorded_at: datetime | None = None) -> bool:
        for name, value in (("record_type", record_type), ("entity_key", entity_key), ("source", source)):
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} obrigatório")
        _aware(observed_at, 'observed_at')
        known_at = recorded_at or datetime.now(timezone.utc)
        _aware(known_at, 'recorded_at')
        # Pequena diferença de relógio é permitida pelo ingestor; recorded_at
        # continua sendo a barreira point-in-time de quando o SMR conheceu o dado.
        if not isinstance(payload, dict):
            raise ValueError('payload precisa ser um objeto')
        encoded = json.dumps(payload, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
        canonical = '|'.join((record_type, entity_key, source, observed_at.isoformat(), encoded))
        fingerprint = hashlib.sha256(canonical.encode()).hexdigest()
        with closing(sqlite3.connect(self.database)) as conn, conn:
            cur = conn.execute('''INSERT OR IGNORE INTO historical_records
                (record_type,entity_key,source,observed_at,recorded_at,payload,fingerprint)
                VALUES (?,?,?,?,?,?,?)''', (record_type, entity_key, source, observed_at.isoformat(),
                known_at.isoformat(), encoded, fingerprint))
            return cur.rowcount == 1

    def record_snapshot(self, snapshot: MarketDataSnapshot, *, recorded_at: datetime | None = None) -> bool:
        payload = {name: (str(value) if isinstance(value, Decimal) else value) for name, value in {
            'pool_address': snapshot.pool_address, 'token_mint': snapshot.token_mint,
            'quote_mint': snapshot.quote_mint, 'price_quote': snapshot.price_quote,
            'volume_24h_quote': snapshot.volume_24h_quote, 'liquidity_quote': snapshot.liquidity_quote,
            'buys_24h': snapshot.buys_24h, 'sells_24h': snapshot.sells_24h,
            'price_usd': snapshot.price_usd, 'volume_24h_usd': snapshot.volume_24h_usd,
            'liquidity_usd': snapshot.liquidity_usd}.items()}
        return self.record('market_snapshot', snapshot.pool_address, snapshot.source,
                           snapshot.observed_at, payload, recorded_at=recorded_at)

    def record_signal(self, signal_type: str, entity_key: str, source: str,
                      observed_at: datetime, payload: dict[str, Any], *,
                      recorded_at: datetime | None = None) -> bool:
        return self.record(f'signal:{signal_type}', entity_key, source, observed_at,
                           payload, recorded_at=recorded_at)

    def query_as_of(self, *, record_type: str, entity_key: str, as_of: datetime,
                    limit: int = 1000) -> tuple[HistoricalRecord, ...]:
        _aware(as_of, 'as_of')
        if not 1 <= limit <= 100000:
            raise ValueError('limit deve estar entre 1 e 100000')
        with closing(sqlite3.connect(self.database)) as conn:
            rows = conn.execute('''SELECT record_type,entity_key,source,observed_at,recorded_at,payload
                FROM historical_records WHERE record_type=? AND entity_key=? AND recorded_at<=?
                ORDER BY observed_at DESC, id DESC LIMIT ?''',
                (record_type, entity_key, as_of.isoformat(), limit)).fetchall()
        return tuple(HistoricalRecord(row[0], row[1], row[2], datetime.fromisoformat(row[3]),
            datetime.fromisoformat(row[4]), json.loads(row[5])) for row in rows)

    def quality(self, *, record_type: str, entity_key: str, start: datetime,
                end: datetime, expected_interval: timedelta) -> HistoryQuality:
        _aware(start, 'start'); _aware(end, 'end')
        if end <= start or expected_interval.total_seconds() <= 0:
            raise ValueError('janela e intervalo precisam ser positivos')
        with closing(sqlite3.connect(self.database)) as conn:
            rows = conn.execute('''SELECT observed_at FROM historical_records
                WHERE record_type=? AND entity_key=? AND observed_at>=? AND observed_at<=?
                ORDER BY observed_at''', (record_type, entity_key, start.isoformat(), end.isoformat())).fetchall()
        stamps = sorted({datetime.fromisoformat(row[0]) for row in rows})
        expected = max(1, int((end - start).total_seconds() // expected_interval.total_seconds()) + 1)
        # Missing cadence slots, bounded at zero; duplicate timestamps count once.
        missing = max(0, expected - len(stamps))
        coverage = Decimal(max(0, expected - missing)) / Decimal(expected) * 100
        return HistoryQuality(len(stamps), expected, missing, coverage)
