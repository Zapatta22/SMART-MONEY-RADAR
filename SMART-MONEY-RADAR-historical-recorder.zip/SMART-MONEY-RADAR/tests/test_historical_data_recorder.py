import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from smart_money_radar.storage.historical_data_recorder import SQLiteHistoricalDataRecorder
from smart_money_radar.data_sources.market_feed import MarketDataSnapshot

T = datetime(2026, 1, 1, tzinfo=timezone.utc)

class HistoricalRecorderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.rec = SQLiteHistoricalDataRecorder(Path(self.tmp.name) / 'history.db')
    def tearDown(self): self.tmp.cleanup()
    def snap(self, minute=0):
        return MarketDataSnapshot('feed-a','pool','mint','quote',T+timedelta(minutes=minute),Decimal('2'))
    def test_records_snapshot_idempotently(self):
        self.assertTrue(self.rec.record_snapshot(self.snap(), recorded_at=T))
        self.assertFalse(self.rec.record_snapshot(self.snap(), recorded_at=T))
    def test_point_in_time_excludes_later_known_data(self):
        self.rec.record_snapshot(self.snap(1), recorded_at=T+timedelta(minutes=2))
        self.assertEqual(self.rec.query_as_of(record_type='market_snapshot',entity_key='pool',as_of=T+timedelta(minutes=1)),())
        self.assertEqual(len(self.rec.query_as_of(record_type='market_snapshot',entity_key='pool',as_of=T+timedelta(minutes=2))),1)
    def test_signal_history(self):
        self.rec.record_signal('whale_buy','mint','wallet-monitor',T,{'wallet':'w','score':88},recorded_at=T)
        self.assertEqual(self.rec.query_as_of(record_type='signal:whale_buy',entity_key='mint',as_of=T)[0].payload['score'],88)
    def test_quality_detects_missing_intervals(self):
        for m in (0,1,3): self.rec.record_snapshot(self.snap(m),recorded_at=T+timedelta(minutes=m))
        q=self.rec.quality(record_type='market_snapshot',entity_key='pool',start=T,end=T+timedelta(minutes=3),expected_interval=timedelta(minutes=1))
        self.assertEqual(q.missing_intervals,1); self.assertEqual(q.coverage_pct,Decimal('75'))
    def test_rejects_future_observation_and_naive_time(self):
        self.assertTrue(self.rec.record('x','y','z',T+timedelta(seconds=1),{},recorded_at=T))
        with self.assertRaises(ValueError): self.rec.record('x','y','z',datetime(2026,1,1),{},recorded_at=T)
    def test_invalid_quality_window(self):
        with self.assertRaises(ValueError): self.rec.quality(record_type='x',entity_key='y',start=T,end=T,expected_interval=timedelta(seconds=1))

if __name__ == '__main__': unittest.main()
