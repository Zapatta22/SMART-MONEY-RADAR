"""Histórico auditável de cada ciclo do Market Radar (SQLite)."""
from __future__ import annotations
import json
import sqlite3
from contextlib import closing
from datetime import datetime
from pathlib import Path
from typing import Any


class SQLiteMarketPollingCycleStore:
    def __init__(self, database: str | Path):
        self.database = str(database)
        if self.database != ':memory:':
            Path(self.database).parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(self.database)) as con, con:
            con.execute('''CREATE TABLE IF NOT EXISTS market_polling_cycles (
                cycle_id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at TEXT NOT NULL, completed_at TEXT NOT NULL,
                duration_ms INTEGER NOT NULL, force_refresh INTEGER NOT NULL,
                requested_pools INTEGER NOT NULL, fetched_snapshots INTEGER NOT NULL,
                cached_pools INTEGER NOT NULL, failed_pools INTEGER NOT NULL,
                ingestion_received INTEGER NOT NULL, ingestion_accepted INTEGER NOT NULL,
                ingestion_inserted INTEGER NOT NULL, failed_details_json TEXT NOT NULL,
                rejected_details_json TEXT NOT NULL
            )''')
            con.execute('CREATE INDEX IF NOT EXISTS idx_market_cycles_completed ON market_polling_cycles(completed_at)')

    def record(self, *, started_at: datetime, completed_at: datetime, force_refresh: bool,
               requested_pools: int, fetched_snapshots: int, cached_pools: int,
               failed_details: tuple[tuple[str, str], ...], ingestion: Any) -> int:
        duration = max(0, int((completed_at - started_at).total_seconds() * 1000))
        with closing(sqlite3.connect(self.database)) as con, con:
            cur = con.execute('''INSERT INTO market_polling_cycles (
                started_at,completed_at,duration_ms,force_refresh,requested_pools,
                fetched_snapshots,cached_pools,failed_pools,ingestion_received,
                ingestion_accepted,ingestion_inserted,failed_details_json,rejected_details_json
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)''', (
                started_at.isoformat(), completed_at.isoformat(), duration, int(force_refresh),
                requested_pools, fetched_snapshots, cached_pools, len(failed_details),
                ingestion.received, ingestion.accepted, ingestion.inserted,
                json.dumps(failed_details, ensure_ascii=False),
                json.dumps(ingestion.rejected, ensure_ascii=False),
            ))
            return int(cur.lastrowid)

    def list_recent(self, limit: int = 100) -> tuple[dict[str, Any], ...]:
        if not 1 <= limit <= 10000:
            raise ValueError('limit deve ficar entre 1 e 10000')
        with closing(sqlite3.connect(self.database)) as con:
            con.row_factory = sqlite3.Row
            rows = con.execute('SELECT * FROM market_polling_cycles ORDER BY cycle_id DESC LIMIT ?', (limit,)).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item['failed_details'] = json.loads(item.pop('failed_details_json'))
            item['rejected_details'] = json.loads(item.pop('rejected_details_json'))
            result.append(item)
        return tuple(result)
