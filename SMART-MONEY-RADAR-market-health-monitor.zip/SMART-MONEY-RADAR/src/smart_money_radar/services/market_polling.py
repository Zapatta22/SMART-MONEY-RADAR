"""Orquestração de consultas periódicas com cache e limite local de taxa.

Somente leitura: recebe pools já conhecidos, consulta o feed e entrega os
snapshots ao validador/armazenamento. Não cria ordens nem descobre pools.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from time import monotonic, sleep
from typing import Callable, Mapping, Sequence

from smart_money_radar.data_sources.market_feed import MarketDataFeed, MarketDataSnapshot
from smart_money_radar.services.market_ingestion import MarketDataIngestor, MarketIngestionResult
from smart_money_radar.storage.market_polling_cycle_store import SQLiteMarketPollingCycleStore


@dataclass(frozen=True)
class MarketPollingResult:
    requested_pools: int
    fetched_snapshots: int
    cached_pools: int
    failed_pools: tuple[tuple[str, str], ...]
    ingestion: MarketIngestionResult


class MarketPollingService:
    """Consulta pools conhecidos com cache TTL e espaçamento entre requests.

    `requests_per_minute` é um teto local conservador. O espaçamento é aplicado
    entre chamadas individuais ao provedor, inclusive quando fetch consulta
    vários pools sequencialmente.
    """
    def __init__(
        self,
        feed: MarketDataFeed,
        ingestor: MarketDataIngestor,
        *,
        requests_per_minute: int = 240,
        cache_ttl: timedelta = timedelta(seconds=20),
        clock: Callable[[], float] = monotonic,
        sleeper: Callable[[float], None] = sleep,
        utcnow: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
        cycle_store: SQLiteMarketPollingCycleStore | None = None,
    ) -> None:
        if not 1 <= requests_per_minute <= 300:
            raise ValueError("requests_per_minute deve ficar entre 1 e 300")
        if cache_ttl < timedelta(0):
            raise ValueError("cache_ttl não pode ser negativo")
        self.feed = feed
        self.ingestor = ingestor
        self.interval = 60.0 / requests_per_minute
        self.cache_ttl = cache_ttl
        self.clock = clock
        self.sleeper = sleeper
        self.utcnow = utcnow
        self.cycle_store = cycle_store or SQLiteMarketPollingCycleStore(ingestor.store.database)
        self._last_request_at: float | None = None
        self._cache: dict[str, tuple[float, tuple[MarketDataSnapshot, ...]]] = {}

    def _wait_turn(self) -> None:
        now = self.clock()
        if self._last_request_at is not None:
            remaining = self.interval - (now - self._last_request_at)
            if remaining > 0:
                self.sleeper(remaining)
        self._last_request_at = self.clock()

    def poll_once(
        self,
        pool_tokens: Mapping[str, set[str]],
        *,
        force_refresh: bool = False,
    ) -> MarketPollingResult:
        """Consulta e ingere os pools; `pool_tokens` mapeia pool para seus mints."""
        normalized: dict[str, set[str]] = {}
        for pool, mints in pool_tokens.items():
            if not isinstance(pool, str) or not pool.strip():
                raise ValueError("endereço de pool inválido")
            token_set = set(mints)
            if len(token_set) < 2 or any(not isinstance(m, str) or not m.strip() for m in token_set):
                raise ValueError(f"pool {pool} precisa ter pelo menos dois mints válidos")
            normalized[pool] = token_set

        cycle_started = self.utcnow()
        now_mono = self.clock()
        snapshots: list[MarketDataSnapshot] = []
        failed: list[tuple[str, str]] = []
        cached = 0
        for pool in normalized:
            cached_entry = self._cache.get(pool)
            if (not force_refresh and cached_entry is not None
                    and now_mono - cached_entry[0] <= self.cache_ttl.total_seconds()):
                snapshots.extend(cached_entry[1])
                cached += 1
                continue
            try:
                self._wait_turn()
                fresh = tuple(self.feed.fetch([pool]))
                # Só armazenar no cache se a fonte retornou um snapshot para este pool.
                if fresh:
                    self._cache[pool] = (self.clock(), fresh)
                else:
                    self._cache.pop(pool, None)
                snapshots.extend(fresh)
            except Exception as exc:  # falha isolada por pool; os demais continuam
                failed.append((pool, f"{type(exc).__name__}: {exc}"))

        ingested = self.ingestor.ingest(
            snapshots,
            known_pool_tokens=normalized,
            now=self.utcnow(),
        )
        cycle_completed = self.utcnow()
        self.cycle_store.record(
            started_at=cycle_started, completed_at=cycle_completed,
            force_refresh=force_refresh, requested_pools=len(normalized),
            fetched_snapshots=len(snapshots), cached_pools=cached,
            failed_details=tuple(failed), ingestion=ingested,
        )
        return MarketPollingResult(
            requested_pools=len(normalized), fetched_snapshots=len(snapshots),
            cached_pools=cached, failed_pools=tuple(failed), ingestion=ingested,
        )

    def clear_cache(self, pool_address: str | None = None) -> None:
        """Limpa o cache de um pool ou todo o cache local."""
        if pool_address is None:
            self._cache.clear()
        else:
            self._cache.pop(pool_address, None)
