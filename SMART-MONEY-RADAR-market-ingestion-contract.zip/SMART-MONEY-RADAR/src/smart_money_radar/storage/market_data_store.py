"""Persistência idempotente de snapshots normalizados com proveniência."""
from __future__ import annotations

import sqlite3
from contextlib import closing
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from smart_money_radar.data_sources.market_feed import MarketDataSnapshot


class SQLiteMarketDataStore:
    def __init__(self, database: str | Path):
        self.database = str(database)
        if self.database != ":memory:":
            Path(self.database).parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(self.database)) as connection, connection:
            connection.execute("""CREATE TABLE IF NOT EXISTS market_data_snapshots (
                source TEXT NOT NULL, pool_address TEXT NOT NULL,
                token_mint TEXT NOT NULL, quote_mint TEXT NOT NULL,
                observed_at TEXT NOT NULL, price_quote TEXT NOT NULL,
                volume_24h_quote TEXT, liquidity_quote TEXT,
                buys_24h INTEGER, sells_24h INTEGER,
                PRIMARY KEY(source, pool_address, token_mint, quote_mint, observed_at)
            )""")
            connection.execute("CREATE INDEX IF NOT EXISTS idx_market_snapshots_mint_time ON market_data_snapshots(token_mint, observed_at)")
            connection.execute("CREATE INDEX IF NOT EXISTS idx_market_snapshots_pool_time ON market_data_snapshots(pool_address, observed_at)")

    def save(self, snapshot: MarketDataSnapshot) -> bool:
        values = (
            snapshot.source, snapshot.pool_address, snapshot.token_mint,
            snapshot.quote_mint, snapshot.observed_at.isoformat(),
            str(snapshot.price_quote),
            str(snapshot.volume_24h_quote) if snapshot.volume_24h_quote is not None else None,
            str(snapshot.liquidity_quote) if snapshot.liquidity_quote is not None else None,
            snapshot.buys_24h, snapshot.sells_24h,
        )
        with closing(sqlite3.connect(self.database)) as connection, connection:
            cursor = connection.execute("INSERT OR IGNORE INTO market_data_snapshots VALUES (?,?,?,?,?,?,?,?,?,?)", values)
            return cursor.rowcount == 1

    def load(self, token_mint: str | None = None, limit: int = 1000) -> tuple[MarketDataSnapshot, ...]:
        if not 1 <= limit <= 100000:
            raise ValueError("limit deve estar entre 1 e 100000")
        sql = "SELECT source,pool_address,token_mint,quote_mint,observed_at,price_quote,volume_24h_quote,liquidity_quote,buys_24h,sells_24h FROM market_data_snapshots"
        args: list[object] = []
        if token_mint is not None:
            if not token_mint.strip():
                raise ValueError("token_mint não pode estar vazio")
            sql += " WHERE token_mint=?"
            args.append(token_mint)
        sql += " ORDER BY observed_at DESC LIMIT ?"
        args.append(limit)
        with closing(sqlite3.connect(self.database)) as connection:
            rows = connection.execute(sql, args).fetchall()
        return tuple(MarketDataSnapshot(
            source=row[0], pool_address=row[1], token_mint=row[2], quote_mint=row[3],
            observed_at=datetime.fromisoformat(row[4]), price_quote=Decimal(row[5]),
            volume_24h_quote=Decimal(row[6]) if row[6] is not None else None,
            liquidity_quote=Decimal(row[7]) if row[7] is not None else None,
            buys_24h=row[8], sells_24h=row[9],
        ) for row in rows)
