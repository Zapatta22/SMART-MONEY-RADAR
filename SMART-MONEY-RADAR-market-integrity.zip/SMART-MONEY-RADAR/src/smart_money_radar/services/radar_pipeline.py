"""Orquestração offline dos radares Launch/Market para o Decision Engine.

As classes recebem candidatos já enriquecidos. Elas não descobrem tokens,
não consultam RPC/DEX e não executam ordens; essa separação permite validar
os pipelines antes de ligar fontes externas.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Iterable

from smart_money_radar.data_sources.candidate_feed import CandidateFeed, RadarKind
from smart_money_radar.data_sources.market_feed import MarketDataSnapshot
from smart_money_radar.analysis.market_data_integrity import MarketDataIntegrityAnalyzer, MarketIntegrityFinding

from smart_money_radar.analysis.decision_engine import (
    DecisionCandidate, DecisionPolicy, DecisionResult, DecisionStatus, EntryMode, evaluate_candidate,
)
from smart_money_radar.storage.decision_store import SQLiteDecisionStore


@dataclass(frozen=True)
class RadarEvaluation:
    radar: RadarKind
    result: DecisionResult
    persisted: bool


class _BaseRadar:
    """Pipeline independente; compartilha somente política e motor de decisão."""
    kind: RadarKind

    def __init__(self, policy: DecisionPolicy | None = None):
        self.policy = policy or DecisionPolicy()

    def evaluate(self, candidates: Iterable[DecisionCandidate], mode: EntryMode | str,
                 store: SQLiteDecisionStore, *,
                 blocked_token_mints: frozenset[str] = frozenset()) -> tuple[RadarEvaluation, ...]:
        output = []
        for candidate in candidates:
            result = evaluate_candidate(candidate, mode, self.policy)
            if candidate.token_mint in blocked_token_mints:
                result = replace(
                    result, status=DecisionStatus.BLOCKED,
                    reasons=result.reasons + ("market_feed_watchdog:pool_desatualizado_ou_anormal",),
                )
            output.append(RadarEvaluation(self.kind, result, store.save(result)))
        return tuple(output)


class LaunchRadar(_BaseRadar):
    """Fluxo destinado a tokens recém-lançados; exige dados completos no candidato."""
    kind = RadarKind.LAUNCH


class MarketRadar(_BaseRadar):
    """Fluxo destinado a tokens já negociados; isolado do Launch Radar."""
    kind = RadarKind.MARKET


class RadarCoordinator:
    """Executa os dois radares sem misturar suas filas de candidatos."""
    def __init__(self, store: SQLiteDecisionStore,
                 policy: DecisionPolicy | None = None):
        self.store = store
        self.launch_radar = LaunchRadar(policy)
        self.market_radar = MarketRadar(policy)

    def evaluate_launch(self, candidates: Iterable[DecisionCandidate],
                        mode: EntryMode | str) -> tuple[RadarEvaluation, ...]:
        return self.launch_radar.evaluate(candidates, mode, self.store)

    def evaluate_market(self, candidates: Iterable[DecisionCandidate],
                        mode: EntryMode | str, *,
                        blocked_token_mints: frozenset[str] = frozenset()) -> tuple[RadarEvaluation, ...]:
        """Avalia somente tokens cujo feed não foi bloqueado pelo watchdog.

        O chamador converte pools não saudáveis em seus mints e os fornece aqui.
        Sem essa lista explícita, mantém compatibilidade com simulações antigas.
        """
        return self.market_radar.evaluate(candidates, mode, self.store,
                                          blocked_token_mints=blocked_token_mints)

    def evaluate_market_with_integrity(self, candidates: Iterable[DecisionCandidate],
                                       mode: EntryMode | str,
                                       snapshots: Iterable[MarketDataSnapshot], *,
                                       analyzer: MarketDataIntegrityAnalyzer | None = None
                                       ) -> tuple[tuple[RadarEvaluation, ...], tuple[MarketIntegrityFinding, ...]]:
        """Audita fontes independentes e bloqueia mints com divergência material."""
        auditor = analyzer or MarketDataIntegrityAnalyzer()
        findings = auditor.analyze(snapshots)
        blocked = auditor.blocked_token_mints(findings)
        evaluations = self.evaluate_market(candidates, mode, blocked_token_mints=blocked)
        return evaluations, findings

    def ingest_and_evaluate(self, feed: CandidateFeed, radar: RadarKind | str,
                            mode: EntryMode | str) -> tuple[RadarEvaluation, ...]:
        """Lê um lote do feed e o encaminha apenas ao pipeline solicitado.

        O feed é somente de leitura. Esta operação não descobre dados por si só,
        não faz chamadas externas e não executa ordens.
        """
        selected = RadarKind(radar)
        batch = feed.fetch(selected)
        if batch.radar is not selected:
            raise ValueError("O feed retornou lote de um radar diferente do solicitado.")
        if selected is RadarKind.LAUNCH:
            return self.evaluate_launch(batch.candidates, mode)
        return self.evaluate_market(batch.candidates, mode)
