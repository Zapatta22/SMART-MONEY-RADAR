import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal as D
from pathlib import Path

from smart_money_radar.analysis.decision_engine import DecisionCandidate, DecisionStatus
from smart_money_radar.data_sources.candidate_feed import RadarKind
from smart_money_radar.services.radar_pipeline import RadarCoordinator
from smart_money_radar.storage.decision_store import SQLiteDecisionStore


class RadarPipelineTests(unittest.TestCase):
    def candidate(self, candidate_id="c-1", safety_checks=None):
        now = datetime(2026, 11, 16, 12, 0, tzinfo=timezone.utc)
        return DecisionCandidate(
            candidate_id=candidate_id, token_mint="mint-" + candidate_id,
            detected_at=now - timedelta(seconds=1), evaluated_at=now,
            current_price=D("1.05"), price_at_detection=D("1"),
            liquidity_quote=D("50000"), current_volume_quote=D("3000"),
            baseline_volume_quote=D("1000"), realized_volatility=D("0.04"),
            smart_money_score=85,
            safety_checks=safety_checks or {"mint_authority_disabled": True,
                "freeze_authority_disabled": True, "liquidity_lock_verified": True,
                "honeypot_check": True},
        )

    def test_launch_and_market_are_independent_and_share_engine(self):
        with tempfile.TemporaryDirectory() as directory:
            store = SQLiteDecisionStore(Path(directory) / "audit.sqlite")
            coordinator = RadarCoordinator(store)
            launch = coordinator.evaluate_launch([self.candidate("launch-1")], "immediate")
            market = coordinator.evaluate_market([self.candidate("market-1")], "confirmed")
            self.assertEqual(launch[0].radar, RadarKind.LAUNCH)
            self.assertEqual(market[0].radar, RadarKind.MARKET)
            self.assertEqual(launch[0].result.status, DecisionStatus.APPROVED_FOR_SIMULATION)
            self.assertEqual(market[0].result.status, DecisionStatus.APPROVED_FOR_SIMULATION)
            self.assertEqual(len(store.list()), 2)

    def test_safety_block_applies_to_both_radar_pipelines(self):
        with tempfile.TemporaryDirectory() as directory:
            coordinator = RadarCoordinator(SQLiteDecisionStore(Path(directory) / "audit.sqlite"))
            unsafe = self.candidate("unsafe", safety_checks={
                "mint_authority_disabled": False, "freeze_authority_disabled": True,
                "liquidity_lock_verified": True, "honeypot_check": True})
            launch = coordinator.evaluate_launch([unsafe], "immediate")[0]
            market = coordinator.evaluate_market([unsafe], "confirmed")[0]
            self.assertEqual(launch.result.status, DecisionStatus.BLOCKED)
            self.assertEqual(market.result.status, DecisionStatus.BLOCKED)
            self.assertEqual(launch.result.reasons, market.result.reasons)

    def test_watchdog_quality_gate_blocks_market_candidate(self):
        with tempfile.TemporaryDirectory() as directory:
            coordinator = RadarCoordinator(SQLiteDecisionStore(Path(directory) / "audit.sqlite"))
            candidate = self.candidate("pool-risk")
            result = coordinator.evaluate_market(
                [candidate], "immediate", blocked_token_mints=frozenset({candidate.token_mint})
            )[0]
            self.assertEqual(result.result.status, DecisionStatus.BLOCKED)
            self.assertIn("market_feed_watchdog:pool_desatualizado_ou_anormal", result.result.reasons)

    def test_empty_radar_returns_no_evaluations(self):
        with tempfile.TemporaryDirectory() as directory:
            coordinator = RadarCoordinator(SQLiteDecisionStore(Path(directory) / "audit.sqlite"))
            self.assertEqual(coordinator.evaluate_launch([], "immediate"), ())
            self.assertEqual(coordinator.evaluate_market([], "confirmed"), ())


if __name__ == "__main__":
    unittest.main()
