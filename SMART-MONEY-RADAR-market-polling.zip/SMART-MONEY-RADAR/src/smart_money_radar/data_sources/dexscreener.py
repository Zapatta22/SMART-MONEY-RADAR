"""Adaptador somente leitura para dados de pools da API pública DexScreener."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Callable, Sequence
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from smart_money_radar.data_sources.market_feed import MarketDataSnapshot


class DexScreenerError(RuntimeError):
    """Erro de transporte ou de formato da API DexScreener."""


class DexScreenerFeed:
    """Consulta detalhes de pools Solana conhecidos, sem enviar transações.

    `opener` é injetável para testes. O adaptador não descobre tokens nem pools:
    recebe endereços de pools previamente conhecidos pelo SMR.
    """
    BASE_URL = "https://api.dexscreener.com/latest/dex/pairs"
    SOURCE = "dexscreener"

    def __init__(self, *, timeout: float = 8.0, opener: Callable = urlopen):
        if timeout <= 0:
            raise ValueError("timeout precisa ser positivo")
        self.timeout = timeout
        self.opener = opener

    @staticmethod
    def _decimal(value: object, field: str, *, optional: bool = False) -> Decimal | None:
        if value is None and optional:
            return None
        try:
            result = Decimal(str(value))
        except (InvalidOperation, ValueError, TypeError) as exc:
            raise DexScreenerError(f"campo numérico inválido: {field}") from exc
        if not result.is_finite():
            raise DexScreenerError(f"campo numérico não finito: {field}")
        return result

    def _get_json(self, url: str) -> object:
        request = Request(url, headers={"Accept": "application/json", "User-Agent": "SMART-MONEY-RADAR/0.1"})
        try:
            with self.opener(request, timeout=self.timeout) as response:
                status = getattr(response, "status", 200)
                if status != 200:
                    raise DexScreenerError(f"HTTP inesperado: {status}")
                return json.loads(response.read().decode("utf-8"))
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            raise DexScreenerError(f"falha ao consultar DexScreener: {exc}") from exc
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise DexScreenerError("resposta JSON inválida da DexScreener") from exc

    def fetch(self, pool_addresses: Sequence[str]) -> tuple[MarketDataSnapshot, ...]:
        snapshots: list[MarketDataSnapshot] = []
        for pool in dict.fromkeys(pool_addresses):
            if not isinstance(pool, str) or not pool.strip():
                raise ValueError("pool address inválido")
            payload = self._get_json(f"{self.BASE_URL}/solana/{pool}")
            if not isinstance(payload, dict):
                raise DexScreenerError("resposta de par precisa ser um objeto")
            pairs = payload.get("pairs")
            if pairs is None:
                continue
            if not isinstance(pairs, list):
                raise DexScreenerError("campo pairs precisa ser uma lista")
            for pair in pairs:
                if not isinstance(pair, dict):
                    continue
                if pair.get("chainId") != "solana" or pair.get("pairAddress") != pool:
                    continue
                base, quote = pair.get("baseToken"), pair.get("quoteToken")
                if not isinstance(base, dict) or not isinstance(quote, dict):
                    continue
                base_mint, quote_mint = base.get("address"), quote.get("address")
                if not isinstance(base_mint, str) or not isinstance(quote_mint, str) or not base_mint or not quote_mint:
                    continue
                price_native = self._decimal(pair.get("priceNative"), "priceNative")
                if price_native is None or price_native <= 0:
                    continue
                volume = pair.get("volume") if isinstance(pair.get("volume"), dict) else {}
                liquidity = pair.get("liquidity") if isinstance(pair.get("liquidity"), dict) else {}
                txns = pair.get("txns") if isinstance(pair.get("txns"), dict) else {}
                h24 = txns.get("h24") if isinstance(txns.get("h24"), dict) else {}
                observed_at = datetime.now(timezone.utc)
                snapshots.append(MarketDataSnapshot(
                    source=self.SOURCE, pool_address=pool,
                    token_mint=base_mint, quote_mint=quote_mint,
                    observed_at=observed_at, price_quote=price_native,
                    buys_24h=self._optional_count(h24.get("buys")),
                    sells_24h=self._optional_count(h24.get("sells")),
                    price_usd=self._decimal(pair.get("priceUsd"), "priceUsd", optional=True),
                    volume_24h_usd=self._decimal(volume.get("h24"), "volume.h24", optional=True),
                    liquidity_usd=self._decimal(liquidity.get("usd"), "liquidity.usd", optional=True),
                ))
        return tuple(snapshots)

    @staticmethod
    def _optional_count(value: object) -> int | None:
        if value is None:
            return None
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            return None
        return value
