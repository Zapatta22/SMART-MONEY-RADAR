"""Contrato e modelo normalizado para snapshots de mercado recebidos de feeds.

Este módulo não consulta provedores. Adaptadores externos devem converter suas
respostas para MarketDataSnapshot antes de entregá-las ao pipeline.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Protocol, Sequence


@dataclass(frozen=True)
class MarketDataSnapshot:
    source: str
    pool_address: str
    token_mint: str
    quote_mint: str
    observed_at: datetime
    price_quote: Decimal
    volume_24h_quote: Decimal | None = None
    liquidity_quote: Decimal | None = None
    buys_24h: int | None = None
    sells_24h: int | None = None
    price_usd: Decimal | None = None
    volume_24h_usd: Decimal | None = None
    liquidity_usd: Decimal | None = None

    def __post_init__(self) -> None:
        for name in ("source", "pool_address", "token_mint", "quote_mint"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} é obrigatório")
        if self.token_mint == self.quote_mint:
            raise ValueError("token_mint e quote_mint precisam ser diferentes")
        if self.observed_at.tzinfo is None or self.observed_at.utcoffset() is None:
            raise ValueError("observed_at precisa conter fuso horário")
        if not self.price_quote.is_finite() or self.price_quote <= 0:
            raise ValueError("price_quote precisa ser positivo e finito")
        for name in ("volume_24h_quote", "liquidity_quote", "price_usd", "volume_24h_usd", "liquidity_usd"):
            value = getattr(self, name)
            if value is not None and (not value.is_finite() or value < 0 or (name in ("price_usd",) and value == 0)):
                raise ValueError(f"{name} precisa ser positivo (preço) ou não negativo e finito")
        for name in ("buys_24h", "sells_24h"):
            value = getattr(self, name)
            if value is not None and (not isinstance(value, int) or isinstance(value, bool) or value < 0):
                raise ValueError(f"{name} precisa ser inteiro não negativo")


class MarketDataFeed(Protocol):
    """Interface mínima que um adaptador de provedor deverá implementar."""

    def fetch(self, pool_addresses: Sequence[str]) -> Sequence[MarketDataSnapshot]:
        """Retorna snapshots normalizados para os pools solicitados."""
        ...
