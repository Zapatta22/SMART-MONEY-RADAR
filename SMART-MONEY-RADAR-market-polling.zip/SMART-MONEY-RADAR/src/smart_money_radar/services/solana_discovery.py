"""Coordena descoberta de mints e pools a partir de transações Solana já obtidas.

O serviço é offline: não busca transações, não consulta DEXs e não infere preço,
volume, liquidez ou negociabilidade. Recebe uma transação jsonParsed e persiste
as observações produzidas pelos parsers especializados.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from smart_money_radar.data_sources.dex_pool_parser import (
    PoolObservation,
    PoolProgramSpec,
    parse_pool_observations,
)
from smart_money_radar.data_sources.solana_launch_parser import (
    LaunchObservation,
    parse_launch_observations,
)
from smart_money_radar.storage.launch_discovery_store import SQLiteLaunchDiscoveryStore
from smart_money_radar.storage.pool_discovery_store import SQLitePoolDiscoveryStore


@dataclass(frozen=True)
class DiscoveryIngestionResult:
    signature: str
    launches_found: int
    launches_inserted: int
    pools_found: int
    pools_inserted: int
    linked_mints: tuple[str, ...]


class SolanaDiscoveryProcessor:
    """Integra parsers e stores existentes sem introduzir acesso à rede."""

    def __init__(
        self,
        launch_store: SQLiteLaunchDiscoveryStore,
        pool_store: SQLitePoolDiscoveryStore,
        pool_specs: Iterable[PoolProgramSpec] = (),
    ) -> None:
        self.launch_store = launch_store
        self.pool_store = pool_store
        self.pool_specs = tuple(pool_specs)

    def process(self, transaction: dict[str, Any], signature: str) -> DiscoveryIngestionResult:
        if not isinstance(transaction, dict) or not isinstance(signature, str) or not signature.strip():
            raise ValueError("transação e assinatura válidas são obrigatórias")

        launches: tuple[LaunchObservation, ...] = parse_launch_observations(transaction, signature)
        pools: tuple[PoolObservation, ...] = parse_pool_observations(
            transaction, signature, self.pool_specs
        )

        launch_inserted = sum(self.launch_store.save(item) for item in launches)
        pool_inserted = sum(self.pool_store.save(item) for item in pools)
        linked_mints = tuple(sorted({mint for pool in pools for mint in pool.token_mints}))

        return DiscoveryIngestionResult(
            signature=signature,
            launches_found=len(launches),
            launches_inserted=launch_inserted,
            pools_found=len(pools),
            pools_inserted=pool_inserted,
            linked_mints=linked_mints,
        )
