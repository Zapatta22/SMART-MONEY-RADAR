import json
import unittest
import tempfile
from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal
from urllib.parse import urlparse

from smart_money_radar.data_sources.dexscreener import DexScreenerFeed, DexScreenerError
from smart_money_radar.services.market_ingestion import MarketDataIngestor
from smart_money_radar.storage.market_data_store import SQLiteMarketDataStore


class FakeResponse:
    status = 200
    def __init__(self, payload): self.payload = payload
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def read(self): return json.dumps(self.payload).encode()


class DexScreenerFeedTests(unittest.TestCase):
    def setUp(self):
        self.pair = {
            "chainId": "solana", "pairAddress": "pool-1", "dexId": "raydium",
            "baseToken": {"address": "mint-a", "symbol": "AAA"},
            "quoteToken": {"address": "mint-b", "symbol": "SOL"},
            "priceNative": "0.0025", "priceUsd": "0.35",
            "volume": {"h24": 12000.5}, "liquidity": {"usd": 45000},
            "txns": {"h24": {"buys": 120, "sells": 80}},
        }

    def feed(self, payload):
        seen = []
        def opener(request, timeout):
            seen.append((request.full_url, timeout))
            return FakeResponse(payload)
        return DexScreenerFeed(opener=opener), seen

    def test_maps_pair_into_normalized_snapshot(self):
        feed, seen = self.feed({"pairs": [self.pair]})
        result = feed.fetch(["pool-1"])
        self.assertEqual(len(result), 1)
        item = result[0]
        self.assertEqual(item.token_mint, "mint-a")
        self.assertEqual(item.quote_mint, "mint-b")
        self.assertEqual(item.price_quote, Decimal("0.0025"))
        self.assertEqual(item.price_usd, Decimal("0.35"))
        self.assertEqual(item.volume_24h_usd, Decimal("12000.5"))
        self.assertEqual(item.liquidity_usd, Decimal("45000"))
        self.assertEqual((item.buys_24h, item.sells_24h), (120, 80))
        self.assertIn("/solana/pool-1", seen[0][0])

    def test_ignores_other_chain_or_pool(self):
        other = dict(self.pair, pairAddress="pool-other")
        feed, _ = self.feed({"pairs": [other]})
        self.assertEqual(feed.fetch(["pool-1"]), ())

    def test_empty_pairs_is_valid_no_data(self):
        feed, _ = self.feed({"pairs": None})
        self.assertEqual(feed.fetch(["pool-1"]), ())

    def test_rejects_invalid_response_shape(self):
        feed, _ = self.feed({"pairs": "bad"})
        with self.assertRaises(DexScreenerError):
            feed.fetch(["pool-1"])

    def test_deduplicates_requested_pool_addresses(self):
        feed, seen = self.feed({"pairs": [self.pair]})
        feed.fetch(["pool-1", "pool-1"])
        self.assertEqual(len(seen), 1)

    def test_feed_snapshot_passes_ingestion_and_persists_usd_data(self):
        feed, _ = self.feed({"pairs": [self.pair]})
        snapshot = feed.fetch(["pool-1"])[0]
        with tempfile.TemporaryDirectory() as directory:
            store = SQLiteMarketDataStore(Path(directory) / "market.sqlite")
            ingestor = MarketDataIngestor(store)
            result = ingestor.ingest(
                [snapshot], known_pool_tokens={"pool-1": {"mint-a", "mint-b"}},
                now=datetime.now(timezone.utc),
            )
            self.assertEqual((result.accepted, result.inserted), (1, 1))
            saved = store.load("mint-a")[0]
            self.assertEqual(saved.price_usd, Decimal("0.35"))
            self.assertEqual(saved.volume_24h_usd, Decimal("12000.5"))
            self.assertEqual(saved.liquidity_usd, Decimal("45000"))

    def test_skips_pairs_without_positive_price(self):
        bad = dict(self.pair, priceNative="0")
        feed, _ = self.feed({"pairs": [bad]})
        self.assertEqual(feed.fetch(["pool-1"]), ())


if __name__ == "__main__":
    unittest.main()
