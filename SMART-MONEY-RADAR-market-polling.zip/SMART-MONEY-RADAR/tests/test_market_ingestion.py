import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal as D
from pathlib import Path

from smart_money_radar.data_sources.market_feed import MarketDataSnapshot
from smart_money_radar.services.market_ingestion import MarketDataIngestor
from smart_money_radar.storage.market_data_store import SQLiteMarketDataStore


class MarketIngestionTests(unittest.TestCase):
    def setUp(self):
        self.now = datetime(2026, 11, 16, 14, 0, tzinfo=timezone.utc)
        self.known = {"pool-1": {"mint-a", "mint-b"}}

    def snapshot(self, **changes):
        values = dict(source="fixture-provider", pool_address="pool-1", token_mint="mint-a",
                      quote_mint="mint-b", observed_at=self.now - timedelta(seconds=20),
                      price_quote=D("0.25"), volume_24h_quote=D("1200"),
                      liquidity_quote=D("8500"), buys_24h=42, sells_24h=19)
        values.update(changes)
        return MarketDataSnapshot(**values)

    def make_ingestor(self, directory):
        store = SQLiteMarketDataStore(Path(directory) / "market.sqlite")
        return MarketDataIngestor(store), store

    def test_accepts_and_persists_fresh_snapshot(self):
        with tempfile.TemporaryDirectory() as d:
            ingestor, store = self.make_ingestor(d)
            result = ingestor.ingest([self.snapshot()], known_pool_tokens=self.known, now=self.now)
            self.assertEqual((result.received, result.accepted, result.inserted), (1, 1, 1))
            self.assertEqual(store.load("mint-a")[0].price_quote, D("0.25"))

    def test_rejects_unknown_pool(self):
        with tempfile.TemporaryDirectory() as d:
            ingestor, _ = self.make_ingestor(d)
            result = ingestor.ingest([self.snapshot()], known_pool_tokens={}, now=self.now)
            self.assertEqual(result.rejected[0][1], "pool_desconhecido")

    def test_rejects_mints_not_in_pool(self):
        with tempfile.TemporaryDirectory() as d:
            ingestor, _ = self.make_ingestor(d)
            bad = self.snapshot(quote_mint="mint-c")
            result = ingestor.ingest([bad], known_pool_tokens=self.known, now=self.now)
            self.assertEqual(result.rejected[0][1], "mints_nao_correspondem_ao_pool")

    def test_rejects_stale_snapshot(self):
        with tempfile.TemporaryDirectory() as d:
            ingestor, _ = self.make_ingestor(d)
            old = self.snapshot(observed_at=self.now - timedelta(minutes=5))
            result = ingestor.ingest([old], known_pool_tokens=self.known, now=self.now)
            self.assertEqual(result.rejected[0][1], "snapshot_desatualizado")

    def test_rejects_future_snapshot_outside_tolerance(self):
        with tempfile.TemporaryDirectory() as d:
            ingestor, _ = self.make_ingestor(d)
            future = self.snapshot(observed_at=self.now + timedelta(minutes=1))
            result = ingestor.ingest([future], known_pool_tokens=self.known, now=self.now)
            self.assertEqual(result.rejected[0][1], "timestamp_no_futuro")

    def test_accepts_small_clock_skew(self):
        with tempfile.TemporaryDirectory() as d:
            ingestor, _ = self.make_ingestor(d)
            future = self.snapshot(observed_at=self.now + timedelta(seconds=10))
            result = ingestor.ingest([future], known_pool_tokens=self.known, now=self.now)
            self.assertEqual(result.accepted, 1)

    def test_duplicate_is_accepted_but_not_inserted_twice(self):
        with tempfile.TemporaryDirectory() as d:
            ingestor, _ = self.make_ingestor(d)
            first = ingestor.ingest([self.snapshot()], known_pool_tokens=self.known, now=self.now)
            second = ingestor.ingest([self.snapshot()], known_pool_tokens=self.known, now=self.now)
            self.assertEqual(first.inserted, 1)
            self.assertEqual(second.accepted, 1)
            self.assertEqual(second.inserted, 0)

    def test_snapshot_rejects_invalid_price_and_counts(self):
        with self.assertRaises(ValueError):
            self.snapshot(price_quote=D("0"))
        with self.assertRaises(ValueError):
            self.snapshot(buys_24h=-1)

    def test_snapshot_requires_timezone(self):
        with self.assertRaises(ValueError):
            self.snapshot(observed_at=datetime(2026, 11, 16, 14, 0))

    def test_store_round_trips_usd_fields(self):
        with tempfile.TemporaryDirectory() as d:
            ingestor, store = self.make_ingestor(d)
            snapshot = self.snapshot(price_usd=D("0.35"), volume_24h_usd=D("12000"), liquidity_usd=D("45000"))
            ingestor.ingest([snapshot], known_pool_tokens=self.known, now=self.now)
            saved = store.load("mint-a")[0]
            self.assertEqual(saved.price_usd, D("0.35"))
            self.assertEqual(saved.volume_24h_usd, D("12000"))
            self.assertEqual(saved.liquidity_usd, D("45000"))

    def test_result_reports_mixed_batch(self):
        with tempfile.TemporaryDirectory() as d:
            ingestor, _ = self.make_ingestor(d)
            stale = self.snapshot(observed_at=self.now - timedelta(hours=1))
            result = ingestor.ingest([self.snapshot(), stale], known_pool_tokens=self.known, now=self.now)
            self.assertEqual((result.received, result.accepted, result.inserted), (2, 1, 1))
            self.assertEqual(len(result.rejected), 1)


if __name__ == "__main__":
    unittest.main()
