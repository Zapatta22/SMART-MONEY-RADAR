import tempfile
import unittest
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from pathlib import Path

from smart_money_radar.data_sources.market_feed import MarketDataSnapshot
from smart_money_radar.services.market_ingestion import MarketDataIngestor
from smart_money_radar.services.market_polling import MarketPollingService
from smart_money_radar.storage.market_data_store import SQLiteMarketDataStore


class FakeClock:
    def __init__(self): self.value = 100.0; self.sleeps = []
    def now(self): return self.value
    def sleep(self, seconds): self.sleeps.append(seconds); self.value += seconds


class FakeFeed:
    def __init__(self): self.calls = []; self.fail = set()
    def fetch(self, pools):
        pool = pools[0]; self.calls.append(pool)
        if pool in self.fail: raise RuntimeError("temporarily unavailable")
        return (MarketDataSnapshot(
            source="fake", pool_address=pool, token_mint="mint-a", quote_mint="mint-b",
            observed_at=datetime.now(timezone.utc), price_quote=Decimal("2"),
        ),)


class MarketPollingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = SQLiteMarketDataStore(Path(self.tmp.name) / "market.db")
        self.ingestor = MarketDataIngestor(self.store)
        self.clock = FakeClock(); self.feed = FakeFeed()
        self.service = MarketPollingService(
            self.feed, self.ingestor, requests_per_minute=60,
            cache_ttl=timedelta(seconds=20), clock=self.clock.now,
            sleeper=self.clock.sleep,
        )
        self.pools = {"pool-1": {"mint-a", "mint-b"}}
    def tearDown(self): self.tmp.cleanup()

    def test_fetches_and_ingests_known_pool(self):
        result = self.service.poll_once(self.pools)
        self.assertEqual((result.requested_pools, result.fetched_snapshots), (1, 1))
        self.assertEqual(result.ingestion.inserted, 1)
        self.assertEqual(self.feed.calls, ["pool-1"])

    def test_uses_cache_within_ttl(self):
        self.service.poll_once(self.pools)
        result = self.service.poll_once(self.pools)
        self.assertEqual(result.cached_pools, 1)
        self.assertEqual(len(self.feed.calls), 1)

    def test_force_refresh_bypasses_cache(self):
        self.service.poll_once(self.pools)
        self.service.poll_once(self.pools, force_refresh=True)
        self.assertEqual(len(self.feed.calls), 2)

    def test_respects_local_request_spacing(self):
        self.service.poll_once({"pool-1": {"mint-a", "mint-b"}, "pool-2": {"mint-a", "mint-b"}})
        self.assertEqual(len(self.feed.calls), 2)
        self.assertEqual(self.clock.sleeps, [1.0])

    def test_failure_isolated_and_reported(self):
        self.feed.fail.add("pool-1")
        result = self.service.poll_once(self.pools)
        self.assertEqual(len(result.failed_pools), 1)
        self.assertEqual(result.ingestion.received, 0)

    def test_rejects_invalid_pool_mapping(self):
        with self.assertRaises(ValueError):
            self.service.poll_once({"pool-1": {"mint-a"}})

    def test_clear_cache_forces_next_fetch(self):
        self.service.poll_once(self.pools)
        self.service.clear_cache("pool-1")
        self.service.poll_once(self.pools)
        self.assertEqual(len(self.feed.calls), 2)


if __name__ == "__main__": unittest.main()
