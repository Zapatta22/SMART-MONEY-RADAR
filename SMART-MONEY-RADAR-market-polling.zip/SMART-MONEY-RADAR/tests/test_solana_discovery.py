import tempfile
import unittest
from pathlib import Path

from smart_money_radar.data_sources.dex_pool_parser import PoolProgramSpec
from smart_money_radar.services.solana_discovery import SolanaDiscoveryProcessor
from smart_money_radar.storage.launch_discovery_store import SQLiteLaunchDiscoveryStore
from smart_money_radar.storage.pool_discovery_store import SQLitePoolDiscoveryStore
from smart_money_radar.data_sources.solana_launch_parser import SPL_TOKEN_PROGRAM


class SolanaDiscoveryProcessorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        db = Path(self.temp.name) / "smr.sqlite3"
        self.launch_store = SQLiteLaunchDiscoveryStore(db)
        self.pool_store = SQLitePoolDiscoveryStore(db)
        self.spec = PoolProgramSpec(
            program_id="VerifiedDexProgram111",
            instruction_types=("initializePool",),
            pool_field="pool",
            token_mint_fields=("tokenAMint", "tokenBMint"),
        )
        self.processor = SolanaDiscoveryProcessor(
            self.launch_store, self.pool_store, [self.spec]
        )

    def tearDown(self):
        self.temp.cleanup()

    def transaction(self):
        return {
            "blockTime": 1794837600,
            "transaction": {"message": {"instructions": [
                {"programId": SPL_TOKEN_PROGRAM, "parsed": {"type": "initializeMint2", "info": {
                    "mint": "NewMint", "decimals": 6, "mintAuthority": "Creator",
                    "freezeAuthority": None}}},
                {"programId": "VerifiedDexProgram111", "parsed": {"type": "initializePool", "info": {
                    "pool": "PoolAddress", "tokenAMint": "NewMint", "tokenBMint": "QuoteMint"}}},
            ]}},
            "meta": {},
        }

    def test_processes_and_links_launch_and_pool(self):
        result = self.processor.process(self.transaction(), "signature-1")
        self.assertEqual(result.launches_found, 1)
        self.assertEqual(result.launches_inserted, 1)
        self.assertEqual(result.pools_found, 1)
        self.assertEqual(result.pools_inserted, 1)
        self.assertEqual(result.linked_mints, ("NewMint", "QuoteMint"))
        self.assertEqual(self.pool_store.list_for_mint("NewMint")[0]["pool_address"], "PoolAddress")

    def test_reprocessing_is_idempotent(self):
        first = self.processor.process(self.transaction(), "signature-1")
        second = self.processor.process(self.transaction(), "signature-1")
        self.assertEqual((first.launches_inserted, first.pools_inserted), (1, 1))
        self.assertEqual((second.launches_inserted, second.pools_inserted), (0, 0))

    def test_pool_can_be_discovered_after_launch_in_another_transaction(self):
        launch_tx = self.transaction()
        launch_tx["transaction"]["message"]["instructions"] = launch_tx["transaction"]["message"]["instructions"][:1]
        self.processor.process(launch_tx, "launch-signature")
        pool_tx = self.transaction()
        pool_tx["transaction"]["message"]["instructions"] = pool_tx["transaction"]["message"]["instructions"][1:]
        result = self.processor.process(pool_tx, "pool-signature")
        self.assertEqual(result.launches_found, 0)
        self.assertEqual(self.pool_store.list_for_mint("NewMint")[0]["pool_address"], "PoolAddress")
        self.assertEqual(self.launch_store.list()[0]["mint"], "NewMint")

    def test_rejects_invalid_signature(self):
        with self.assertRaises(ValueError):
            self.processor.process({}, " ")


if __name__ == "__main__":
    unittest.main()
