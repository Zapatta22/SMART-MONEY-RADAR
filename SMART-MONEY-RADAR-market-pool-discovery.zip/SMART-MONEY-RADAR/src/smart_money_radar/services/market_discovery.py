"""Descoberta de pools por mint e ingestão de snapshots de mercado."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from smart_money_radar.data_sources.dexscreener import DexScreenerFeed
from smart_money_radar.services.market_ingestion import MarketDataIngestor, MarketIngestionResult


@dataclass(frozen=True)
class MarketDiscoveryResult:
    tokens_requested: int
    pools_discovered: int
    ingestion: MarketIngestionResult


class SolanaMarketDiscovery:
    """Liga mints já descobertos aos pools indexados pela DexScreener."""

    def __init__(self, feed: DexScreenerFeed, ingestor: MarketDataIngestor):
        self.feed = feed
        self.ingestor = ingestor

    def discover_and_ingest(self, token_mints: Sequence[str]) -> MarketDiscoveryResult:
        mints = tuple(dict.fromkeys(token_mints))
        if any(not isinstance(mint, str) or not mint.strip() for mint in mints):
            raise ValueError("todos os token mints precisam ser strings não vazias")
        snapshots = self.feed.fetch_for_tokens(mints)
        pool_tokens: dict[str, set[str]] = {}
        for snapshot in snapshots:
            pool_tokens.setdefault(snapshot.pool_address, set()).update(
                (snapshot.token_mint, snapshot.quote_mint)
            )
        ingestion = self.ingestor.ingest(snapshots, known_pool_tokens=pool_tokens)
        return MarketDiscoveryResult(
            tokens_requested=len(mints),
            pools_discovered=len(pool_tokens),
            ingestion=ingestion,
        )
