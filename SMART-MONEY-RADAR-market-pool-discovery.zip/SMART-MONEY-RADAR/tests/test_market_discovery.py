import json
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path

from smart_money_radar.data_sources.dexscreener import DexScreenerFeed
from smart_money_radar.services.market_discovery import SolanaMarketDiscovery
from smart_money_radar.services.market_ingestion import MarketDataIngestor
from smart_money_radar.storage.market_data_store import SQLiteMarketDataStore


class FakeResponse:
    status = 200
    def __init__(self, payload): self.payload = payload
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def read(self): return json.dumps(self.payload).encode()


class MarketDiscoveryTests(unittest.TestCase):
    def setUp(self):
        self.pair = {
            "chainId": "solana", "pairAddress": "pool-x", "dexId": "raydium",
            "baseToken": {"address": "mint-base", "symbol": "BASE"},
            "quoteToken": {"address": "mint-quote", "symbol": "QUOTE"},
            "priceNative": "2", "priceUsd": "10",
            "volume": {"h24": 25000}, "liquidity": {"usd": 80000},
            "txns": {"h24": {"buys": 300, "sells": 210}},
        }

    def build(self, payload):
        urls = []
        def opener(request, timeout):
            urls.append(request.full_url)
            return FakeResponse(payload)
        return DexScreenerFeed(opener=opener), urls

    def test_discovers_pool_for_base_mint_and_ingests(self):
        feed, urls = self.build([self.pair])
        with tempfile.TemporaryDirectory() as d:
            store = SQLiteMarketDataStore(Path(d) / "m.sqlite")
            service = SolanaMarketDiscovery(feed, MarketDataIngestor(store))
            result = service.discover_and_ingest(["mint-base"])
            self.assertEqual(result.tokens_requested, 1)
            self.assertEqual(result.pools_discovered, 1)
            self.assertEqual((result.ingestion.accepted, result.ingestion.inserted), (1, 1))
            saved = store.load("mint-base")[0]
            self.assertEqual(saved.price_quote, Decimal("2"))
            self.assertEqual(saved.price_usd, Decimal("10"))
            self.assertEqual(saved.volume_24h_usd, Decimal("25000"))
            self.assertIn("/token-pairs/v1/solana/mint-base", urls[0])

    def test_orients_price_when_target_is_quote_token(self):
        feed, _ = self.build([self.pair])
        snapshot = feed.fetch_for_tokens(["mint-quote"])[0]
        self.assertEqual(snapshot.token_mint, "mint-quote")
        self.assertEqual(snapshot.quote_mint, "mint-base")
        self.assertEqual(snapshot.price_quote, Decimal("0.5"))
        self.assertEqual(snapshot.price_usd, Decimal("5"))

    def test_deduplicates_mints_and_pairs(self):
        feed, urls = self.build([self.pair])
        result = feed.fetch_for_tokens(["mint-base", "mint-base"])
        self.assertEqual(len(result), 1)
        self.assertEqual(len(urls), 1)

    def test_empty_result_is_valid(self):
        feed, _ = self.build([])
        self.assertEqual(feed.fetch_for_tokens(["mint-new"]), ())

    def test_rejects_non_list_response(self):
        feed, _ = self.build({"pairs": []})
        with self.assertRaises(Exception):
            feed.fetch_for_tokens(["mint-new"])

    def test_service_rejects_empty_mint(self):
        feed, _ = self.build([])
        with tempfile.TemporaryDirectory() as d:
            service = SolanaMarketDiscovery(feed, MarketDataIngestor(SQLiteMarketDataStore(Path(d) / "m.sqlite")))
            with self.assertRaises(ValueError):
                service.discover_and_ingest([" "])


if __name__ == "__main__":
    unittest.main()
