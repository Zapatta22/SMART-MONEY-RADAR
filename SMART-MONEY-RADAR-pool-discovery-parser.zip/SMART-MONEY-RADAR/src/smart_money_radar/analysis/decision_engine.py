"""Decision Engine determinístico para avaliação offline e simulação.

Este módulo nunca envia ordens. Uma aprovação significa apenas elegibilidade
para uma simulação, não recomendação financeira nem autorização de execução.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from typing import Mapping


REQUIRED_SAFETY_CHECKS = frozenset({
    "mint_authority_disabled",
    "freeze_authority_disabled",
    "liquidity_lock_verified",
    "honeypot_check",
})


class EntryMode(str, Enum):
    IMMEDIATE = "immediate"
    CONFIRMED = "confirmed"


class DecisionStatus(str, Enum):
    BLOCKED = "blocked"
    WATCH = "watch"
    APPROVED_FOR_SIMULATION = "approved_for_simulation"


@dataclass(frozen=True)
class DecisionCandidate:
    candidate_id: str
    token_mint: str
    detected_at: datetime
    evaluated_at: datetime
    current_price: Decimal
    price_at_detection: Decimal
    liquidity_quote: Decimal
    current_volume_quote: Decimal
    baseline_volume_quote: Decimal
    realized_volatility: Decimal
    smart_money_score: int
    # Cada item representa uma verificação independente; True = passou.
    safety_checks: Mapping[str, bool]
    rug_pull_risk: int = 0
    related_wallet_risk: int = 0
    price_confirmation_pct: Decimal = Decimal("0.03")
    volume_confirmation_multiple: Decimal = Decimal("1.5")

    def __post_init__(self) -> None:
        if not self.candidate_id.strip() or not self.token_mint.strip():
            raise ValueError("candidate_id e token_mint são obrigatórios.")
        for name, value in (("detected_at", self.detected_at), ("evaluated_at", self.evaluated_at)):
            if value.tzinfo is None or value.utcoffset() is None:
                raise ValueError(f"{name} precisa conter fuso horário.")
        for name, value in (("current_price", self.current_price), ("price_at_detection", self.price_at_detection)):
            if not value.is_finite() or value <= 0:
                raise ValueError(f"{name} deve ser positivo e finito.")
        for name, value in (("liquidity_quote", self.liquidity_quote),
                            ("current_volume_quote", self.current_volume_quote),
                            ("baseline_volume_quote", self.baseline_volume_quote),
                            ("realized_volatility", self.realized_volatility),
                            ("price_confirmation_pct", self.price_confirmation_pct),
                            ("volume_confirmation_multiple", self.volume_confirmation_multiple)):
            if not value.is_finite() or value < 0:
                raise ValueError(f"{name} deve ser não negativo e finito.")
        if not 0 <= self.smart_money_score <= 100:
            raise ValueError("smart_money_score deve estar entre 0 e 100.")
        if not 0 <= self.rug_pull_risk <= 100 or not 0 <= self.related_wallet_risk <= 100:
            raise ValueError("Scores de risco devem estar entre 0 e 100.")
        missing = REQUIRED_SAFETY_CHECKS - set(self.safety_checks)
        if missing:
            raise ValueError("Verificações de segurança obrigatórias ausentes: " + ", ".join(sorted(missing)))
        if any(not isinstance(value, bool) for value in self.safety_checks.values()):
            raise ValueError("Cada verificação de segurança precisa ser booleana.")


@dataclass(frozen=True)
class DecisionPolicy:
    max_signal_age_seconds: int = 20
    minimum_liquidity_quote: Decimal = Decimal("10000")
    maximum_realized_volatility: Decimal = Decimal("0.15")
    minimum_smart_money_score: int = 65
    maximum_rug_pull_risk: int = 35
    maximum_related_wallet_risk: int = 60

    def __post_init__(self) -> None:
        if self.max_signal_age_seconds < 0:
            raise ValueError("max_signal_age_seconds deve ser >= 0")
        for name, value in (("minimum_liquidity_quote", self.minimum_liquidity_quote),
                            ("maximum_realized_volatility", self.maximum_realized_volatility)):
            if not value.is_finite() or value < 0:
                raise ValueError(f"{name} deve ser não negativo e finito.")
        if not 0 <= self.minimum_smart_money_score <= 100:
            raise ValueError("minimum_smart_money_score deve estar entre 0 e 100.")
        if not 0 <= self.maximum_rug_pull_risk <= 100 or not 0 <= self.maximum_related_wallet_risk <= 100:
            raise ValueError("Limites de risco devem estar entre 0 e 100.")


@dataclass(frozen=True)
class DecisionResult:
    candidate_id: str
    token_mint: str
    mode: EntryMode
    status: DecisionStatus
    evaluated_at: datetime
    signal_age_seconds: float
    price_change_pct: Decimal
    volume_multiple: Decimal | None
    reasons: tuple[str, ...]
    passed_safety_checks: tuple[str, ...]
    failed_safety_checks: tuple[str, ...]
    order_created: bool = False


def evaluate_candidate(candidate: DecisionCandidate, mode: EntryMode | str,
                        policy: DecisionPolicy = DecisionPolicy()) -> DecisionResult:
    """Aplica gates comuns e, no modo confirmado, valida preço + volume.

    Os dois modos compartilham todos os bloqueios de segurança. Modo immediate
    não significa execução instantânea: significa apenas aprovação sem aguardar
    confirmação adicional de preço/volume, sempre para simulação.
    """
    try:
        selected_mode = EntryMode(mode)
    except ValueError as exc:
        raise ValueError("Modo deve ser 'immediate' ou 'confirmed'.") from exc

    age = (candidate.evaluated_at - candidate.detected_at).total_seconds()
    price_change = candidate.current_price / candidate.price_at_detection - 1
    volume_multiple = (candidate.current_volume_quote / candidate.baseline_volume_quote
                       if candidate.baseline_volume_quote > 0 else None)
    reasons: list[str] = []
    passed = tuple(sorted(name for name, ok in candidate.safety_checks.items() if ok))
    failed = tuple(sorted(name for name, ok in candidate.safety_checks.items() if not ok))

    if age < 0:
        reasons.append("timestamp_de_deteccao_no_futuro")
    elif age > policy.max_signal_age_seconds:
        reasons.append("sinal_expirado_por_atraso")
    if failed:
        reasons.extend(f"bloqueio_seguranca:{name}" for name in failed)
    if candidate.liquidity_quote < policy.minimum_liquidity_quote:
        reasons.append("liquidez_abaixo_do_minimo")
    if candidate.realized_volatility > policy.maximum_realized_volatility:
        reasons.append("volatilidade_acima_do_limite")
    if candidate.smart_money_score < policy.minimum_smart_money_score:
        reasons.append("score_smart_money_insuficiente")
    if candidate.rug_pull_risk > policy.maximum_rug_pull_risk:
        reasons.append("risco_de_rug_pull_acima_do_limite")
    if candidate.related_wallet_risk > policy.maximum_related_wallet_risk:
        reasons.append("risco_de_relacao_entre_carteiras_acima_do_limite")

    common_blockers = bool(reasons)
    if not common_blockers and selected_mode is EntryMode.CONFIRMED:
        if price_change < candidate.price_confirmation_pct:
            reasons.append("aguardando_confirmacao_minima_de_preco")
        if volume_multiple is None or volume_multiple < candidate.volume_confirmation_multiple:
            reasons.append("aguardando_confirmacao_minima_de_volume")

    if any(reason not in {"aguardando_confirmacao_minima_de_preco", "aguardando_confirmacao_minima_de_volume"}
           for reason in reasons):
        status = DecisionStatus.BLOCKED
    elif reasons:
        status = DecisionStatus.WATCH
    else:
        status = DecisionStatus.APPROVED_FOR_SIMULATION

    return DecisionResult(candidate.candidate_id, candidate.token_mint, selected_mode, status,
                          candidate.evaluated_at.astimezone(timezone.utc), age, price_change,
                          volume_multiple, tuple(reasons), passed, failed, False)
