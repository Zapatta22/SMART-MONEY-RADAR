"""Contexto de mercado calculado somente a partir de observações históricas fornecidas."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from math import sqrt
from statistics import pstdev
from typing import Iterable

@dataclass(frozen=True)
class MarketObservation:
    token_mint: str
    observed_at: datetime
    price_quote: Decimal
    quote_mint: str
    volume_quote: Decimal | None = None
    liquidity_quote: Decimal | None = None

    def __post_init__(self):
        if not self.token_mint.strip() or not self.quote_mint.strip():
            raise ValueError("Mints do token e da cotação são obrigatórios.")
        if self.observed_at.tzinfo is None or self.observed_at.utcoffset() is None:
            raise ValueError("Timestamp precisa conter fuso horário.")
        if not self.price_quote.is_finite() or self.price_quote <= 0:
            raise ValueError("Preço deve ser positivo e finito.")
        for name, value in (("volume_quote", self.volume_quote), ("liquidity_quote", self.liquidity_quote)):
            if value is not None and (not value.is_finite() or value < 0):
                raise ValueError(f"{name} deve ser não negativo e finito.")

@dataclass(frozen=True)
class MarketContext:
    token_mint: str
    quote_mint: str
    observations: int
    start_at: datetime
    end_at: datetime
    total_return: Decimal
    realized_volatility: Decimal | None
    max_drawdown: Decimal
    liquidity_change: Decimal | None
    average_volume_quote: Decimal | None
    trend: str
    volatility_regime: str
    limitations: tuple[str, ...]

def analyze_market_context(observations: Iterable[MarketObservation]) -> tuple[MarketContext, ...]:
    """Calcula retorno, volatilidade, drawdown e proxies de liquidez por par.

    Volatilidade é desvio-padrão populacional dos retornos simples por intervalo;
    não é anualizada porque a frequência das observações pode variar.
    """
    groups: dict[tuple[str,str], list[MarketObservation]] = {}
    for item in observations:
        groups.setdefault((item.token_mint,item.quote_mint), []).append(item)
    reports=[]
    for (mint, quote), rows in sorted(groups.items()):
        rows=sorted(rows,key=lambda x:x.observed_at)
        prices=[float(x.price_quote) for x in rows]
        returns=[prices[i]/prices[i-1]-1 for i in range(1,len(prices))]
        total=Decimal(str(prices[-1]/prices[0]-1))
        peak=prices[0]; drawdown=0.0
        for price in prices:
            peak=max(peak,price)
            if peak: drawdown=min(drawdown,price/peak-1)
        vol=Decimal(str(pstdev(returns))) if len(returns)>=2 else None
        if total >= Decimal("0.05"): trend="alta"
        elif total <= Decimal("-0.05"): trend="baixa"
        else: trend="lateral"
        vol_regime="indisponivel" if vol is None else ("alta" if vol >= Decimal("0.10") else "moderada" if vol >= Decimal("0.03") else "baixa")
        liquid=[x.liquidity_quote for x in rows if x.liquidity_quote is not None]
        liq_change=(liquid[-1]/liquid[0]-1) if len(liquid)>=2 and liquid[0] else None
        volumes=[x.volume_quote for x in rows if x.volume_quote is not None]
        avg_vol=sum(volumes,Decimal("0"))/len(volumes) if volumes else None
        reports.append(MarketContext(mint,quote,len(rows),rows[0].observed_at,rows[-1].observed_at,total,vol,Decimal(str(drawdown)),liq_change,avg_vol,trend,vol_regime,
            ("Métricas dependem da frequência, qualidade e cobertura das observações fornecidas.",
             "Volume e liquidez são proxies informadas pela fonte; não representam profundidade executável nem slippage.",
             "Volatilidade não anualizada; não há inferência de causalidade ou previsão.")))
    return tuple(reports)

@dataclass(frozen=True)
class RelativeTradeAssessment:
    token_mint: str
    wallet_return: Decimal
    market_return: Decimal
    excess_return: Decimal
    quote_mint: str

def assess_trade_vs_market(*, token_mint: str, quote_mint: str, entry_price: Decimal, exit_price: Decimal,
                           market_entry_price: Decimal, market_exit_price: Decimal) -> RelativeTradeAssessment:
    """Compara retorno bruto da operação com o retorno do token no mesmo intervalo."""
    vals=(entry_price,exit_price,market_entry_price,market_exit_price)
    if any(not x.is_finite() or x<=0 for x in vals):
        raise ValueError("Todos os preços precisam ser positivos e finitos.")
    wallet=exit_price/entry_price-1
    market=market_exit_price/market_entry_price-1
    return RelativeTradeAssessment(token_mint,wallet,market,wallet-market,quote_mint)
