"""Contrato de ingestão de candidatos para os radares, sem rede por padrão.

Uma implementação futura poderá consumir launchpads, DEXs ou indexadores.
Este módulo inclui apenas uma fonte de fixtures locais para testes e simulação.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterable, Protocol

from smart_money_radar.analysis.decision_engine import DecisionCandidate


class RadarKind(str, Enum):
    LAUNCH = "launch"
    MARKET = "market"


@dataclass(frozen=True)
class CandidateBatch:
    radar: RadarKind
    candidates: tuple[DecisionCandidate, ...]
    source_name: str
    fetched_at: str

    def __post_init__(self) -> None:
        if not self.source_name.strip():
            raise ValueError("source_name é obrigatório")
        if not self.fetched_at.strip():
            raise ValueError("fetched_at é obrigatório")
        ids = [candidate.candidate_id for candidate in self.candidates]
        if len(ids) != len(set(ids)):
            raise ValueError("Lote contém candidate_id duplicado")


class CandidateFeed(Protocol):
    """Fonte somente de leitura; não concede permissão para enviar ordens."""

    def fetch(self, radar: RadarKind) -> CandidateBatch:
        """Obtém um lote para o radar solicitado."""
        ...


class OfflineCandidateFeed:
    """Feed local determinístico; não acessa internet, RPC ou blockchain."""

    def __init__(self, *, launch: Iterable[DecisionCandidate] = (),
                 market: Iterable[DecisionCandidate] = (),
                 source_name: str = "offline-fixture",
                 fetched_at: str = "offline") -> None:
        self._batches = {
            RadarKind.LAUNCH: tuple(launch),
            RadarKind.MARKET: tuple(market),
        }
        self.source_name = source_name
        self.fetched_at = fetched_at
        self.fetch_counts = {RadarKind.LAUNCH: 0, RadarKind.MARKET: 0}

    def fetch(self, radar: RadarKind) -> CandidateBatch:
        try:
            selected = RadarKind(radar)
        except ValueError as exc:
            raise ValueError("Radar deve ser 'launch' ou 'market'.") from exc
        self.fetch_counts[selected] += 1
        return CandidateBatch(selected, self._batches[selected],
                              self.source_name, self.fetched_at)
