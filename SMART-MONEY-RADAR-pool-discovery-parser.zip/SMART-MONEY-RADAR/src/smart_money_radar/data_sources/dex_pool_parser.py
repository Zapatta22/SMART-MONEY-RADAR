"""Parser configurável e conservador de inicializações de pools DEX.

Não descobre programas por heurística nem presume liquidez. O chamador deve
fornecer especificações verificadas por programa/instrução, pois cada AMM usa
layouts e nomes de campos próprios.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable


@dataclass(frozen=True)
class PoolProgramSpec:
    program_id: str
    instruction_types: tuple[str, ...]
    pool_field: str
    token_mint_fields: tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.program_id.strip() or not self.instruction_types:
            raise ValueError("program_id e instruction_types são obrigatórios")
        if not self.pool_field.strip() or len(self.token_mint_fields) < 2:
            raise ValueError("pool_field e pelo menos dois token_mint_fields são obrigatórios")
        if any(not item.strip() for item in (*self.instruction_types, *self.token_mint_fields)):
            raise ValueError("campos da especificação não podem estar vazios")


@dataclass(frozen=True)
class PoolObservation:
    pool_address: str
    signature: str
    created_at: datetime
    program_id: str
    instruction_type: str
    token_mints: tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.pool_address.strip() or not self.signature.strip() or not self.program_id.strip():
            raise ValueError("pool_address, signature e program_id são obrigatórios")
        if self.created_at.tzinfo is None or self.created_at.utcoffset() is None:
            raise ValueError("created_at precisa conter fuso horário")
        if len(self.token_mints) < 2 or len(set(self.token_mints)) != len(self.token_mints):
            raise ValueError("o pool precisa conter pelo menos dois mints distintos")
        if any(not mint.strip() for mint in self.token_mints):
            raise ValueError("token_mints não podem conter valores vazios")


def _instructions(transaction: dict[str, Any]) -> Iterable[dict[str, Any]]:
    message = transaction.get("transaction", {}).get("message", {})
    if isinstance(message, dict):
        top = message.get("instructions", [])
        if isinstance(top, list):
            yield from (item for item in top if isinstance(item, dict))
    meta = transaction.get("meta", {})
    inner = meta.get("innerInstructions", []) if isinstance(meta, dict) else []
    if isinstance(inner, list):
        for group in inner:
            if isinstance(group, dict) and isinstance(group.get("instructions"), list):
                yield from (item for item in group["instructions"] if isinstance(item, dict))


def parse_pool_observations(
    transaction: dict[str, Any], signature: str, specs: Iterable[PoolProgramSpec]
) -> tuple[PoolObservation, ...]:
    """Extrai pools somente de instruções jsonParsed explicitamente autorizadas."""
    if not isinstance(transaction, dict) or not isinstance(signature, str) or not signature.strip():
        raise ValueError("transação e assinatura válidas são obrigatórias")
    block_time = transaction.get("blockTime")
    if not isinstance(block_time, (int, float)) or isinstance(block_time, bool):
        return ()
    try:
        created_at = datetime.fromtimestamp(block_time, tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        return ()

    registry = {spec.program_id: spec for spec in specs}
    found: list[PoolObservation] = []
    seen: set[str] = set()
    for instruction in _instructions(transaction):
        program_id = instruction.get("programId")
        spec = registry.get(program_id) if isinstance(program_id, str) else None
        parsed = instruction.get("parsed")
        if spec is None or not isinstance(parsed, dict) or not isinstance(parsed.get("info"), dict):
            continue
        instruction_type = parsed.get("type")
        if instruction_type not in spec.instruction_types:
            continue
        info = parsed["info"]
        pool = info.get(spec.pool_field)
        mints = tuple(dict.fromkeys(
            value for field in spec.token_mint_fields
            if isinstance((value := info.get(field)), str) and value.strip()
        ))
        if not isinstance(pool, str) or not pool.strip() or pool in seen or len(mints) < 2:
            continue
        try:
            observation = PoolObservation(
                pool_address=pool, signature=signature, created_at=created_at,
                program_id=program_id, instruction_type=instruction_type,
                token_mints=mints,
            )
        except ValueError:
            continue
        seen.add(pool)
        found.append(observation)
    return tuple(found)
