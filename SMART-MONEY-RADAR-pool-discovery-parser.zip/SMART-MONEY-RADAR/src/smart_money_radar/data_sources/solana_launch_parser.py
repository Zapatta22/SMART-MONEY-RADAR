"""Descoberta conservadora de criação de mint SPL em transações Solana já obtidas.

Não consulta RPC. Reconhece somente instruções jsonParsed initializeMint/
initializeMint2 dos programas SPL Token e Token-2022; não prova que exista
pool, liquidez ou mercado negociável para o mint descoberto.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable

SPL_TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
TOKEN_2022_PROGRAM = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
SUPPORTED_PROGRAMS = {SPL_TOKEN_PROGRAM, TOKEN_2022_PROGRAM}


@dataclass(frozen=True)
class LaunchObservation:
    mint: str
    signature: str
    created_at: datetime
    token_program: str
    decimals: int
    mint_authority: str | None
    freeze_authority: str | None
    instruction_type: str

    def __post_init__(self) -> None:
        if not self.mint.strip() or not self.signature.strip():
            raise ValueError("mint e signature são obrigatórios")
        if self.created_at.tzinfo is None or self.created_at.utcoffset() is None:
            raise ValueError("created_at precisa conter fuso horário")
        if self.token_program not in SUPPORTED_PROGRAMS:
            raise ValueError("programa SPL não suportado")
        if not 0 <= self.decimals <= 18:
            raise ValueError("decimals fora do intervalo aceito")
        if self.instruction_type not in {"initializeMint", "initializeMint2"}:
            raise ValueError("tipo de instrução não suportado")


def _instructions(transaction: dict[str, Any]) -> Iterable[dict[str, Any]]:
    """Itera instruções top-level e innerInstructions sem confiar em tipos."""
    message = transaction.get("transaction", {}).get("message", {})
    if not isinstance(message, dict):
        return
    top = message.get("instructions", [])
    if isinstance(top, list):
        for instruction in top:
            if isinstance(instruction, dict):
                yield instruction
    meta = transaction.get("meta", {})
    inner = meta.get("innerInstructions", []) if isinstance(meta, dict) else []
    if isinstance(inner, list):
        for group in inner:
            if not isinstance(group, dict):
                continue
            items = group.get("instructions", [])
            if isinstance(items, list):
                for instruction in items:
                    if isinstance(instruction, dict):
                        yield instruction


def parse_launch_observations(
    transaction: dict[str, Any], signature: str
) -> tuple[LaunchObservation, ...]:
    """Extrai mints inicializados de uma transação jsonParsed confirmada."""
    if not isinstance(transaction, dict) or not signature.strip():
        raise ValueError("transação e assinatura válidas são obrigatórias")
    block_time = transaction.get("blockTime")
    if not isinstance(block_time, (int, float)) or isinstance(block_time, bool):
        return ()
    try:
        created_at = datetime.fromtimestamp(block_time, tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        return ()

    observations: list[LaunchObservation] = []
    seen: set[str] = set()
    for instruction in _instructions(transaction):
        program_id = instruction.get("programId")
        program = instruction.get("program")
        parsed = instruction.get("parsed")
        if not isinstance(parsed, dict) or not isinstance(parsed.get("info"), dict):
            continue
        instruction_type = parsed.get("type")
        if instruction_type not in {"initializeMint", "initializeMint2"}:
            continue
        # jsonParsed pode fornecer programId; o nome program serve apenas como
        # compatibilidade com fixtures/providers que omitem esse campo.
        if program_id not in SUPPORTED_PROGRAMS:
            if program not in {"spl-token", "spl-token-2022"}:
                continue
            # Sem programId não é possível distinguir Token de Token-2022.
            continue
        info = parsed["info"]
        mint = info.get("mint")
        decimals = info.get("decimals")
        if not isinstance(mint, str) or not mint.strip() or mint in seen:
            continue
        if not isinstance(decimals, int) or isinstance(decimals, bool) or not 0 <= decimals <= 18:
            continue
        try:
            observation = LaunchObservation(
                mint=mint,
                signature=signature,
                created_at=created_at,
                token_program=program_id,
                decimals=decimals,
                mint_authority=info.get("mintAuthority") if isinstance(info.get("mintAuthority"), str) else None,
                freeze_authority=info.get("freezeAuthority") if isinstance(info.get("freezeAuthority"), str) else None,
                instruction_type=instruction_type,
            )
        except ValueError:
            continue
        seen.add(mint)
        observations.append(observation)
    return tuple(observations)
