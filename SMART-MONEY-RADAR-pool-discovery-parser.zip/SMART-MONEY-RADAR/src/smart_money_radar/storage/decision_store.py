"""Auditoria local e append-only das avaliações do Decision Engine."""
from __future__ import annotations
import json
import sqlite3
from contextlib import closing
from pathlib import Path
from smart_money_radar.analysis.decision_engine import DecisionResult


class SQLiteDecisionStore:
    def __init__(self, database_path: Path | str):
        self.path = str(database_path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(self.path)) as connection, connection:
            connection.execute("""CREATE TABLE IF NOT EXISTS decision_audit (
                candidate_id TEXT NOT NULL, mode TEXT NOT NULL, evaluated_at TEXT NOT NULL,
                token_mint TEXT NOT NULL, status TEXT NOT NULL, signal_age_seconds REAL NOT NULL,
                price_change_pct TEXT NOT NULL, volume_multiple TEXT, reasons_json TEXT NOT NULL,
                passed_checks_json TEXT NOT NULL, failed_checks_json TEXT NOT NULL,
                order_created INTEGER NOT NULL CHECK(order_created = 0),
                PRIMARY KEY(candidate_id, mode, evaluated_at))""")

    def save(self, result: DecisionResult) -> bool:
        if result.order_created:
            raise ValueError("O Decision Store não aceita nem registra criação de ordens.")
        row = (result.candidate_id, result.mode.value, result.evaluated_at.isoformat(),
               result.token_mint, result.status.value, result.signal_age_seconds,
               str(result.price_change_pct), str(result.volume_multiple) if result.volume_multiple is not None else None,
               json.dumps(result.reasons), json.dumps(result.passed_safety_checks),
               json.dumps(result.failed_safety_checks), 0)
        with closing(sqlite3.connect(self.path)) as connection, connection:
            cursor = connection.execute("INSERT OR IGNORE INTO decision_audit VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", row)
            return cursor.rowcount == 1

    def list(self, candidate_id: str | None = None) -> tuple[dict, ...]:
        sql = "SELECT candidate_id,mode,evaluated_at,token_mint,status,signal_age_seconds,price_change_pct,volume_multiple,reasons_json,passed_checks_json,failed_checks_json,order_created FROM decision_audit"
        args: tuple = ()
        if candidate_id is not None:
            sql += " WHERE candidate_id=?"
            args = (candidate_id,)
        sql += " ORDER BY evaluated_at,candidate_id,mode"
        with closing(sqlite3.connect(self.path)) as connection:
            rows = connection.execute(sql, args).fetchall()
        keys = ("candidate_id", "mode", "evaluated_at", "token_mint", "status", "signal_age_seconds",
                "price_change_pct", "volume_multiple", "reasons", "passed_safety_checks", "failed_safety_checks", "order_created")
        output = []
        for row in rows:
            values = list(row)
            values[8:11] = [json.loads(value) for value in values[8:11]]
            output.append(dict(zip(keys, values)))
        return tuple(output)
