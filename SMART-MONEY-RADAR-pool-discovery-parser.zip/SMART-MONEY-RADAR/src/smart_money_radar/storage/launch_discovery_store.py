"""Persistência SQLite idempotente para descobertas de criação de mint."""
from __future__ import annotations

import sqlite3
from pathlib import Path
from smart_money_radar.data_sources.solana_launch_parser import LaunchObservation


class SQLiteLaunchDiscoveryStore:
    def __init__(self, database: str | Path):
        self.database = str(database)
        Path(self.database).parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as connection:
            connection.execute("""
                CREATE TABLE IF NOT EXISTS launch_discoveries (
                    mint TEXT NOT NULL,
                    signature TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    token_program TEXT NOT NULL,
                    decimals INTEGER NOT NULL,
                    mint_authority TEXT,
                    freeze_authority TEXT,
                    instruction_type TEXT NOT NULL,
                    PRIMARY KEY (mint, signature)
                )
            """)

    def _connect(self):
        return sqlite3.connect(self.database)

    def save(self, observation: LaunchObservation) -> bool:
        with self._connect() as connection:
            cursor = connection.execute("""
                INSERT OR IGNORE INTO launch_discoveries
                (mint, signature, created_at, token_program, decimals,
                 mint_authority, freeze_authority, instruction_type)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                observation.mint, observation.signature,
                observation.created_at.isoformat(), observation.token_program,
                observation.decimals, observation.mint_authority,
                observation.freeze_authority, observation.instruction_type,
            ))
            return cursor.rowcount == 1

    def list(self, limit: int = 100) -> list[dict[str, object]]:
        if not 1 <= limit <= 10000:
            raise ValueError("limit deve estar entre 1 e 10000")
        with self._connect() as connection:
            connection.row_factory = sqlite3.Row
            rows = connection.execute(
                "SELECT * FROM launch_discoveries ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]
