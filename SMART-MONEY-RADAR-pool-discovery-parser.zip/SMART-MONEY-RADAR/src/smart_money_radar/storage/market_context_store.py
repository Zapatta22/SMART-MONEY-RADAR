"""Armazenamento idempotente de observações de mercado no SQLite local."""
import sqlite3
from contextlib import closing
from pathlib import Path
from decimal import Decimal
from datetime import datetime
from smart_money_radar.analysis.market_context import MarketObservation

class SQLiteMarketContextStore:
    def __init__(self, database_path: Path | str):
        self.path=str(database_path)
        if self.path != ":memory:": Path(self.path).parent.mkdir(parents=True,exist_ok=True)
        with closing(sqlite3.connect(self.path)) as c, c:
            c.execute("""CREATE TABLE IF NOT EXISTS market_observations(
                token_mint TEXT NOT NULL, quote_mint TEXT NOT NULL, observed_at TEXT NOT NULL,
                price_quote TEXT NOT NULL, volume_quote TEXT, liquidity_quote TEXT,
                PRIMARY KEY(token_mint,quote_mint,observed_at))""")
    def save(self, observations):
        rows=[(o.token_mint,o.quote_mint,o.observed_at.isoformat(),str(o.price_quote),
               str(o.volume_quote) if o.volume_quote is not None else None,
               str(o.liquidity_quote) if o.liquidity_quote is not None else None) for o in observations]
        with closing(sqlite3.connect(self.path)) as c, c:
            before=c.total_changes
            c.executemany("INSERT OR IGNORE INTO market_observations VALUES(?,?,?,?,?,?)",rows)
            return c.total_changes-before
    def load(self, token_mint=None):
        sql="SELECT token_mint,quote_mint,observed_at,price_quote,volume_quote,liquidity_quote FROM market_observations"
        args=()
        if token_mint is not None: sql+=" WHERE token_mint=?"; args=(token_mint,)
        sql+=" ORDER BY token_mint,quote_mint,observed_at"
        with closing(sqlite3.connect(self.path)) as c: rows=c.execute(sql,args).fetchall()
        return tuple(MarketObservation(r[0],datetime.fromisoformat(r[2]),Decimal(r[3]),r[1],Decimal(r[4]) if r[4] else None,Decimal(r[5]) if r[5] else None) for r in rows)
