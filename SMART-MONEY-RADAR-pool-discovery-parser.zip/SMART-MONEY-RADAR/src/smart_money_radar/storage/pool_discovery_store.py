"""Persistência SQLite idempotente para observações de inicialização de pools."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from smart_money_radar.data_sources.dex_pool_parser import PoolObservation


class SQLitePoolDiscoveryStore:
    def __init__(self, database: str | Path):
        self.database = str(database)
        Path(self.database).parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as connection:
            connection.execute("""
                CREATE TABLE IF NOT EXISTS dex_pool_discoveries (
                    pool_address TEXT NOT NULL,
                    signature TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    program_id TEXT NOT NULL,
                    instruction_type TEXT NOT NULL,
                    token_mints_json TEXT NOT NULL,
                    PRIMARY KEY (pool_address, signature)
                )
            """)
            connection.execute("""
                CREATE TABLE IF NOT EXISTS dex_pool_tokens (
                    pool_address TEXT NOT NULL,
                    signature TEXT NOT NULL,
                    token_mint TEXT NOT NULL,
                    PRIMARY KEY (pool_address, signature, token_mint),
                    FOREIGN KEY (pool_address, signature)
                        REFERENCES dex_pool_discoveries(pool_address, signature)
                )
            """)
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_dex_pool_tokens_mint ON dex_pool_tokens(token_mint)"
            )

    def _connect(self):
        return sqlite3.connect(self.database)

    def save(self, observation: PoolObservation) -> bool:
        with self._connect() as connection:
            cursor = connection.execute("""
                INSERT OR IGNORE INTO dex_pool_discoveries
                (pool_address, signature, created_at, program_id, instruction_type, token_mints_json)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                observation.pool_address, observation.signature,
                observation.created_at.isoformat(), observation.program_id,
                observation.instruction_type, json.dumps(observation.token_mints),
            ))
            inserted = cursor.rowcount == 1
            if inserted:
                connection.executemany(
                    "INSERT OR IGNORE INTO dex_pool_tokens (pool_address, signature, token_mint) VALUES (?, ?, ?)",
                    [(observation.pool_address, observation.signature, mint) for mint in observation.token_mints],
                )
            return inserted

    def list_for_mint(self, mint: str, limit: int = 100) -> list[dict[str, object]]:
        if not mint.strip():
            raise ValueError("mint não pode estar vazio")
        if not 1 <= limit <= 10000:
            raise ValueError("limit deve estar entre 1 e 10000")
        with self._connect() as connection:
            connection.row_factory = sqlite3.Row
            rows = connection.execute(
                """SELECT d.* FROM dex_pool_discoveries d
                   JOIN dex_pool_tokens t ON t.pool_address = d.pool_address AND t.signature = d.signature
                   WHERE t.token_mint = ? ORDER BY d.created_at DESC LIMIT ?""",
                (mint, limit),
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["token_mints"] = json.loads(item.pop("token_mints_json"))
            result.append(item)
        return result

    def list(self, limit: int = 100) -> list[dict[str, object]]:
        if not 1 <= limit <= 10000:
            raise ValueError("limit deve estar entre 1 e 10000")
        with self._connect() as connection:
            connection.row_factory = sqlite3.Row
            rows = connection.execute(
                "SELECT * FROM dex_pool_discoveries ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["token_mints"] = json.loads(item.pop("token_mints_json"))
            result.append(item)
        return result
