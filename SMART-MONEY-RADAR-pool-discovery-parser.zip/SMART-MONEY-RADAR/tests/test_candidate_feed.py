import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal as D
from pathlib import Path

from smart_money_radar.analysis.decision_engine import DecisionCandidate, DecisionStatus
from smart_money_radar.data_sources.candidate_feed import CandidateBatch, OfflineCandidateFeed, RadarKind
from smart_money_radar.services.radar_pipeline import RadarCoordinator
from smart_money_radar.storage.decision_store import SQLiteDecisionStore


class CandidateFeedTests(unittest.TestCase):
    def candidate(self, candidate_id):
        now = datetime(2026, 11, 16, 14, 0, tzinfo=timezone.utc)
        return DecisionCandidate(
            candidate_id=candidate_id, token_mint=f"mint-{candidate_id}",
            detected_at=now - timedelta(seconds=1), evaluated_at=now,
            current_price=D("1.05"), price_at_detection=D("1"),
            liquidity_quote=D("50000"), current_volume_quote=D("3000"),
            baseline_volume_quote=D("1000"), realized_volatility=D("0.04"),
            smart_money_score=85,
            safety_checks={"mint_authority_disabled": True,
                "freeze_authority_disabled": True, "liquidity_lock_verified": True,
                "honeypot_check": True})

    def test_offline_feed_keeps_radar_queues_independent(self):
        launch, market = self.candidate("l1"), self.candidate("m1")
        feed = OfflineCandidateFeed(launch=[launch], market=[market])
        self.assertEqual(feed.fetch(RadarKind.LAUNCH).candidates, (launch,))
        self.assertEqual(feed.fetch(RadarKind.MARKET).candidates, (market,))
        self.assertEqual(feed.fetch_counts[RadarKind.LAUNCH], 1)
        self.assertEqual(feed.fetch_counts[RadarKind.MARKET], 1)

    def test_coordinator_ingests_and_persists_only_requested_pipeline(self):
        with tempfile.TemporaryDirectory() as directory:
            store = SQLiteDecisionStore(Path(directory) / "audit.sqlite")
            coordinator = RadarCoordinator(store)
            feed = OfflineCandidateFeed(launch=[self.candidate("l2")],
                                        market=[self.candidate("m2")])
            results = coordinator.ingest_and_evaluate(feed, "launch", "immediate")
            self.assertEqual(len(results), 1)
            self.assertEqual(results[0].radar, RadarKind.LAUNCH)
            self.assertEqual(results[0].result.status, DecisionStatus.APPROVED_FOR_SIMULATION)
            self.assertEqual(feed.fetch_counts[RadarKind.MARKET], 0)
            self.assertEqual(len(store.list()), 1)

    def test_batch_rejects_duplicate_candidate_ids(self):
        candidate = self.candidate("duplicate")
        with self.assertRaises(ValueError):
            CandidateBatch(RadarKind.LAUNCH, (candidate, candidate), "fixture", "offline")

    def test_batch_requires_source_metadata(self):
        with self.assertRaises(ValueError):
            CandidateBatch(RadarKind.LAUNCH, (), "", "offline")

    def test_invalid_radar_is_rejected(self):
        feed = OfflineCandidateFeed()
        with self.assertRaises(ValueError):
            feed.fetch("unknown")


if __name__ == "__main__":
    unittest.main()
