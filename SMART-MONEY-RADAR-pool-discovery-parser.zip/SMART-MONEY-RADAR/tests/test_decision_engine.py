import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal as D
from pathlib import Path

from smart_money_radar.analysis.decision_engine import (
    DecisionCandidate, DecisionPolicy, DecisionStatus, EntryMode, evaluate_candidate,
)
from smart_money_radar.storage.decision_store import SQLiteDecisionStore


class DecisionEngineTests(unittest.TestCase):
    def candidate(self, **overrides):
        now = datetime(2026, 11, 16, 12, 0, tzinfo=timezone.utc)
        values = dict(
            candidate_id="cand-1", token_mint="mint-1", detected_at=now - timedelta(seconds=2),
            evaluated_at=now, current_price=D("1.04"), price_at_detection=D("1.00"),
            liquidity_quote=D("50000"), current_volume_quote=D("3000"),
            baseline_volume_quote=D("1000"), realized_volatility=D("0.05"),
            smart_money_score=80,
            safety_checks={"mint_authority_disabled": True, "freeze_authority_disabled": True,
                            "liquidity_lock_verified": True, "honeypot_check": True},
            rug_pull_risk=10, related_wallet_risk=15,
        )
        values.update(overrides)
        return DecisionCandidate(**values)

    def test_immediate_mode_approves_only_for_simulation(self):
        result = evaluate_candidate(self.candidate(), EntryMode.IMMEDIATE)
        self.assertEqual(result.status, DecisionStatus.APPROVED_FOR_SIMULATION)
        self.assertFalse(result.order_created)

    def test_confirmed_mode_requires_price_and_volume(self):
        result = evaluate_candidate(self.candidate(current_price=D("1.01"), current_volume_quote=D("1200")), "confirmed")
        self.assertEqual(result.status, DecisionStatus.WATCH)
        self.assertIn("aguardando_confirmacao_minima_de_preco", result.reasons)
        self.assertIn("aguardando_confirmacao_minima_de_volume", result.reasons)

    def test_confirmed_mode_approves_when_both_confirmations_pass(self):
        result = evaluate_candidate(self.candidate(), EntryMode.CONFIRMED)
        self.assertEqual(result.status, DecisionStatus.APPROVED_FOR_SIMULATION)

    def test_safety_blocks_are_identical_in_both_modes(self):
        candidate = self.candidate(safety_checks={"mint_authority_disabled": False, "freeze_authority_disabled": True,
                                                       "liquidity_lock_verified": True, "honeypot_check": True})
        immediate = evaluate_candidate(candidate, "immediate")
        confirmed = evaluate_candidate(candidate, "confirmed")
        self.assertEqual(immediate.status, DecisionStatus.BLOCKED)
        self.assertEqual(confirmed.status, DecisionStatus.BLOCKED)
        self.assertIn("bloqueio_seguranca:mint_authority_disabled", immediate.reasons)
        self.assertEqual(immediate.reasons, confirmed.reasons)

    def test_stale_signal_is_blocked(self):
        result = evaluate_candidate(self.candidate(detected_at=datetime(2026, 11, 16, 11, 59, 0, tzinfo=timezone.utc)), "immediate")
        self.assertEqual(result.status, DecisionStatus.BLOCKED)
        self.assertIn("sinal_expirado_por_atraso", result.reasons)

    def test_liquidity_volatility_and_rug_risk_block(self):
        result = evaluate_candidate(self.candidate(liquidity_quote=D("100"), realized_volatility=D("0.30"), rug_pull_risk=90), "immediate")
        self.assertEqual(result.status, DecisionStatus.BLOCKED)
        self.assertIn("liquidez_abaixo_do_minimo", result.reasons)
        self.assertIn("volatilidade_acima_do_limite", result.reasons)
        self.assertIn("risco_de_rug_pull_acima_do_limite", result.reasons)

    def test_missing_baseline_volume_never_confirms_mode_b(self):
        result = evaluate_candidate(self.candidate(baseline_volume_quote=D("0")), "confirmed")
        self.assertEqual(result.status, DecisionStatus.WATCH)
        self.assertIn("aguardando_confirmacao_minima_de_volume", result.reasons)

    def test_future_detection_timestamp_is_blocked(self):
        now = datetime(2026, 11, 16, 12, 0, tzinfo=timezone.utc)
        result = evaluate_candidate(self.candidate(detected_at=now + timedelta(seconds=1)), "immediate")
        self.assertEqual(result.status, DecisionStatus.BLOCKED)
        self.assertIn("timestamp_de_deteccao_no_futuro", result.reasons)

    def test_invalid_input_rejected(self):
        with self.assertRaises(ValueError):
            self.candidate(smart_money_score=101)
        with self.assertRaises(ValueError):
            self.candidate(safety_checks={"mint_authority_disabled": True})
        with self.assertRaises(ValueError):
            evaluate_candidate(self.candidate(), "fast")

    def test_store_is_idempotent_and_never_records_order(self):
        with tempfile.TemporaryDirectory() as directory:
            store = SQLiteDecisionStore(Path(directory) / "decisions.sqlite")
            result = evaluate_candidate(self.candidate(), "immediate")
            self.assertTrue(store.save(result))
            self.assertFalse(store.save(result))
            rows = store.list("cand-1")
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["order_created"], 0)
            self.assertEqual(rows[0]["status"], "approved_for_simulation")


if __name__ == "__main__":
    unittest.main()
