import tempfile
import unittest
from pathlib import Path

from smart_money_radar.data_sources.dex_pool_parser import PoolProgramSpec, parse_pool_observations
from smart_money_radar.storage.pool_discovery_store import SQLitePoolDiscoveryStore


class DexPoolParserTests(unittest.TestCase):
    SPEC = PoolProgramSpec(
        program_id="VerifiedDexProgram111",
        instruction_types=("initializePool", "createPool"),
        pool_field="pool",
        token_mint_fields=("tokenAMint", "tokenBMint"),
    )

    def tx(self, instructions, block_time=1794837600):
        return {"blockTime": block_time, "transaction": {"message": {"instructions": instructions}}, "meta": {}}

    def instruction(self, pool="Pool111", program_id="VerifiedDexProgram111", kind="initializePool"):
        return {"programId": program_id, "parsed": {"type": kind, "info": {
            "pool": pool, "tokenAMint": "MintA", "tokenBMint": "MintB"}}}

    def test_detects_configured_pool_initialization(self):
        found = parse_pool_observations(self.tx([self.instruction()]), "sig-1", [self.SPEC])
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].pool_address, "Pool111")
        self.assertEqual(found[0].token_mints, ("MintA", "MintB"))

    def test_detects_inner_instruction(self):
        tx = self.tx([])
        tx["meta"]["innerInstructions"] = [{"index": 0, "instructions": [self.instruction()]}]
        self.assertEqual(len(parse_pool_observations(tx, "sig-2", [self.SPEC])), 1)

    def test_ignores_unknown_program_and_instruction(self):
        self.assertEqual(parse_pool_observations(self.tx([
            self.instruction(program_id="Unknown"), self.instruction(kind="swap")
        ]), "sig", [self.SPEC]), ())

    def test_requires_two_distinct_mints_and_pool_address(self):
        bad = self.instruction()
        bad["parsed"]["info"]["tokenBMint"] = "MintA"
        self.assertEqual(parse_pool_observations(self.tx([bad]), "sig", [self.SPEC]), ())

    def test_missing_timestamp_is_not_fabricated(self):
        self.assertEqual(parse_pool_observations(self.tx([self.instruction()], None), "sig", [self.SPEC]), ())

    def test_store_is_idempotent(self):
        item = parse_pool_observations(self.tx([self.instruction()]), "sig", [self.SPEC])[0]
        with tempfile.TemporaryDirectory() as directory:
            store = SQLitePoolDiscoveryStore(Path(directory) / "pools.sqlite")
            self.assertTrue(store.save(item))
            self.assertFalse(store.save(item))
            self.assertEqual(store.list()[0]["token_mints"], ["MintA", "MintB"])
            self.assertEqual(store.list_for_mint("MintA")[0]["pool_address"], "Pool111")
            self.assertEqual(store.list_for_mint("MintMissing"), [])

    def test_spec_requires_explicit_field_mapping(self):
        with self.assertRaises(ValueError):
            PoolProgramSpec("program", ("initializePool",), "pool", ("mint",))


if __name__ == "__main__":
    unittest.main()
