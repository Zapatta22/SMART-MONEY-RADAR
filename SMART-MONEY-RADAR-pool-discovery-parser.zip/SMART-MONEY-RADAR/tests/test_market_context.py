import unittest, tempfile
from pathlib import Path
from datetime import datetime, timezone, timedelta
from decimal import Decimal as D
from smart_money_radar.analysis.market_context import MarketObservation, analyze_market_context, assess_trade_vs_market
from smart_money_radar.storage.market_context_store import SQLiteMarketContextStore

class MarketContextTests(unittest.TestCase):
 def observations(self):
  t=datetime(2026,1,1,tzinfo=timezone.utc)
  return [MarketObservation('mint',t+timedelta(hours=i),D(p),'SOL',D('100'),D(liq)) for i,(p,liq) in enumerate([('1','1000'),('1.2','1100'),('0.9','900'),('1.1','1200')])]
 def test_metrics_and_drawdown(self):
  result=analyze_market_context(self.observations())[0]
  self.assertEqual(result.observations,4); self.assertEqual(result.trend,'alta')
  self.assertLess(result.max_drawdown,D('0')); self.assertIsNotNone(result.realized_volatility)
  self.assertEqual(result.liquidity_change,D('0.2'))
 def test_single_observation_marks_volatility_unavailable(self):
  result=analyze_market_context(self.observations()[:1])[0]
  self.assertIsNone(result.realized_volatility); self.assertEqual(result.volatility_regime,'indisponivel')
 def test_excess_return(self):
  a=assess_trade_vs_market(token_mint='m',quote_mint='SOL',entry_price=D('2'),exit_price=D('3'),market_entry_price=D('2'),market_exit_price=D('2.5'))
  self.assertEqual(a.excess_return,D('0.25'))
 def test_store_is_idempotent(self):
  with tempfile.TemporaryDirectory() as d:
   store=SQLiteMarketContextStore(Path(d)/'m.db'); rows=self.observations()
   self.assertEqual(store.save(rows),4); self.assertEqual(store.save(rows),0); self.assertEqual(len(store.load()),4)
 def test_rejects_naive_timestamp_and_invalid_price(self):
  with self.assertRaises(ValueError): MarketObservation('m',datetime(2026,1,1),D('1'),'SOL')
  with self.assertRaises(ValueError): MarketObservation('m',datetime.now(timezone.utc),D('0'),'SOL')
if __name__=='__main__': unittest.main()
