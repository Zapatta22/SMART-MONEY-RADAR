import tempfile
import unittest
from pathlib import Path

from smart_money_radar.data_sources.solana_launch_parser import (
    SPL_TOKEN_PROGRAM, TOKEN_2022_PROGRAM, parse_launch_observations,
)
from smart_money_radar.storage.launch_discovery_store import SQLiteLaunchDiscoveryStore


class SolanaLaunchParserTests(unittest.TestCase):
    def tx(self, instructions, block_time=1794837600):
        return {"blockTime": block_time, "transaction": {"message": {"instructions": instructions}}, "meta": {}}

    def instruction(self, mint="Mint111", program_id=SPL_TOKEN_PROGRAM, kind="initializeMint"):
        return {"programId": program_id, "program": "spl-token", "parsed": {
            "type": kind, "info": {"mint": mint, "decimals": 9,
                "mintAuthority": "Auth111", "freezeAuthority": None}}}

    def test_detects_spl_mint_initialization(self):
        found = parse_launch_observations(self.tx([self.instruction()]), "sig-1")
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].mint, "Mint111")
        self.assertEqual(found[0].decimals, 9)
        self.assertIsNone(found[0].freeze_authority)
        self.assertEqual(found[0].created_at.tzinfo, __import__('datetime').timezone.utc)

    def test_detects_token_2022_and_inner_instructions(self):
        tx = self.tx([])
        tx["meta"]["innerInstructions"] = [{"index": 0, "instructions": [
            self.instruction("Mint2022", TOKEN_2022_PROGRAM, "initializeMint2")]}]
        self.assertEqual(parse_launch_observations(tx, "sig-2")[0].mint, "Mint2022")

    def test_ignores_non_mint_or_unrecognized_program(self):
        wrong = self.instruction()
        wrong["programId"] = "not-a-token-program"
        swap = self.instruction(kind="transfer")
        self.assertEqual(parse_launch_observations(self.tx([wrong, swap]), "sig"), ())

    def test_deduplicates_same_mint_inside_transaction(self):
        result = parse_launch_observations(self.tx([self.instruction(), self.instruction()]), "sig")
        self.assertEqual(len(result), 1)

    def test_missing_block_time_is_not_fabricated(self):
        self.assertEqual(parse_launch_observations(self.tx([self.instruction()], None), "sig"), ())

    def test_sqlite_store_is_idempotent(self):
        item = parse_launch_observations(self.tx([self.instruction()]), "sig")[0]
        with tempfile.TemporaryDirectory() as directory:
            store = SQLiteLaunchDiscoveryStore(Path(directory) / "launch.sqlite")
            self.assertTrue(store.save(item))
            self.assertFalse(store.save(item))
            self.assertEqual(len(store.list()), 1)

    def test_invalid_limit_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            store = SQLiteLaunchDiscoveryStore(Path(directory) / "launch.sqlite")
            with self.assertRaises(ValueError):
                store.list(0)


if __name__ == "__main__":
    unittest.main()
