"""Orquestração offline dos radares Launch/Market para o Decision Engine.

As classes recebem candidatos já enriquecidos. Elas não descobrem tokens,
não consultam RPC/DEX e não executam ordens; essa separação permite validar
os pipelines antes de ligar fontes externas.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterable

from smart_money_radar.analysis.decision_engine import (
    DecisionCandidate, DecisionPolicy, DecisionResult, EntryMode, evaluate_candidate,
)
from smart_money_radar.storage.decision_store import SQLiteDecisionStore


class RadarKind(str, Enum):
    LAUNCH = "launch"
    MARKET = "market"


@dataclass(frozen=True)
class RadarEvaluation:
    radar: RadarKind
    result: DecisionResult
    persisted: bool


class _BaseRadar:
    """Pipeline independente; compartilha somente política e motor de decisão."""
    kind: RadarKind

    def __init__(self, policy: DecisionPolicy | None = None):
        self.policy = policy or DecisionPolicy()

    def evaluate(self, candidates: Iterable[DecisionCandidate], mode: EntryMode | str,
                 store: SQLiteDecisionStore) -> tuple[RadarEvaluation, ...]:
        output = []
        for candidate in candidates:
            result = evaluate_candidate(candidate, mode, self.policy)
            output.append(RadarEvaluation(self.kind, result, store.save(result)))
        return tuple(output)


class LaunchRadar(_BaseRadar):
    """Fluxo destinado a tokens recém-lançados; exige dados completos no candidato."""
    kind = RadarKind.LAUNCH


class MarketRadar(_BaseRadar):
    """Fluxo destinado a tokens já negociados; isolado do Launch Radar."""
    kind = RadarKind.MARKET


class RadarCoordinator:
    """Executa os dois radares sem misturar suas filas de candidatos."""
    def __init__(self, store: SQLiteDecisionStore,
                 policy: DecisionPolicy | None = None):
        self.store = store
        self.launch_radar = LaunchRadar(policy)
        self.market_radar = MarketRadar(policy)

    def evaluate_launch(self, candidates: Iterable[DecisionCandidate],
                        mode: EntryMode | str) -> tuple[RadarEvaluation, ...]:
        return self.launch_radar.evaluate(candidates, mode, self.store)

    def evaluate_market(self, candidates: Iterable[DecisionCandidate],
                        mode: EntryMode | str) -> tuple[RadarEvaluation, ...]:
        return self.market_radar.evaluate(candidates, mode, self.store)
