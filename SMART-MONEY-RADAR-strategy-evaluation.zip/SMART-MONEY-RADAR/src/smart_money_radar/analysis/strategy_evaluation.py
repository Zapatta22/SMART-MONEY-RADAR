"""Comparação offline de estratégias com separação cronológica treino/validação.

Não otimiza regras de segurança automaticamente e nunca envia ordens.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Sequence

from smart_money_radar.analysis.backtesting import (
    BacktestConfig, BacktestReport, MarketBar, run_backtest,
)
from smart_money_radar.analysis.decision_engine import (
    DecisionCandidate, DecisionPolicy,
)


@dataclass(frozen=True)
class StrategyVariant:
    name: str
    config: BacktestConfig = BacktestConfig()
    policy: DecisionPolicy = DecisionPolicy()

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValueError("nome da estratégia obrigatório")


@dataclass(frozen=True)
class StrategyResult:
    name: str
    train: BacktestReport
    validation: BacktestReport
    eligible: bool
    validation_score: Decimal
    reasons: tuple[str, ...]


@dataclass(frozen=True)
class StrategyEvaluationReport:
    total_candidates: int
    train_candidates: int
    validation_candidates: int
    results: tuple[StrategyResult, ...]
    ranked_names: tuple[str, ...]
    warning: str


def evaluate_strategies(
    candidates: Sequence[DecisionCandidate],
    bars: Sequence[MarketBar],
    variants: Sequence[StrategyVariant],
    *,
    validation_fraction: Decimal = Decimal("0.30"),
    minimum_validation_trades: int = 5,
) -> StrategyEvaluationReport:
    """Compara variantes em janela posterior não usada na ordenação do treino.

    A classificação usa somente a janela de validação. O score penaliza drawdown
    (retorno percentual menos 0,5x drawdown percentual). Não é uma previsão.
    """
    if not Decimal("0.10") <= validation_fraction <= Decimal("0.50"):
        raise ValueError("validation_fraction deve ficar entre 0.10 e 0.50")
    if minimum_validation_trades < 1:
        raise ValueError("minimum_validation_trades deve ser >= 1")
    if not variants:
        raise ValueError("informe ao menos uma estratégia")
    names = [variant.name for variant in variants]
    if len(names) != len(set(names)):
        raise ValueError("nomes de estratégias devem ser únicos")

    ordered = sorted(candidates, key=lambda item: item.evaluated_at)
    if len(ordered) < 2:
        raise ValueError("são necessários ao menos dois candidatos para separar as janelas")
    split = int(len(ordered) * (Decimal(1) - validation_fraction))
    split = min(max(split, 1), len(ordered) - 1)
    train_candidates, validation_candidates = ordered[:split], ordered[split:]

    results: list[StrategyResult] = []
    for variant in variants:
        train_report = run_backtest(train_candidates, bars, config=variant.config, policy=variant.policy)
        validation_report = run_backtest(validation_candidates, bars, config=variant.config, policy=variant.policy)
        reasons: list[str] = []
        if train_report.trade_count == 0:
            reasons.append("sem_operacoes_na_janela_de_treino")
        if validation_report.trade_count < minimum_validation_trades:
            reasons.append("amostra_de_validacao_insuficiente")
        if validation_report.unresolved_candidates:
            reasons.append("candidatos_sem_desfecho_historico_suficiente")
        score = validation_report.total_return_pct - (validation_report.max_drawdown_pct * Decimal("0.5"))
        eligible = not reasons
        results.append(StrategyResult(variant.name, train_report, validation_report,
                                      eligible, score, tuple(reasons)))

    ranked = sorted((result for result in results if result.eligible),
                    key=lambda result: (result.validation_score, result.validation.total_return_pct),
                    reverse=True)
    return StrategyEvaluationReport(
        len(ordered), len(train_candidates), len(validation_candidates), tuple(results),
        tuple(result.name for result in ranked),
        "Comparação histórica offline; validação não garante desempenho futuro. "
        "Amostras pequenas ou sem dados completos não devem orientar capital real.",
    )
