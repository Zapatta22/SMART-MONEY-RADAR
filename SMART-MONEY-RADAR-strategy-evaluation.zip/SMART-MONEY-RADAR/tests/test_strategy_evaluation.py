from datetime import datetime, timedelta, timezone
from decimal import Decimal
import unittest

from smart_money_radar.analysis.backtesting import BacktestConfig, MarketBar
from smart_money_radar.analysis.decision_engine import DecisionCandidate, DecisionPolicy, EntryMode
from smart_money_radar.analysis.strategy_evaluation import StrategyVariant, evaluate_strategies


class StrategyEvaluationTests(unittest.TestCase):
    def setUp(self):
        self.start = datetime(2026, 1, 1, tzinfo=timezone.utc)
        self.candidates = []
        self.bars = []
        for i in range(20):
            at = self.start + timedelta(minutes=i * 20)
            self.candidates.append(DecisionCandidate(
                candidate_id=f"c{i}", token_mint=f"mint{i}", detected_at=at,
                evaluated_at=at, current_price=Decimal("1"), price_at_detection=Decimal("1"),
                liquidity_quote=Decimal("50000"), current_volume_quote=Decimal("5000"),
                baseline_volume_quote=Decimal("1000"), realized_volatility=Decimal("0.02"),
                smart_money_score=90, safety_checks={
                    "mint_authority_disabled": True, "freeze_authority_disabled": True,
                    "liquidity_lock_verified": True, "honeypot_check": True}))
            self.bars.append(MarketBar(f"mint{i}", at + timedelta(minutes=16), Decimal("1.10")))

    def test_separates_chronological_windows_and_ranks_eligible(self):
        variants = [StrategyVariant("immediate", BacktestConfig(entry_mode=EntryMode.IMMEDIATE)),
                    StrategyVariant("confirmed", BacktestConfig(entry_mode=EntryMode.CONFIRMED))]
        report = evaluate_strategies(self.candidates, self.bars, variants, minimum_validation_trades=2)
        self.assertEqual(report.train_candidates + report.validation_candidates, 20)
        self.assertEqual(report.validation_candidates, 6)
        self.assertTrue(report.ranked_names)
        self.assertEqual(len(report.results), 2)

    def test_insufficient_validation_sample_is_not_ranked(self):
        report = evaluate_strategies(self.candidates[:4], self.bars, [StrategyVariant("x")],
                                     minimum_validation_trades=5)
        self.assertFalse(report.results[0].eligible)
        self.assertEqual(report.ranked_names, ())

    def test_rejects_duplicate_names(self):
        with self.assertRaises(ValueError):
            evaluate_strategies(self.candidates, self.bars,
                                [StrategyVariant("same"), StrategyVariant("same")])

    def test_rejects_single_candidate(self):
        with self.assertRaises(ValueError):
            evaluate_strategies(self.candidates[:1], self.bars, [StrategyVariant("x")])

    def test_rejects_invalid_validation_fraction(self):
        with self.assertRaises(ValueError):
            evaluate_strategies(self.candidates, self.bars, [StrategyVariant("x")],
                                validation_fraction=Decimal("0.05"))

    def test_rejects_no_variants(self):
        with self.assertRaises(ValueError):
            evaluate_strategies(self.candidates, self.bars, [])

    def test_reports_unresolved_validation_outcomes(self):
        report = evaluate_strategies(self.candidates, [], [StrategyVariant("x")],
                                     minimum_validation_trades=1)
        self.assertIn("amostra_de_validacao_insuficiente", report.results[0].reasons)

    def test_policy_is_preserved_per_variant(self):
        strict = DecisionPolicy(minimum_smart_money_score=99)
        report = evaluate_strategies(self.candidates, self.bars,
                                     [StrategyVariant("strict", policy=strict)],
                                     minimum_validation_trades=1)
        self.assertEqual(report.results[0].validation.blocked_candidates, 6)


if __name__ == "__main__":
    unittest.main()
