"""Tipos de domínio para endereços públicos e eventos observados."""

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Literal


@dataclass(frozen=True)
class Wallet:
    """Identifica uma carteira por seu endereço público, sem guardar credenciais."""

    address: str
    label: str | None = None

    def __post_init__(self) -> None:
        if not self.address.strip():
            raise ValueError("O endereço público da carteira não pode estar vazio.")


@dataclass(frozen=True)
class ActivityEvent:
    """Representa um evento de atividade já obtido por uma fonte de dados."""

    wallet_address: str
    signature: str
    occurred_at: datetime | None
    token_mint: str
    direction: Literal["in", "out"]
    amount: Decimal

    def __post_init__(self) -> None:
        if not self.wallet_address.strip():
            raise ValueError("O endereço público da carteira não pode estar vazio.")
        if not self.signature.strip():
            raise ValueError("A assinatura do evento não pode estar vazia.")
        if not self.token_mint.strip():
            raise ValueError("O mint do token não pode estar vazio.")
        if self.direction not in {"in", "out"}:
            raise ValueError("A direção deve ser 'in' ou 'out'.")
        if not self.amount.is_finite() or self.amount < 0:
            raise ValueError("O valor do evento não pode ser negativo.")
