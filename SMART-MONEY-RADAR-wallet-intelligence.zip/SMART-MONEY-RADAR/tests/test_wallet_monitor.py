import asyncio
import json
import unittest
from decimal import Decimal

from smart_money_radar.domain.models import Wallet
from smart_money_radar.services.wallet_monitor import WalletMonitor
from smart_money_radar.settings import HeliusSettings
from smart_money_radar.storage.event_store import SQLiteEventStore
from smart_money_radar.storage.telemetry_store import TelemetryStore


def simulated_transaction() -> dict[str, object]:
    return {
        "blockTime": 1_730_000_000,
        "meta": {
            "err": None,
            "preTokenBalances": [],
            "postTokenBalances": [
                {
                    "owner": "public-wallet",
                    "mint": "mint-demo",
                    "uiTokenAmount": {"amount": "1230000", "decimals": 6},
                }
            ],
            "innerInstructions": [],
        },
        "transaction": {
            "message": {
                "instructions": [],
            }
        },
    }


class FakeWebSocket:
    def __init__(self, messages: list[str], stop_event: asyncio.Event) -> None:
        self.messages = list(messages)
        self.stop_event = stop_event
        self.sent: list[dict[str, object]] = []

    async def __aenter__(self) -> "FakeWebSocket":
        return self

    async def __aexit__(self, *_: object) -> None:
        return None

    async def send(self, raw: str) -> None:
        self.sent.append(json.loads(raw))

    async def recv(self) -> str:
        if self.messages:
            return self.messages.pop(0)
        await self.stop_event.wait()
        return ""


class FakeDataSource:
    def __init__(self, stop_event: asyncio.Event) -> None:
        self.stop_event = stop_event
        self.signatures: list[str] = []

    async def get_transaction_async(self, signature: str) -> dict[str, object]:
        self.signatures.append(signature)
        self.stop_event.set()
        return simulated_transaction()


class WalletMonitorTests(unittest.IsolatedAsyncioTestCase):
    async def test_subscription_enriches_and_stores_transaction_without_network(self) -> None:
        stop_event = asyncio.Event()
        messages = [
            json.dumps({"jsonrpc": "2.0", "id": 1, "result": 42}),
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "method": "logsNotification",
                    "params": {
                        "subscription": 42,
                        "result": {
                            "value": {
                                "signature": "simulated-signature",
                                "err": None,
                                "logs": [],
                            }
                        },
                    },
                }
            ),
        ]
        websocket = FakeWebSocket(messages, stop_event)
        data_source = FakeDataSource(stop_event)
        settings = HeliusSettings(api_key="simulated-key")
        # A file-backed temporary database is used because the store opens a
        # fresh SQLite connection for each operation.
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as directory:
            store = SQLiteEventStore(Path(directory) / "history.sqlite3")
            telemetry = TelemetryStore(Path(directory) / "telemetry.sqlite3")
            monitor = WalletMonitor(
                settings,
                data_source,  # type: ignore[arg-type]
                store,
                telemetry_store=telemetry,
                websocket_connector=lambda *_args, **_kwargs: websocket,
            )

            await monitor.run_forever([Wallet("public-wallet")], stop_event)

            self.assertEqual(
                websocket.sent[0]["method"],
                "logsSubscribe",
            )
            self.assertEqual(
                websocket.sent[0]["params"][0],
                {"mentions": ["public-wallet"]},
            )
            self.assertEqual(data_source.signatures, ["simulated-signature"])
            events = store.get_events(wallet_address="public-wallet")
            self.assertEqual(len(events), 1)
            self.assertEqual(events[0].token_mint, "mint-demo")
            self.assertEqual(events[0].direction, "in")
            self.assertEqual(events[0].amount, Decimal("1.23"))
            latency = telemetry.latency_summary()
            self.assertEqual(latency["completed_events"], 1)
            self.assertGreaterEqual(latency["avg_detection_to_analysis_ms"], 0)
            self.assertGreaterEqual(latency["avg_analysis_to_persist_ms"], 0)
            self.assertEqual(telemetry.connection_summary()["connected"], 1)

    async def test_reconnects_with_exponential_backoff(self) -> None:
        stop_event = asyncio.Event()
        data_source = FakeDataSource(stop_event)
        messages = [
            json.dumps({"jsonrpc": "2.0", "id": 1, "result": 7}),
            json.dumps(
                {
                    "method": "logsNotification",
                    "params": {
                        "subscription": 7,
                        "result": {
                            "value": {
                                "signature": "simulated-signature",
                                "err": None,
                            }
                        },
                    },
                }
            ),
        ]
        websocket = FakeWebSocket(messages, stop_event)
        attempts = 0
        delays: list[float] = []

        def connector(*_args: object, **_kwargs: object) -> FakeWebSocket:
            nonlocal attempts
            attempts += 1
            if attempts <= 2:
                raise OSError("simulated disconnect")
            return websocket

        async def no_wait(delay: float) -> None:
            delays.append(delay)

        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as directory:
            monitor = WalletMonitor(
                HeliusSettings(api_key="simulated-key"),
                data_source,  # type: ignore[arg-type]
                SQLiteEventStore(Path(directory) / "history.sqlite3"),
                initial_backoff_seconds=1,
                maximum_backoff_seconds=4,
                websocket_connector=connector,
                sleep=no_wait,
            )

            await monitor.run_forever([Wallet("public-wallet")], stop_event)

        self.assertEqual(attempts, 3)
        self.assertEqual(delays, [1, 2])
        self.assertEqual(data_source.signatures, ["simulated-signature"])


if __name__ == "__main__":
    unittest.main()
