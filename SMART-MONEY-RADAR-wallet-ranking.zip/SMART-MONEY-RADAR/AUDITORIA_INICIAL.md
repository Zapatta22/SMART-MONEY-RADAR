# SMR — auditoria da base e da etapa Wallet Intelligence

Data: 16/11/2026

## Resultado desta execução

- A base mais recente de telemetria integrada foi recuperada do pacote ZIP anterior e preservada.
- Implementado o primeiro núcleo de Wallet Intelligence e a persistência dos snapshots no SQLite.
- 30 testes automatizados executados localmente: todos passaram.
- Testes executados com dados sintéticos e mocks; nenhuma chamada real à Solana/Helius.
- Nenhuma chave API, chave privada, frase-semente ou banco pessoal foi incluído no pacote.
- O comando `smr intelligence` foi adicionado para análise local sem rede.

## Funcionalidades implementadas

1. Perfil por carteira: quantidade de eventos, mints distintos, dias ativos, primeira/última observação e frequência de assinaturas únicas por dia ativo.
2. Métricas por mint: contagem e quantidade de entradas/saídas, mediana e p90 dos tamanhos observados. Unidades de mints diferentes não são somadas.
3. Relevância relativa: identifica observações no p90 por mint quando há pelo menos cinco amostras.
4. Relações heurísticas: assinaturas compartilhadas, coatividade no mesmo mint/direção em janela padrão de 120 segundos e mints em comum; as evidências ficam explícitas.
5. Avaliador FIFO para execuções normalizadas com preço USD e taxas: PnL realizado, win rate por venda conciliada, tempo de retenção e posições/vendas não conciliadas por mint.
6. Snapshots SQLite para perfis, relações e desempenho quando fornecido.
7. CLI `smr intelligence` para analisar o histórico local e persistir snapshots sem API key ou autorização de rede.

## Limitações e interpretação correta

- O score de relação é heurístico e não calibrado estatisticamente. Não é uma probabilidade validada e não prova identidade, coordenação ou controle comum.
- O parser Helius ainda não produz fills de swap com preço USD confiável. Portanto, o avaliador FIFO está implementado e testado com dados simulados, mas ainda não calcula PnL real das carteiras coletadas.
- Deltas de saldo e transferências não equivalem necessariamente a compras/vendas; podem representar transferências, airdrops, depósitos/retiradas de pools ou outras atividades.
- Não há ainda cálculo de PnL não realizado, drawdown, slippage, retorno líquido completo ou consistência 30/90/180 dias.
- A cobertura histórica depende dos endereços monitorados e do período de coleta. Não houve comparação com o conteúdo atual do GitHub.

## Próximas dependências técnicas

1. Implementar decodificação/normalização robusta de swaps Solana e fills precificados, com taxas e ordem das execuções.
2. Alimentar o avaliador FIFO com dados reais e validar contra exploradores/fontes independentes.
3. Enriquecer relações com funding, contrapartes, autoridade, padrões de execução e sincronização entre carteiras independentes.
4. Calibrar score de associação e confiabilidade com conjunto histórico rotulado; até lá, manter o score apenas como evidência auxiliar.
5. Só depois construir classificação Smart Money, Launch Radar, Market Radar, Decision Engine, Risk Manager, Portfolio Manager e simulação de estratégias.

## Segurança e validação

O pacote continua somente leitura. Nenhum envio ou assinatura de transação foi adicionado. O desenvolvimento e os testes desta etapa não fizeram chamadas externas nem consumiram créditos Helius. A aprovação dos 30 testes confirma apenas a consistência do código coberto pelos testes; não significa prontidão para operação real ou financeira.
