"""Análises locais sobre eventos já fornecidos ao sistema."""
