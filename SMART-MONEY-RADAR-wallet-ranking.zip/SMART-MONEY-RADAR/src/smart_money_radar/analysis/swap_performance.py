"""Performance FIFO para swaps cujo ativo de cotação é o mesmo (ex.: SOL).

Não converte moedas nem mistura mints/unidades de cotação diferentes.
"""
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Iterable

from smart_money_radar.domain.models import SwapExecution


@dataclass(frozen=True)
class SwapWalletPerformance:
    wallet_address: str
    quote_mint: str
    matched_sell_fills: int
    winning_sell_fills: int
    win_rate: float | None
    realized_pnl_quote: Decimal
    network_fees_included: bool
    average_holding_seconds: float | None
    unmatched_sell_quantities: tuple[tuple[str, Decimal], ...]
    open_positions: tuple[tuple[str, Decimal], ...]


@dataclass
class _Lot:
    quantity: Decimal
    cost_per_token: Decimal
    opened_at: datetime
    fee_per_token: Decimal


def evaluate_swap_performance(executions: Iterable[SwapExecution]) -> tuple[SwapWalletPerformance, ...]:
    """Calcula PnL realizado em unidade de cotação, com FIFO e taxas em SOL.

    Para manter comparabilidade, cada carteira é agrupada por quote_mint. Swaps
    com quote_mint diferente nunca são somados. Taxa de rede em SOL só é
    subtraída quando a cotação também é SOL.
    """
    groups: dict[tuple[str, str], list[SwapExecution]] = defaultdict(list)
    for execution in executions:
        groups[(execution.wallet_address, execution.quote_mint)].append(execution)

    reports: list[SwapWalletPerformance] = []
    for (wallet, quote_mint), fills in sorted(groups.items()):
        lots: dict[str, deque[_Lot]] = defaultdict(deque)
        pnl_total = Decimal("0")
        matched = wins = 0
        holding: list[float] = []
        unmatched: dict[str, Decimal] = defaultdict(Decimal)

        for fill in sorted(fills, key=lambda item: (item.occurred_at, item.signature)):
            # Taxa em SOL não é conversível automaticamente para outra cotação.
            fee = fill.fee_sol if quote_mint == "SOL" else Decimal("0")
            if fill.side == "buy":
                lots[fill.token_mint].append(_Lot(
                    fill.token_quantity,
                    (fill.quote_quantity + fee) / fill.token_quantity,
                    fill.occurred_at,
                    fee / fill.token_quantity,
                ))
                continue

            remaining = fill.token_quantity
            sell_fee_per_token = fee / fill.token_quantity
            fill_pnl = Decimal("0")
            while remaining > 0 and lots[fill.token_mint]:
                lot = lots[fill.token_mint][0]
                quantity = min(remaining, lot.quantity)
                # Custo de entrada inclui taxa; receita de saída desconta taxa.
                fill_pnl += (fill.price_quote - sell_fee_per_token - lot.cost_per_token) * quantity
                holding.append((fill.occurred_at - lot.opened_at).total_seconds())
                lot.quantity -= quantity
                remaining -= quantity
                if lot.quantity == 0:
                    lots[fill.token_mint].popleft()
            if remaining < fill.token_quantity:
                matched += 1
                wins += int(fill_pnl > 0)
                pnl_total += fill_pnl
            if remaining > 0:
                unmatched[fill.token_mint] += remaining

        open_positions = tuple(sorted(
            (mint, sum((lot.quantity for lot in queue), Decimal("0")))
            for mint, queue in lots.items() if queue
        ))
        reports.append(SwapWalletPerformance(
            wallet_address=wallet, quote_mint=quote_mint,
            matched_sell_fills=matched, winning_sell_fills=wins,
            win_rate=(wins / matched) if matched else None,
            realized_pnl_quote=pnl_total,
            network_fees_included=(quote_mint == "SOL"),
            average_holding_seconds=(sum(holding) / len(holding)) if holding else None,
            unmatched_sell_quantities=tuple(sorted(unmatched.items())),
            open_positions=open_positions,
        ))
    return tuple(reports)
