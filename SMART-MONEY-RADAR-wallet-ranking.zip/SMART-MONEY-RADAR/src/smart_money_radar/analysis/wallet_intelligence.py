"""Métricas históricas e relações heurísticas entre carteiras públicas.

Este módulo descreve atividade observada. Não presume que cada delta seja um
trade, não estima preços e não produz sinais de compra ou venda.
"""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
from itertools import combinations
from math import ceil
from statistics import median
from typing import Literal, Iterable

from smart_money_radar.domain.models import ActivityEvent


@dataclass(frozen=True)
class TokenActivityMetrics:
    token_mint: str
    event_count: int
    inflow_count: int
    outflow_count: int
    inflow_amount: Decimal
    outflow_amount: Decimal
    median_event_amount: Decimal
    p90_event_amount: Decimal | None
    large_event_count: int


@dataclass(frozen=True)
class WalletProfile:
    wallet_address: str
    event_count: int
    unique_tokens: int
    active_days: int
    first_seen: datetime | None
    last_seen: datetime | None
    transactions_per_active_day: float
    median_transaction_interval_seconds: float | None
    inflow_event_count: int
    outflow_event_count: int
    token_metrics: tuple[TokenActivityMetrics, ...]


@dataclass(frozen=True)
class WalletRelationship:
    wallet_a: str
    wallet_b: str
    association_score: int
    shared_signature_count: int
    coactivity_match_count: int
    shared_mints: tuple[str, ...]
    evidence: tuple[str, ...]
    score_kind: str = "heuristic_not_calibrated_probability"


@dataclass(frozen=True)
class PricedExecution:
    """Execução normalizada com preço; ainda não é alimentada pelo parser Helius."""

    wallet_address: str
    signature: str
    occurred_at: datetime
    token_mint: str
    side: Literal["buy", "sell"]
    quantity: Decimal
    price_usd: Decimal
    fee_usd: Decimal = Decimal("0")

    def __post_init__(self) -> None:
        if not self.wallet_address.strip() or not self.signature.strip() or not self.token_mint.strip():
            raise ValueError("Carteira, assinatura e mint são obrigatórios.")
        if self.side not in {"buy", "sell"}:
            raise ValueError("O lado deve ser 'buy' ou 'sell'.")
        if self.occurred_at.tzinfo is None or self.occurred_at.utcoffset() is None:
            raise ValueError("A execução precisa de timestamp com fuso horário.")
        for name, value in (("quantity", self.quantity), ("price_usd", self.price_usd)):
            if not value.is_finite() or value <= 0:
                raise ValueError(f"{name} deve ser positivo e finito.")
        if not self.fee_usd.is_finite() or self.fee_usd < 0:
            raise ValueError("fee_usd não pode ser negativo ou não finito.")


@dataclass(frozen=True)
class WalletPerformance:
    wallet_address: str
    matched_sell_fills: int
    winning_sell_fills: int
    win_rate: float | None
    realized_pnl_usd: Decimal
    average_holding_seconds: float | None
    unmatched_sells_by_mint: tuple[tuple[str, Decimal], ...]
    open_positions_by_mint: tuple[tuple[str, Decimal], ...]


@dataclass(frozen=True)
class IntelligenceReport:
    generated_at: datetime
    event_count: int
    profiles: tuple[WalletProfile, ...]
    relationships: tuple[WalletRelationship, ...]
    performances: tuple[WalletPerformance, ...]
    limitations: tuple[str, ...]


@dataclass
class _OpenLot:
    quantity: Decimal
    price_usd: Decimal
    occurred_at: datetime
    fee_per_unit_usd: Decimal


def _aware_utc(value: datetime | None) -> datetime | None:
    if value is None or value.tzinfo is None or value.utcoffset() is None:
        return None
    return value.astimezone(timezone.utc)


def _percentile_90(values: list[Decimal]) -> Decimal:
    ordered = sorted(values)
    return ordered[max(0, ceil(0.90 * len(ordered)) - 1)]


def build_wallet_profile(wallet_address: str, events: Iterable[ActivityEvent]) -> WalletProfile:
    """Calcula métricas sem somar unidades de mints diferentes."""
    wallet_events = [event for event in events if event.wallet_address == wallet_address]
    token_events: dict[str, list[ActivityEvent]] = defaultdict(list)
    timestamps: list[datetime] = []
    transaction_times: dict[str, datetime] = {}
    active_days: set[object] = set()
    inflow_count = 0
    outflow_count = 0

    for event in wallet_events:
        token_events[event.token_mint].append(event)
        if event.direction == "in":
            inflow_count += 1
        else:
            outflow_count += 1
        timestamp = _aware_utc(event.occurred_at)
        if timestamp is not None:
            timestamps.append(timestamp)
            active_days.add(timestamp.date())
            transaction_times[event.signature] = min(
                timestamp, transaction_times.get(event.signature, timestamp)
            )

    ordered_transaction_times = sorted(transaction_times.values())
    intervals = [
        (right - left).total_seconds()
        for left, right in zip(ordered_transaction_times, ordered_transaction_times[1:])
        if right >= left
    ]

    token_metrics: list[TokenActivityMetrics] = []
    for mint, mint_events in sorted(token_events.items()):
        amounts = [event.amount for event in mint_events]
        p90 = _percentile_90(amounts) if len(amounts) >= 5 else None
        token_metrics.append(
            TokenActivityMetrics(
                token_mint=mint,
                event_count=len(mint_events),
                inflow_count=sum(event.direction == "in" for event in mint_events),
                outflow_count=sum(event.direction == "out" for event in mint_events),
                inflow_amount=sum(
                    (event.amount for event in mint_events if event.direction == "in"),
                    Decimal("0"),
                ),
                outflow_amount=sum(
                    (event.amount for event in mint_events if event.direction == "out"),
                    Decimal("0"),
                ),
                median_event_amount=Decimal(str(median(amounts))) if amounts else Decimal("0"),
                p90_event_amount=p90,
                large_event_count=sum(amount >= p90 for amount in amounts) if p90 is not None else 0,
            )
        )

    first_seen = timestamps[0] if timestamps else None
    last_seen = timestamps[-1] if timestamps else None
    active_day_count = len(active_days)
    return WalletProfile(
        wallet_address=wallet_address,
        event_count=len(wallet_events),
        unique_tokens=len(token_events),
        active_days=active_day_count,
        first_seen=first_seen,
        last_seen=last_seen,
        transactions_per_active_day=(len(transaction_times) / active_day_count) if active_day_count else 0.0,
        median_transaction_interval_seconds=float(median(intervals)) if intervals else None,
        inflow_event_count=inflow_count,
        outflow_event_count=outflow_count,
        token_metrics=tuple(token_metrics),
    )


def _coactivity_matches(
    events_a: list[ActivityEvent],
    events_b: list[ActivityEvent],
    window_seconds: int,
    excluded_signatures: set[str],
) -> set[tuple[str, str, str, str]]:
    """Pares distintos de assinaturas no mesmo mint/direção e janela temporal."""
    by_key_a: dict[tuple[str, str], list[tuple[datetime, str]]] = defaultdict(list)
    by_key_b: dict[tuple[str, str], list[tuple[datetime, str]]] = defaultdict(list)
    for event in events_a:
        timestamp = _aware_utc(event.occurred_at)
        if timestamp is not None and event.signature not in excluded_signatures:
            by_key_a[(event.token_mint, event.direction)].append((timestamp, event.signature))
    for event in events_b:
        timestamp = _aware_utc(event.occurred_at)
        if timestamp is not None and event.signature not in excluded_signatures:
            by_key_b[(event.token_mint, event.direction)].append((timestamp, event.signature))

    matches: set[tuple[str, str, str, str]] = set()
    for key in by_key_a.keys() & by_key_b.keys():
        left = sorted(by_key_a[key])
        right = sorted(by_key_b[key])
        start = 0
        for time_a, signature_a in left:
            while start < len(right) and (time_a - right[start][0]).total_seconds() > window_seconds:
                start += 1
            index = start
            while index < len(right) and (right[index][0] - time_a).total_seconds() <= window_seconds:
                time_b, signature_b = right[index]
                if signature_a != signature_b:
                    matches.add((key[0], key[1], signature_a, signature_b))
                index += 1
    return matches


def find_wallet_relationships(
    events: Iterable[ActivityEvent],
    *,
    coactivity_window_seconds: int = 120,
    minimum_score: int = 20,
) -> tuple[WalletRelationship, ...]:
    """Gera score de associação explicável; não é probabilidade estatística calibrada."""
    if coactivity_window_seconds < 0:
        raise ValueError("A janela de coatividade não pode ser negativa.")
    if not 0 <= minimum_score <= 100:
        raise ValueError("minimum_score deve estar entre 0 e 100.")

    by_wallet: dict[str, list[ActivityEvent]] = defaultdict(list)
    for event in events:
        by_wallet[event.wallet_address].append(event)

    results: list[WalletRelationship] = []
    for wallet_a, wallet_b in combinations(sorted(by_wallet), 2):
        events_a = by_wallet[wallet_a]
        events_b = by_wallet[wallet_b]
        signatures_a = {event.signature for event in events_a}
        signatures_b = {event.signature for event in events_b}
        shared_signatures = signatures_a & signatures_b
        mints_a = {event.token_mint for event in events_a}
        mints_b = {event.token_mint for event in events_b}
        shared_mints = tuple(sorted(mints_a & mints_b))
        coactivity = _coactivity_matches(
            events_a, events_b, coactivity_window_seconds, shared_signatures
        )

        score = min(50, 25 * len(shared_signatures))
        score += min(35, 10 * len(coactivity))
        score += min(15, 5 * len(shared_mints))
        score = min(100, score)
        if score < minimum_score:
            continue

        evidence: list[str] = []
        if shared_signatures:
            evidence.append(f"{len(shared_signatures)} assinatura(s) observada(s) nas duas carteiras")
        if coactivity:
            evidence.append(
                f"{len(coactivity)} coatividade(s) no mesmo mint/direção em até "
                f"{coactivity_window_seconds}s, com assinaturas distintas"
            )
        if shared_mints:
            evidence.append(f"{len(shared_mints)} mint(s) em comum; isoladamente é evidência fraca")
        results.append(
            WalletRelationship(
                wallet_a=wallet_a,
                wallet_b=wallet_b,
                association_score=score,
                shared_signature_count=len(shared_signatures),
                coactivity_match_count=len(coactivity),
                shared_mints=shared_mints,
                evidence=tuple(evidence),
            )
        )

    return tuple(sorted(results, key=lambda item: (-item.association_score, item.wallet_a, item.wallet_b)))


def evaluate_wallet_performance(executions: Iterable[PricedExecution]) -> tuple[WalletPerformance, ...]:
    """Calcula PnL realizado aproximado por FIFO somente com fills precificados.

    Inclui taxas informadas. Vendas sem inventário comprado no conjunto são
    reportadas como não conciliadas; posições abertas permanecem não realizadas.
    """
    by_wallet: dict[str, list[PricedExecution]] = defaultdict(list)
    for execution in executions:
        by_wallet[execution.wallet_address].append(execution)

    output: list[WalletPerformance] = []
    for wallet_address, wallet_executions in sorted(by_wallet.items()):
        lots: dict[str, deque[_OpenLot]] = defaultdict(deque)
        realized = Decimal("0")
        unmatched_sells: dict[str, Decimal] = defaultdict(Decimal)
        matched_sell_fills = 0
        winning_sell_fills = 0
        holding_durations: list[float] = []

        for execution in sorted(wallet_executions, key=lambda item: (item.occurred_at, item.signature)):
            if execution.side == "buy":
                fee_per_unit = execution.fee_usd / execution.quantity
                lots[execution.token_mint].append(
                    _OpenLot(execution.quantity, execution.price_usd, execution.occurred_at, fee_per_unit)
                )
                continue

            remaining = execution.quantity
            sell_fee_per_unit = execution.fee_usd / execution.quantity
            sell_pnl = Decimal("0")
            while remaining > 0 and lots[execution.token_mint]:
                lot = lots[execution.token_mint][0]
                matched_quantity = min(remaining, lot.quantity)
                entry_price = lot.price_usd
                entry_time = lot.occurred_at
                entry_fee_per_unit = lot.fee_per_unit_usd
                pnl = (execution.price_usd - entry_price) * matched_quantity
                pnl -= (entry_fee_per_unit + sell_fee_per_unit) * matched_quantity
                sell_pnl += pnl
                holding_durations.append((execution.occurred_at - entry_time).total_seconds())
                lot.quantity -= matched_quantity
                remaining -= matched_quantity
                if lot.quantity == 0:
                    lots[execution.token_mint].popleft()

            if remaining < execution.quantity:
                matched_sell_fills += 1
                if sell_pnl > 0:
                    winning_sell_fills += 1
                realized += sell_pnl
            if remaining > 0:
                unmatched_sells[execution.token_mint] += remaining

        open_positions = {
            mint: sum((lot.quantity for lot in queue), Decimal("0"))
            for mint, queue in lots.items()
        }
        output.append(
            WalletPerformance(
                wallet_address=wallet_address,
                matched_sell_fills=matched_sell_fills,
                winning_sell_fills=winning_sell_fills,
                win_rate=(winning_sell_fills / matched_sell_fills) if matched_sell_fills else None,
                realized_pnl_usd=realized,
                average_holding_seconds=(sum(holding_durations) / len(holding_durations)) if holding_durations else None,
                unmatched_sells_by_mint=tuple(sorted(unmatched_sells.items())),
                open_positions_by_mint=tuple(sorted((mint, amount) for mint, amount in open_positions.items() if amount > 0)),
            )
        )
    return tuple(output)


class WalletIntelligenceAnalyzer:
    """Produz um retrato descritivo a partir do histórico SQLite já coletado."""

    def __init__(self, *, coactivity_window_seconds: int = 120, minimum_relation_score: int = 20) -> None:
        self.coactivity_window_seconds = coactivity_window_seconds
        self.minimum_relation_score = minimum_relation_score

    def analyze(
        self,
        events: Iterable[ActivityEvent],
        *,
        priced_executions: Iterable[PricedExecution] = (),
        generated_at: datetime | None = None,
    ) -> IntelligenceReport:
        materialized = list(events)
        wallets = sorted({event.wallet_address for event in materialized})
        profiles = tuple(build_wallet_profile(wallet, materialized) for wallet in wallets)
        relationships = find_wallet_relationships(
            materialized,
            coactivity_window_seconds=self.coactivity_window_seconds,
            minimum_score=self.minimum_relation_score,
        )
        performances = evaluate_wallet_performance(priced_executions)
        return IntelligenceReport(
            generated_at=generated_at or datetime.now(timezone.utc),
            event_count=len(materialized),
            profiles=profiles,
            relationships=relationships,
            performances=performances,
            limitations=(
                "Eventos são deltas de saldo/transferências; frequência é calculada por assinatura única e não equivale necessariamente a número de swaps.",
                "Quantidades de mints diferentes nunca são somadas nem comparadas como valor financeiro.",
                "O parser Helius ainda não fornece fills precificados; PnL/qualidade só aparecem quando execuções normalizadas com preço são fornecidas.",
                "Score de associação é heurístico e não calibrado; coatividade não prova controle comum ou coordenação.",
                "Cobertura depende apenas dos endereços e do período efetivamente monitorados.",
            ),
        )
