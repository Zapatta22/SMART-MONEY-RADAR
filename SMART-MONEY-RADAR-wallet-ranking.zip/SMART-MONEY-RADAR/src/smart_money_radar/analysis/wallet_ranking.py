"""Ranking explicável de carteiras; score heurístico, não probabilidade."""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable
from smart_money_radar.analysis.wallet_intelligence import WalletProfile, WalletPerformance, WalletRelationship

@dataclass(frozen=True)
class WalletRanking:
    wallet_address: str
    score: int
    confidence: str
    closed_fills: int
    win_rate: float | None
    realized_pnl: Decimal | None
    component_scores: tuple[tuple[str, int], ...]
    risk_flags: tuple[str, ...]
    limitations: tuple[str, ...]

def rank_wallets(profiles: Iterable[WalletProfile], performances: Iterable[WalletPerformance],
                 relationships: Iterable[WalletRelationship] = (), *, minimum_closed_fills: int = 5) -> tuple[WalletRanking, ...]:
    """Combina qualidade observada e tamanho da amostra sem comparar moedas."""
    if minimum_closed_fills < 1:
        raise ValueError("minimum_closed_fills deve ser >= 1")
    perf_by_wallet = {p.wallet_address: p for p in performances}
    relation_by_wallet: dict[str, list[WalletRelationship]] = {}
    for relation in relationships:
        relation_by_wallet.setdefault(relation.wallet_a, []).append(relation)
        relation_by_wallet.setdefault(relation.wallet_b, []).append(relation)
    results = []
    for profile in profiles:
        perf = perf_by_wallet.get(profile.wallet_address)
        fills = perf.matched_sell_fills if perf else 0
        win = perf.win_rate if perf else None
        pnl = perf.realized_pnl_usd if perf else None
        win_score = round(max(0.0, min(1.0, win or 0.0)) * 30)
        sample_score = round(25 * min(1.0, fills / minimum_closed_fills))
        pnl_score = 20 if pnl is not None and pnl > 0 else (10 if pnl == 0 else 0)
        rate = profile.transactions_per_active_day
        activity_score = round(15 * max(0.0, 1.0 - abs(rate - 2.0) / 6.0)) if profile.active_days else 0
        coverage_score = 10 if profile.first_seen and profile.last_seen and profile.active_days >= 3 else (5 if profile.active_days else 0)
        components = (("win_rate", win_score), ("amostra", sample_score), ("pnl_positivo", pnl_score),
                      ("atividade", activity_score), ("cobertura", coverage_score))
        flags = []
        if perf is None or fills == 0: flags.append("sem_execucoes_de_venda_conciliadas")
        if perf and perf.unmatched_sells_by_mint: flags.append("vendas_sem_compra_correspondente_no_historico")
        if perf and perf.open_positions_by_mint: flags.append("posicoes_abertas_sem_pnl_nao_realizado")
        related = relation_by_wallet.get(profile.wallet_address, [])
        if related: flags.append("relacoes_heuristicas_exigem_revisao")
        if fills < minimum_closed_fills: flags.append("amostra_insuficiente")
        confidence = "alta" if fills >= 30 and profile.active_days >= 14 and not related else (
            "media" if fills >= minimum_closed_fills and profile.active_days >= 3 and not related else "baixa")
        limitations = ("Score heurístico de 0–100; não é probabilidade de lucro nem recomendação de compra.",
                       "PnL só é comparável dentro da mesma moeda/unidade de cotação; o ranking não soma moedas diferentes.",
                       "Sem preço histórico independente não há PnL não realizado, ROI sobre capital nem drawdown confiável.",
                       "Associação entre carteiras é evidência para revisão, não prova de controle comum.")
        results.append(WalletRanking(profile.wallet_address, sum(v for _, v in components), confidence,
                                      fills, win, pnl, components, tuple(flags), limitations))
    return tuple(sorted(results, key=lambda r: (-r.score, -r.closed_fills, r.wallet_address)))
