"""Interfaces e adaptadores de fontes de dados."""
