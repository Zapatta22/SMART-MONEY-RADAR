"""Extração conservadora de movimentações a partir de getTransaction."""

from collections import defaultdict
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any

from smart_money_radar.domain.models import ActivityEvent, SwapExecution

SOL_MINT = "SOL"
LAMPORTS_PER_SOL = Decimal("1000000000")


def parse_transaction(
    transaction: dict[str, Any],
    wallet_address: str,
    signature: str,
) -> list[ActivityEvent]:
    """Retorna deltas de tokens e transferências SOL explicitamente decodificadas.

    A função não tenta inferir valores de mercado nem classificar operações.
    Movimentações sem mint, owner ou instrução decodificável são ignoradas.
    """
    meta = transaction.get("meta")
    if not isinstance(meta, dict) or meta.get("err") is not None:
        return []

    occurred_at = _timestamp(transaction.get("blockTime"))
    events: list[ActivityEvent] = []
    before = _token_balances(meta.get("preTokenBalances"), wallet_address)
    after = _token_balances(meta.get("postTokenBalances"), wallet_address)

    for mint in sorted(before.keys() | after.keys()):
        delta = after.get(mint, Decimal("0")) - before.get(mint, Decimal("0"))
        if delta == 0:
            continue
        events.append(
            ActivityEvent(
                wallet_address=wallet_address,
                signature=signature,
                occurred_at=occurred_at,
                token_mint=mint,
                direction="in" if delta > 0 else "out",
                amount=abs(delta),
            )
        )

    sol_transfers = _sol_transfers(transaction, wallet_address)
    for direction, amount in sorted(sol_transfers.items()):
        if amount > 0:
            events.append(
                ActivityEvent(
                    wallet_address=wallet_address,
                    signature=signature,
                    occurred_at=occurred_at,
                    token_mint=SOL_MINT,
                    direction=direction,  # type: ignore[arg-type]
                    amount=amount,
                )
            )
    return events


def _timestamp(value: Any) -> datetime | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    try:
        return datetime.fromtimestamp(value, tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None


def _token_balances(value: Any, wallet_address: str) -> dict[str, Decimal]:
    balances: dict[str, Decimal] = defaultdict(Decimal)
    if not isinstance(value, list):
        return {}
    for entry in value:
        if not isinstance(entry, dict) or entry.get("owner") != wallet_address:
            continue
        mint = entry.get("mint")
        amount_info = entry.get("uiTokenAmount")
        if not isinstance(mint, str) or not mint or not isinstance(amount_info, dict):
            continue
        try:
            raw_amount = Decimal(str(amount_info["amount"]))
            decimals = int(amount_info["decimals"])
            if decimals < 0 or not raw_amount.is_finite() or raw_amount < 0:
                continue
            balances[mint] += raw_amount / (Decimal(10) ** decimals)
        except (KeyError, TypeError, ValueError, InvalidOperation, OverflowError):
            continue
    return dict(balances)


def _sol_transfers(
    transaction: dict[str, Any], wallet_address: str
) -> dict[str, Decimal]:
    totals: dict[str, Decimal] = defaultdict(Decimal)
    message = transaction.get("transaction")
    if not isinstance(message, dict):
        return {}
    message = message.get("message")
    if not isinstance(message, dict):
        return {}

    instructions = message.get("instructions")
    all_instructions = list(instructions) if isinstance(instructions, list) else []
    meta = transaction.get("meta")
    inner = meta.get("innerInstructions") if isinstance(meta, dict) else None
    if isinstance(inner, list):
        for group in inner:
            if isinstance(group, dict) and isinstance(group.get("instructions"), list):
                all_instructions.extend(group["instructions"])

    for instruction in all_instructions:
        if not isinstance(instruction, dict) or instruction.get("program") != "system":
            continue
        parsed = instruction.get("parsed")
        if not isinstance(parsed, dict) or parsed.get("type") not in {
            "transfer",
            "transferWithSeed",
        }:
            continue
        info = parsed.get("info")
        if not isinstance(info, dict):
            continue
        source = info.get("source")
        destination = info.get("destination")
        lamports = info.get("lamports")
        try:
            amount = Decimal(str(lamports)) / LAMPORTS_PER_SOL
        except (InvalidOperation, TypeError, ValueError):
            continue
        if not amount.is_finite() or amount <= 0:
            continue
        if source == wallet_address:
            totals["out"] += amount
        if destination == wallet_address:
            totals["in"] += amount
    return dict(totals)


def parse_swap_execution(
    transaction: dict[str, Any], wallet_address: str, signature: str
) -> SwapExecution | None:
    """Decodifica apenas swaps com um delta de token e um delta de SOL nativo claros.

    Retorna None em casos ambíguos (múltiplos tokens, transferências adicionais,
    token wrapped-SOL, saldo/owner ausente ou timestamp ausente). O preço é SOL/token.
    """
    meta = transaction.get("meta")
    if not isinstance(meta, dict) or meta.get("err") is not None:
        return None
    occurred_at = _timestamp(transaction.get("blockTime"))
    if occurred_at is None:
        return None
    before = _token_balances(meta.get("preTokenBalances"), wallet_address)
    after = _token_balances(meta.get("postTokenBalances"), wallet_address)
    token_deltas = {
        mint: after.get(mint, Decimal("0")) - before.get(mint, Decimal("0"))
        for mint in before.keys() | after.keys()
        if mint != SOL_MINT and after.get(mint, Decimal("0")) != before.get(mint, Decimal("0"))
    }
    if len(token_deltas) != 1:
        return None

    message = transaction.get("transaction")
    message = message.get("message") if isinstance(message, dict) else None
    keys = message.get("accountKeys") if isinstance(message, dict) else None
    if not isinstance(keys, list):
        return None
    wallet_index = None
    for index, key in enumerate(keys):
        pubkey = key.get("pubkey") if isinstance(key, dict) else key
        if pubkey == wallet_address:
            wallet_index = index
            break
    if wallet_index is None:
        return None
    pre, post = meta.get("preBalances"), meta.get("postBalances")
    if not isinstance(pre, list) or not isinstance(post, list) or wallet_index >= len(pre) or wallet_index >= len(post):
        return None
    try:
        delta_lamports = Decimal(str(post[wallet_index])) - Decimal(str(pre[wallet_index]))
        fee_lamports = Decimal(str(meta.get("fee", 0)))
        if wallet_index == 0:  # fee payer: remove network fee from SOL delta
            delta_lamports += fee_lamports
        if not delta_lamports.is_finite() or not fee_lamports.is_finite() or fee_lamports < 0:
            return None
    except (InvalidOperation, TypeError, ValueError):
        return None
    sol_delta = delta_lamports / LAMPORTS_PER_SOL
    token_mint, token_delta = next(iter(token_deltas.items()))
    if sol_delta == 0 or (sol_delta > 0) == (token_delta > 0):
        return None
    token_quantity, quote_quantity = abs(token_delta), abs(sol_delta)
    return SwapExecution(
        wallet_address=wallet_address,
        signature=signature,
        occurred_at=occurred_at,
        token_mint=token_mint,
        side="buy" if token_delta > 0 else "sell",
        token_quantity=token_quantity,
        quote_mint=SOL_MINT,
        quote_quantity=quote_quantity,
        price_quote=quote_quantity / token_quantity,
        fee_sol=fee_lamports / LAMPORTS_PER_SOL,
    )
