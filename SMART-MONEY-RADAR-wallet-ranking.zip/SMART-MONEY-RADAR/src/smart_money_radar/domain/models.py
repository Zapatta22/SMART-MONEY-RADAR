"""Tipos de domínio para endereços públicos e eventos observados."""

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Literal


@dataclass(frozen=True)
class Wallet:
    """Identifica uma carteira por seu endereço público, sem guardar credenciais."""

    address: str
    label: str | None = None

    def __post_init__(self) -> None:
        if not self.address.strip():
            raise ValueError("O endereço público da carteira não pode estar vazio.")


@dataclass(frozen=True)
class ActivityEvent:
    """Representa um evento de atividade já obtido por uma fonte de dados."""

    wallet_address: str
    signature: str
    occurred_at: datetime | None
    token_mint: str
    direction: Literal["in", "out"]
    amount: Decimal

    def __post_init__(self) -> None:
        if not self.wallet_address.strip():
            raise ValueError("O endereço público da carteira não pode estar vazio.")
        if not self.signature.strip():
            raise ValueError("A assinatura do evento não pode estar vazia.")
        if not self.token_mint.strip():
            raise ValueError("O mint do token não pode estar vazio.")
        if self.direction not in {"in", "out"}:
            raise ValueError("A direção deve ser 'in' ou 'out'.")
        if not self.amount.is_finite() or self.amount < 0:
            raise ValueError("O valor do evento não pode ser negativo.")


@dataclass(frozen=True)
class SwapExecution:
    """Swap inferido de deltas inequívocos de SOL nativo e um único token.

    O preço é expresso em SOL por unidade do token; não é preço USD.
    """

    wallet_address: str
    signature: str
    occurred_at: datetime
    token_mint: str
    side: Literal["buy", "sell"]
    token_quantity: Decimal
    quote_mint: str
    quote_quantity: Decimal
    price_quote: Decimal
    fee_sol: Decimal
    evidence: str = "native_sol_balance_delta_plus_single_token_delta"

    def __post_init__(self) -> None:
        if not all((self.wallet_address.strip(), self.signature.strip(), self.token_mint.strip())):
            raise ValueError("Carteira, assinatura e mint são obrigatórios.")
        if self.side not in {"buy", "sell"}:
            raise ValueError("O lado deve ser 'buy' ou 'sell'.")
        if self.occurred_at.tzinfo is None or self.occurred_at.utcoffset() is None:
            raise ValueError("A execução precisa de timestamp com fuso horário.")
        for name, value in (("token_quantity", self.token_quantity), ("quote_quantity", self.quote_quantity), ("price_quote", self.price_quote)):
            if not value.is_finite() or value <= 0:
                raise ValueError(f"{name} deve ser positivo e finito.")
        if not self.fee_sol.is_finite() or self.fee_sol < 0:
            raise ValueError("fee_sol não pode ser negativo ou não finito.")
