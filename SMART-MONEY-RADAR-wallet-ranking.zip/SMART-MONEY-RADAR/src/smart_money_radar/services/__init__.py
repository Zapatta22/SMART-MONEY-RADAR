"""Serviços de aplicação."""
