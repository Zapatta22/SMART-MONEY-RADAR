"""Monitor WebSocket de carteiras com reconexão exponencial."""

import asyncio
import json
import logging
import time
from datetime import datetime, timezone
from collections.abc import Callable, Sequence
from typing import Any

from websockets import connect

from smart_money_radar.data_sources.helius import HeliusDataSource
from smart_money_radar.data_sources.transaction_parser import parse_transaction, parse_swap_execution
from smart_money_radar.domain.models import Wallet
from smart_money_radar.settings import HeliusSettings
from smart_money_radar.storage.event_store import SQLiteEventStore
from smart_money_radar.storage.telemetry_store import TelemetryStore
from smart_money_radar.storage.swap_store import SQLiteSwapStore

Logger = logging.Logger


class WalletMonitor:
    """Assina logs de carteiras públicas, enriquece assinaturas e persiste eventos."""

    def __init__(
        self,
        settings: HeliusSettings,
        data_source: HeliusDataSource,
        event_store: SQLiteEventStore,
        *,
        telemetry_store: TelemetryStore | None = None,
        swap_store: SQLiteSwapStore | None = None,
        initial_backoff_seconds: float = 1.0,
        maximum_backoff_seconds: float = 30.0,
        stable_session_seconds: float = 60.0,
        websocket_connector: Callable[..., Any] | None = None,
        sleep: Callable[[float], Any] = asyncio.sleep,
        logger: Logger | None = None,
    ) -> None:
        if initial_backoff_seconds <= 0 or maximum_backoff_seconds < initial_backoff_seconds:
            raise ValueError("Parâmetros de backoff inválidos.")
        self.settings = settings
        self.data_source = data_source
        self.event_store = event_store
        self.telemetry_store = telemetry_store
        self.swap_store = swap_store
        self.initial_backoff_seconds = initial_backoff_seconds
        self.maximum_backoff_seconds = maximum_backoff_seconds
        self.stable_session_seconds = stable_session_seconds
        self._websocket_connector = websocket_connector or connect
        self._sleep = sleep
        self._logger = logger or logging.getLogger(__name__)

    async def run_forever(
        self,
        wallets: Sequence[Wallet],
        stop_event: asyncio.Event,
    ) -> None:
        addresses = list(dict.fromkeys(wallet.address for wallet in wallets))
        if not addresses:
            raise ValueError("Informe ao menos um endereço público para monitorar.")

        delay = self.initial_backoff_seconds
        while not stop_event.is_set():
            started_at = time.monotonic()
            try:
                await self._listen_once(addresses, stop_event)
                if stop_event.is_set():
                    return
                raise ConnectionError("A sessão WebSocket terminou inesperadamente.")
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                if stop_event.is_set():
                    return
                elapsed = time.monotonic() - started_at
                if elapsed >= self.stable_session_seconds:
                    delay = self.initial_backoff_seconds
                self._record_telemetry("record_connection_event", "disconnected", type(exc).__name__)
                self._record_telemetry("record_connection_event", "reconnect_attempt", type(exc).__name__)
                self._logger.warning(
                    "WebSocket Helius desconectado; nova tentativa em %.1fs (%s).",
                    delay,
                    type(exc).__name__,
                )
                if await self._wait_or_stop(stop_event, delay):
                    return
                delay = min(delay * 2, self.maximum_backoff_seconds)

    async def _listen_once(
        self,
        wallet_addresses: Sequence[str],
        stop_event: asyncio.Event,
    ) -> None:
        request_to_wallet: dict[int, str] = {}
        subscription_to_wallet: dict[int, str] = {}
        async with self._websocket_connector(
            self.settings.websocket_url,
            ping_interval=30,
            ping_timeout=20,
            open_timeout=10,
            max_size=1_048_576,
        ) as websocket:
            for request_id, address in enumerate(wallet_addresses, start=1):
                request_to_wallet[request_id] = address
                await websocket.send(
                    json.dumps(
                        {
                            "jsonrpc": "2.0",
                            "id": request_id,
                            "method": "logsSubscribe",
                            "params": [
                                {"mentions": [address]},
                                {"commitment": "confirmed"},
                            ],
                        }
                    )
                )

            self._record_telemetry("record_connection_event", "connected")
            self._logger.info(
                "Conectado ao WebSocket Helius; aguardando confirmações para %d carteira(s).",
                len(wallet_addresses),
            )
            while not stop_event.is_set():
                raw_message = await self._receive_or_stop(websocket, stop_event)
                if raw_message is None:
                    return
                try:
                    message = json.loads(raw_message)
                except (json.JSONDecodeError, TypeError):
                    self._logger.warning("Mensagem WebSocket inválida; ignorada.")
                    continue
                if not isinstance(message, dict):
                    continue

                if "id" in message:
                    self._handle_subscription_response(
                        message, request_to_wallet, subscription_to_wallet
                    )
                    continue

                notification = message.get("params")
                if not isinstance(notification, dict):
                    continue
                wallet_address = subscription_to_wallet.get(notification.get("subscription"))
                result = notification.get("result")
                value = result.get("value") if isinstance(result, dict) else None
                if not wallet_address or not isinstance(value, dict):
                    continue
                if value.get("err") is not None:
                    continue
                signature = value.get("signature")
                if not isinstance(signature, str) or not signature:
                    continue
                detected_at = datetime.now(timezone.utc)
                self._record_telemetry(
                    "record_detection", wallet_address, signature, at=detected_at
                )
                await self._collect_transaction(wallet_address, signature)

    def _handle_subscription_response(
        self,
        message: dict[str, Any],
        request_to_wallet: dict[int, str],
        subscription_to_wallet: dict[int, str],
    ) -> None:
        request_id = message.get("id")
        if not isinstance(request_id, int) or request_id not in request_to_wallet:
            return
        if "error" in message:
            error = message["error"]
            code = error.get("code") if isinstance(error, dict) else None
            raise RuntimeError(
                f"Helius recusou uma assinatura logsSubscribe (código {code})."
            )
        subscription_id = message.get("result")
        if not isinstance(subscription_id, int):
            raise RuntimeError("Resposta logsSubscribe sem ID de assinatura.")
        subscription_to_wallet[subscription_id] = request_to_wallet[request_id]

    async def _collect_transaction(self, wallet_address: str, signature: str) -> None:
        try:
            transaction = await self.data_source.get_transaction_async(signature)
        except Exception as exc:
            self._logger.warning(
                "Falha ao consultar detalhes de uma transação (%s).",
                type(exc).__name__,
            )
            return
        if transaction is None:
            self._logger.info("Detalhes da transação ainda indisponíveis; evento ignorado.")
            return
        events = parse_transaction(transaction, wallet_address, signature)
        swap = parse_swap_execution(transaction, wallet_address, signature)
        analyzed_at = datetime.now(timezone.utc)
        self._record_telemetry(
            "record_analysis", wallet_address, signature, len(events), at=analyzed_at
        )
        inserted = self.event_store.save_events(events)
        swap_inserted = self.swap_store.save_executions([swap] if swap is not None else []) if self.swap_store else 0
        self._record_telemetry(
            "record_persisted", wallet_address, signature,
            at=datetime.now(timezone.utc),
        )
        if inserted or swap_inserted:
            self._logger.info(
                "Persistidos %d evento(s) de atividade e %d swap(s) normalizado(s).",
                inserted, swap_inserted,
            )

    def _record_telemetry(self, method: str, *args: Any, **kwargs: Any) -> None:
        """Telemetria nunca deve interromper a captura principal."""
        if self.telemetry_store is None:
            return
        try:
            getattr(self.telemetry_store, method)(*args, **kwargs)
        except Exception as exc:
            self._logger.warning("Falha ao gravar telemetria (%s).", type(exc).__name__)

    async def _receive_or_stop(self, websocket: Any, stop_event: asyncio.Event) -> Any:
        receive_task = asyncio.create_task(websocket.recv())
        stop_task = asyncio.create_task(stop_event.wait())
        done, pending = await asyncio.wait(
            {receive_task, stop_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        if stop_task in done and stop_event.is_set():
            return None
        return receive_task.result()

    async def _wait_or_stop(self, stop_event: asyncio.Event, delay: float) -> bool:
        if stop_event.is_set():
            return True
        sleep_task = asyncio.create_task(self._sleep(delay))
        stop_task = asyncio.create_task(stop_event.wait())
        done, pending = await asyncio.wait(
            {sleep_task, stop_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        return stop_task in done
