"""Persistência local do histórico coletado."""
