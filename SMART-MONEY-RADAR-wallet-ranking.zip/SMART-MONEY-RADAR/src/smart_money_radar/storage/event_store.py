"""Armazenamento histórico SQLite, com deduplicação local de eventos."""

import sqlite3
from contextlib import closing
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from smart_money_radar.domain.models import ActivityEvent


class SQLiteEventStore:
    """Persiste eventos sem armazenar chaves ou credenciais."""

    def __init__(self, database_path: Path | str) -> None:
        self.database_path = Path(database_path)
        if str(self.database_path) != ":memory:":
            self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.database_path)

    def _initialize(self) -> None:
        with closing(self._connect()) as connection:
            with connection:
                connection.execute(
                    """
                    CREATE TABLE IF NOT EXISTS activity_events (
                        id INTEGER PRIMARY KEY,
                        wallet_address TEXT NOT NULL,
                        signature TEXT NOT NULL,
                        occurred_at TEXT,
                        token_mint TEXT NOT NULL,
                        direction TEXT NOT NULL CHECK (direction IN ('in', 'out')),
                        amount TEXT NOT NULL,
                        UNIQUE (wallet_address, signature, token_mint, direction)
                    )
                    """
                )
                connection.execute(
                    """
                    CREATE INDEX IF NOT EXISTS idx_activity_wallet_time
                    ON activity_events (wallet_address, occurred_at DESC)
                    """
                )

    def save_events(self, events: list[ActivityEvent]) -> int:
        """Grava eventos e retorna quantos registros novos foram inseridos."""
        rows = [
            (
                event.wallet_address,
                event.signature,
                event.occurred_at.isoformat() if event.occurred_at else None,
                event.token_mint,
                event.direction,
                str(event.amount),
            )
            for event in events
        ]
        if not rows:
            return 0
        with closing(self._connect()) as connection:
            with connection:
                before = connection.total_changes
                connection.executemany(
                    """
                    INSERT OR IGNORE INTO activity_events
                        (wallet_address, signature, occurred_at, token_mint, direction, amount)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    rows,
                )
                return connection.total_changes - before

    def get_events(
        self, *, wallet_address: str | None = None, limit: int = 100
    ) -> list[ActivityEvent]:
        if limit < 1:
            raise ValueError("O limite deve ser maior que zero.")
        query = """
            SELECT wallet_address, signature, occurred_at, token_mint, direction, amount
            FROM activity_events
        """
        parameters: tuple[object, ...]
        if wallet_address is not None:
            query += " WHERE wallet_address = ?"
            parameters = (wallet_address, limit)
        else:
            parameters = (limit,)
        query += " ORDER BY occurred_at DESC, id DESC LIMIT ?"
        with closing(self._connect()) as connection:
            rows = connection.execute(query, parameters).fetchall()
        return [
            ActivityEvent(
                wallet_address=row[0],
                signature=row[1],
                occurred_at=datetime.fromisoformat(row[2]) if row[2] else None,
                token_mint=row[3],
                direction=row[4],
                amount=Decimal(row[5]),
            )
            for row in rows
        ]
