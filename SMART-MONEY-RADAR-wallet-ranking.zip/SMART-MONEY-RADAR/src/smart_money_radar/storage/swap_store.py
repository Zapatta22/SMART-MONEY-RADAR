"""Persistência SQLite de swaps normalizados, sem credenciais ou chamadas externas."""

import sqlite3
from contextlib import closing
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from smart_money_radar.domain.models import SwapExecution


class SQLiteSwapStore:
    def __init__(self, database_path: Path | str) -> None:
        self.database_path = Path(database_path)
        if str(self.database_path) != ":memory:":
            self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.database_path)

    def _initialize(self) -> None:
        with closing(self._connect()) as connection, connection:
            connection.execute(
                """CREATE TABLE IF NOT EXISTS swap_executions (
                    id INTEGER PRIMARY KEY, wallet_address TEXT NOT NULL, signature TEXT NOT NULL,
                    occurred_at TEXT NOT NULL, token_mint TEXT NOT NULL, side TEXT NOT NULL CHECK(side IN ('buy','sell')),
                    token_quantity TEXT NOT NULL, quote_mint TEXT NOT NULL, quote_quantity TEXT NOT NULL,
                    price_quote TEXT NOT NULL, fee_sol TEXT NOT NULL, evidence TEXT NOT NULL,
                    UNIQUE(wallet_address, signature, token_mint))"""
            )
            connection.execute("CREATE INDEX IF NOT EXISTS idx_swaps_wallet_time ON swap_executions(wallet_address, occurred_at DESC)")

    def save_executions(self, executions: list[SwapExecution]) -> int:
        rows = [(e.wallet_address,e.signature,e.occurred_at.isoformat(),e.token_mint,e.side,
                 str(e.token_quantity),e.quote_mint,str(e.quote_quantity),str(e.price_quote),str(e.fee_sol),e.evidence) for e in executions]
        if not rows: return 0
        with closing(self._connect()) as connection, connection:
            before=connection.total_changes
            connection.executemany("""INSERT OR IGNORE INTO swap_executions
                (wallet_address,signature,occurred_at,token_mint,side,token_quantity,quote_mint,quote_quantity,price_quote,fee_sol,evidence)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)""", rows)
            return connection.total_changes-before

    def get_executions(self, *, wallet_address: str | None = None, limit: int = 100000) -> list[SwapExecution]:
        if limit < 1: raise ValueError("O limite deve ser maior que zero.")
        query="SELECT wallet_address,signature,occurred_at,token_mint,side,token_quantity,quote_mint,quote_quantity,price_quote,fee_sol,evidence FROM swap_executions"
        params: tuple[object,...]=(limit,)
        if wallet_address is not None:
            query += " WHERE wallet_address = ?"; params=(wallet_address,limit)
        query += " ORDER BY occurred_at, signature LIMIT ?"
        with closing(self._connect()) as connection:
            rows=connection.execute(query,params).fetchall()
        return [SwapExecution(wallet_address=r[0],signature=r[1],occurred_at=datetime.fromisoformat(r[2]),token_mint=r[3],side=r[4],token_quantity=Decimal(r[5]),quote_mint=r[6],quote_quantity=Decimal(r[7]),price_quote=Decimal(r[8]),fee_sol=Decimal(r[9]),evidence=r[10]) for r in rows]
