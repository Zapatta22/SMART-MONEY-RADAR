"""Persistência de snapshots de métricas e relações do Wallet Intelligence."""

from __future__ import annotations

import json
import sqlite3
from contextlib import closing
from dataclasses import asdict
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

from smart_money_radar.analysis.wallet_intelligence import IntelligenceReport


class WalletIntelligenceStore:
    """Guarda snapshots derivados sem alterar o histórico bruto de eventos."""

    def __init__(self, database_path: Path | str) -> None:
        self.database_path = Path(database_path)
        if str(self.database_path) != ":memory:":
            self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.database_path)

    def _initialize(self) -> None:
        with closing(self._connect()) as connection:
            with connection:
                connection.execute(
                    """CREATE TABLE IF NOT EXISTS wallet_profile_snapshots (
                        id INTEGER PRIMARY KEY,
                        wallet_address TEXT NOT NULL,
                        analyzed_at TEXT NOT NULL,
                        metrics_json TEXT NOT NULL
                    )"""
                )
                connection.execute(
                    """CREATE INDEX IF NOT EXISTS idx_wallet_profile_latest
                    ON wallet_profile_snapshots(wallet_address, analyzed_at DESC)"""
                )
                connection.execute(
                    """CREATE TABLE IF NOT EXISTS wallet_performance_snapshots (
                        id INTEGER PRIMARY KEY,
                        wallet_address TEXT NOT NULL,
                        analyzed_at TEXT NOT NULL,
                        realized_pnl_usd TEXT NOT NULL,
                        metrics_json TEXT NOT NULL
                    )"""
                )
                connection.execute(
                    """CREATE INDEX IF NOT EXISTS idx_wallet_performance_latest
                    ON wallet_performance_snapshots(wallet_address, analyzed_at DESC)"""
                )
                connection.execute(
                    """CREATE TABLE IF NOT EXISTS wallet_relationship_snapshots (
                        id INTEGER PRIMARY KEY,
                        wallet_a TEXT NOT NULL,
                        wallet_b TEXT NOT NULL,
                        analyzed_at TEXT NOT NULL,
                        association_score INTEGER NOT NULL,
                        evidence_json TEXT NOT NULL
                    )"""
                )
                connection.execute(
                    """CREATE INDEX IF NOT EXISTS idx_wallet_relationship_latest
                    ON wallet_relationship_snapshots(wallet_a, wallet_b, analyzed_at DESC)"""
                )

    @staticmethod
    def _profile_payload(profile: Any) -> dict[str, Any]:
        payload = asdict(profile)
        for field in ("first_seen", "last_seen"):
            value = payload[field]
            payload[field] = value.isoformat() if value else None
        payload["token_metrics"] = [
            {
                key: (str(value) if isinstance(value, Decimal) else value)
                for key, value in metric.items()
            }
            for metric in payload["token_metrics"]
        ]
        return payload

    def save_report(self, report: IntelligenceReport) -> tuple[int, int, int]:
        analyzed_at = report.generated_at.isoformat()
        profile_rows = [
            (profile.wallet_address, analyzed_at, json.dumps(self._profile_payload(profile), sort_keys=True))
            for profile in report.profiles
        ]
        performance_rows = [
            (
                performance.wallet_address,
                analyzed_at,
                str(performance.realized_pnl_usd),
                json.dumps(
                    {
                        "matched_sell_fills": performance.matched_sell_fills,
                        "winning_sell_fills": performance.winning_sell_fills,
                        "win_rate": performance.win_rate,
                        "average_holding_seconds": performance.average_holding_seconds,
                        "unmatched_sells_by_mint": [
                            [mint, str(quantity)] for mint, quantity in performance.unmatched_sells_by_mint
                        ],
                        "open_positions_by_mint": [
                            [mint, str(quantity)] for mint, quantity in performance.open_positions_by_mint
                        ],
                    },
                    sort_keys=True,
                ),
            )
            for performance in report.performances
        ]
        relationship_rows = [
            (
                relationship.wallet_a,
                relationship.wallet_b,
                analyzed_at,
                relationship.association_score,
                json.dumps(
                    {
                        "shared_signature_count": relationship.shared_signature_count,
                        "coactivity_match_count": relationship.coactivity_match_count,
                        "shared_mints": list(relationship.shared_mints),
                        "evidence": list(relationship.evidence),
                        "score_kind": relationship.score_kind,
                    },
                    sort_keys=True,
                ),
            )
            for relationship in report.relationships
        ]
        with closing(self._connect()) as connection:
            with connection:
                connection.executemany(
                    "INSERT INTO wallet_profile_snapshots(wallet_address, analyzed_at, metrics_json) VALUES (?, ?, ?)",
                    profile_rows,
                )
                connection.executemany(
                    """INSERT INTO wallet_performance_snapshots
                    (wallet_address, analyzed_at, realized_pnl_usd, metrics_json)
                    VALUES (?, ?, ?, ?)""",
                    performance_rows,
                )
                connection.executemany(
                    """INSERT INTO wallet_relationship_snapshots
                    (wallet_a, wallet_b, analyzed_at, association_score, evidence_json)
                    VALUES (?, ?, ?, ?, ?)""",
                    relationship_rows,
                )
        return len(profile_rows), len(relationship_rows), len(performance_rows)

    def get_latest_profile(self, wallet_address: str) -> dict[str, Any] | None:
        with closing(self._connect()) as connection:
            row = connection.execute(
                """SELECT analyzed_at, metrics_json FROM wallet_profile_snapshots
                WHERE wallet_address = ? ORDER BY analyzed_at DESC, id DESC LIMIT 1""",
                (wallet_address,),
            ).fetchone()
        if row is None:
            return None
        return {"analyzed_at": row[0], "metrics": json.loads(row[1])}

    def get_latest_relationships(self, *, limit: int = 100) -> list[dict[str, Any]]:
        if limit < 1:
            raise ValueError("O limite deve ser maior que zero.")
        with closing(self._connect()) as connection:
            rows = connection.execute(
                """SELECT wallet_a, wallet_b, analyzed_at, association_score, evidence_json
                FROM wallet_relationship_snapshots
                ORDER BY analyzed_at DESC, association_score DESC, id DESC LIMIT ?""",
                (limit,),
            ).fetchall()
        return [
            {
                "wallet_a": row[0],
                "wallet_b": row[1],
                "analyzed_at": row[2],
                "association_score": row[3],
                "evidence": json.loads(row[4]),
            }
            for row in rows
        ]

    def get_latest_performance(self, wallet_address: str) -> dict[str, Any] | None:
        with closing(self._connect()) as connection:
            row = connection.execute(
                """SELECT analyzed_at, realized_pnl_usd, metrics_json
                FROM wallet_performance_snapshots WHERE wallet_address = ?
                ORDER BY analyzed_at DESC, id DESC LIMIT 1""",
                (wallet_address,),
            ).fetchone()
        if row is None:
            return None
        return {
            "analyzed_at": row[0],
            "realized_pnl_usd": row[1],
            "metrics": json.loads(row[2]),
        }
