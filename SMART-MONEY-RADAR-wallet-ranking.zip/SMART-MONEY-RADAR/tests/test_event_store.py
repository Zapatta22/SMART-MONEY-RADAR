import tempfile
import unittest
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

from smart_money_radar.domain.models import ActivityEvent
from smart_money_radar.storage.event_store import SQLiteEventStore


class SQLiteEventStoreTests(unittest.TestCase):
    def test_persists_events_and_ignores_duplicates(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = SQLiteEventStore(Path(directory) / "history.sqlite3")
            event = ActivityEvent(
                wallet_address="public-wallet",
                signature="simulated-signature",
                occurred_at=datetime(2026, 11, 7, tzinfo=timezone.utc),
                token_mint="mint-a",
                direction="in",
                amount=Decimal("1.25"),
            )

            self.assertEqual(store.save_events([event]), 1)
            self.assertEqual(store.save_events([event]), 0)
            self.assertEqual(store.get_events(wallet_address="public-wallet"), [event])

    def test_allows_unknown_time_from_rpc(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = SQLiteEventStore(Path(directory) / "history.sqlite3")
            event = ActivityEvent(
                wallet_address="public-wallet",
                signature="simulated-signature",
                occurred_at=None,
                token_mint="mint-a",
                direction="out",
                amount=Decimal("0.5"),
            )

            store.save_events([event])

            self.assertEqual(store.get_events()[0], event)


if __name__ == "__main__":
    unittest.main()
