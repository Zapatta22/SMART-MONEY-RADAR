import unittest
from decimal import Decimal

from smart_money_radar.data_sources.transaction_parser import parse_swap_execution


class SwapDecoderTests(unittest.TestCase):
    def fixture(self):
        wallet = "wallet-public"
        tx = {
            "blockTime": 1_730_000_000,
            "meta": {
                "err": None,
                "fee": 5000,
                "preBalances": [10_000_000_000],
                "postBalances": [8_999_995_000],
                "preTokenBalances": [{"owner": wallet, "mint": "token-A", "uiTokenAmount": {"amount": "0", "decimals": 6}}],
                "postTokenBalances": [{"owner": wallet, "mint": "token-A", "uiTokenAmount": {"amount": "2000000", "decimals": 6}}],
            },
            "transaction": {"message": {"accountKeys": [{"pubkey": wallet}]}}
        }
        return wallet, tx

    def test_decodes_buy_and_removes_network_fee_from_quote_delta(self):
        wallet, tx = self.fixture()
        swap = parse_swap_execution(tx, wallet, "sig-buy")
        self.assertIsNotNone(swap)
        self.assertEqual(swap.side, "buy")
        self.assertEqual(swap.token_quantity, Decimal("2"))
        self.assertEqual(swap.quote_quantity, Decimal("1"))
        self.assertEqual(swap.price_quote, Decimal("0.5"))
        self.assertEqual(swap.fee_sol, Decimal("0.000005"))

    def test_decodes_sell(self):
        wallet, tx = self.fixture()
        tx["meta"]["preTokenBalances"], tx["meta"]["postTokenBalances"] = tx["meta"]["postTokenBalances"], tx["meta"]["preTokenBalances"]
        tx["meta"]["preBalances"], tx["meta"]["postBalances"] = [8_999_995_000], [10_999_990_000]
        swap = parse_swap_execution(tx, wallet, "sig-sell")
        self.assertEqual(swap.side, "sell")
        self.assertEqual(swap.quote_quantity, Decimal("2"))

    def test_rejects_multiple_token_deltas(self):
        wallet, tx = self.fixture()
        tx["meta"]["postTokenBalances"].append({"owner": wallet, "mint": "token-B", "uiTokenAmount": {"amount": "100", "decimals": 2}})
        self.assertIsNone(parse_swap_execution(tx, wallet, "sig-ambiguous"))

    def test_rejects_failed_or_untimed_transactions(self):
        wallet, tx = self.fixture()
        tx["meta"]["err"] = {"InstructionError": [0, "Custom"]}
        self.assertIsNone(parse_swap_execution(tx, wallet, "sig-failed"))
        tx["meta"]["err"] = None
        tx.pop("blockTime")
        self.assertIsNone(parse_swap_execution(tx, wallet, "sig-no-time"))


if __name__ == "__main__":
    unittest.main()
