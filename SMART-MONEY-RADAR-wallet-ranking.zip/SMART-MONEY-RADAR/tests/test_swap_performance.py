import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from smart_money_radar.domain.models import SwapExecution
from smart_money_radar.analysis.swap_performance import evaluate_swap_performance


class SwapPerformanceTests(unittest.TestCase):
    def fill(self, sig, side, qty, quote, seconds, fee="0.000005", mint="TOKEN", quote_mint="SOL"):
        return SwapExecution("wallet", sig, datetime(2026, 1, 1, tzinfo=timezone.utc)+timedelta(seconds=seconds), mint, side, Decimal(qty), quote_mint, Decimal(quote), Decimal(quote)/Decimal(qty), Decimal(fee))

    def test_fifo_pnl_in_quote_currency_and_open_inventory(self):
        fills=[self.fill("b1","buy","10","1",0), self.fill("s1","sell","4","0.8",60)]
        result=evaluate_swap_performance(fills)[0]
        self.assertEqual(result.realized_pnl_quote, Decimal("0.39999300"))
        self.assertEqual(result.open_positions, (("TOKEN",Decimal("6")),))
        self.assertEqual(result.matched_sell_fills,1)
        self.assertEqual(result.win_rate,1.0)

    def test_unmatched_sell_is_reported_not_counted_as_loss(self):
        result=evaluate_swap_performance([self.fill("s1","sell","2","1",60)])[0]
        self.assertEqual(result.matched_sell_fills,0)
        self.assertEqual(result.unmatched_sell_quantities,(("TOKEN",Decimal("2")),))
        self.assertIsNone(result.win_rate)

    def test_different_quote_assets_are_not_aggregated(self):
        fills=[self.fill("b1","buy","1","2",0,quote_mint="USDC"), self.fill("s1","sell","1","3",60,quote_mint="USDC")]
        result=evaluate_swap_performance(fills)[0]
        self.assertEqual(result.quote_mint,"USDC")
        self.assertEqual(result.realized_pnl_quote,Decimal("1"))

if __name__ == "__main__": unittest.main()
