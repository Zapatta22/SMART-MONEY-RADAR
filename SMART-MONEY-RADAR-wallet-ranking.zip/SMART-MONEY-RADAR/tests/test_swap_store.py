import tempfile
import unittest
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

from smart_money_radar.domain.models import SwapExecution
from smart_money_radar.storage.swap_store import SQLiteSwapStore

class SwapStoreTests(unittest.TestCase):
    def test_round_trip_and_deduplication(self):
        with tempfile.TemporaryDirectory() as directory:
            store=SQLiteSwapStore(Path(directory)/"history.sqlite3")
            item=SwapExecution("wallet","sig",datetime(2026,1,1,tzinfo=timezone.utc),"mint","buy",Decimal("2"),"SOL",Decimal("1"),Decimal("0.5"),Decimal("0.000005"))
            self.assertEqual(store.save_executions([item]),1)
            self.assertEqual(store.save_executions([item]),0)
            result=store.get_executions()
            self.assertEqual(len(result),1)
            self.assertEqual(result[0].price_quote,Decimal("0.5"))
            self.assertEqual(result[0].side,"buy")

if __name__ == "__main__": unittest.main()
