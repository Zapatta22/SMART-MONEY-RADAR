import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path

from smart_money_radar.analysis.wallet_intelligence import (
    PricedExecution,
    WalletIntelligenceAnalyzer,
    build_wallet_profile,
    evaluate_wallet_performance,
    find_wallet_relationships,
)
from smart_money_radar.domain.models import ActivityEvent
from smart_money_radar.storage.wallet_intelligence_store import WalletIntelligenceStore


class WalletProfileTests(unittest.TestCase):
    def test_profile_counts_frequency_and_relative_event_size_per_mint(self) -> None:
        start = datetime(2026, 11, 1, tzinfo=timezone.utc)
        events = [
            ActivityEvent("wallet-a", f"sig-{index}", start + timedelta(days=index), "mint-a", "in" if index % 2 == 0 else "out", Decimal(index))
            for index in range(1, 6)
        ]
        events.append(
            ActivityEvent("wallet-a", "sig-other", start + timedelta(days=5), "mint-b", "in", Decimal("1000000"))
        )

        profile = build_wallet_profile("wallet-a", events)

        self.assertEqual(profile.event_count, 6)
        self.assertEqual(profile.unique_tokens, 2)
        self.assertEqual(profile.active_days, 5)
        self.assertEqual(profile.transactions_per_active_day, 1.2)
        self.assertEqual(profile.median_transaction_interval_seconds, 86400.0)
        mint_a = next(item for item in profile.token_metrics if item.token_mint == "mint-a")
        self.assertEqual(mint_a.median_event_amount, Decimal("3"))
        self.assertEqual(mint_a.p90_event_amount, Decimal("5"))
        self.assertEqual(mint_a.large_event_count, 1)
        self.assertEqual(mint_a.inflow_amount + mint_a.outflow_amount, Decimal("15"))

    def test_unknown_or_naive_timestamps_do_not_count_as_active_days(self) -> None:
        event = ActivityEvent("wallet-a", "sig", datetime(2026, 11, 1), "mint-a", "in", Decimal("1"))
        profile = build_wallet_profile("wallet-a", [event])
        self.assertEqual(profile.event_count, 1)
        self.assertEqual(profile.active_days, 0)
        self.assertIsNone(profile.first_seen)


class WalletRelationshipTests(unittest.TestCase):
    def test_detects_repeated_coactivity_and_explains_heuristic_score(self) -> None:
        start = datetime(2026, 11, 1, tzinfo=timezone.utc)
        events = [
            ActivityEvent("wallet-a", "shared-signature", start, "mint-a", "in", Decimal("1")),
            ActivityEvent("wallet-b", "shared-signature", start, "mint-a", "in", Decimal("1")),
            ActivityEvent("wallet-a", "sig-a-2", start + timedelta(seconds=30), "mint-a", "in", Decimal("2")),
            ActivityEvent("wallet-b", "sig-b-2", start + timedelta(seconds=50), "mint-a", "in", Decimal("3")),
        ]

        relationships = find_wallet_relationships(events)

        self.assertEqual(len(relationships), 1)
        relationship = relationships[0]
        self.assertEqual(relationship.shared_signature_count, 1)
        self.assertEqual(relationship.coactivity_match_count, 1)
        self.assertEqual(relationship.association_score, 40)
        self.assertIn("heuristic", relationship.score_kind)
        self.assertTrue(relationship.evidence)

    def test_common_mint_alone_is_not_enough_to_flag_relation(self) -> None:
        start = datetime(2026, 11, 1, tzinfo=timezone.utc)
        events = [
            ActivityEvent("wallet-a", "sig-a", start, "mint-a", "in", Decimal("1")),
            ActivityEvent("wallet-b", "sig-b", start + timedelta(hours=3), "mint-a", "in", Decimal("1")),
        ]
        self.assertEqual(find_wallet_relationships(events), ())


class WalletPerformanceTests(unittest.TestCase):
    def test_fifo_realized_pnl_includes_buy_and_sell_fees(self) -> None:
        start = datetime(2026, 11, 1, tzinfo=timezone.utc)
        executions = [
            PricedExecution("wallet-a", "buy-1", start, "mint-a", "buy", Decimal("10"), Decimal("2"), Decimal("1")),
            PricedExecution("wallet-a", "sell-1", start + timedelta(hours=1), "mint-a", "sell", Decimal("4"), Decimal("3"), Decimal("0.4")),
        ]

        performance = evaluate_wallet_performance(executions)[0]

        self.assertEqual(performance.realized_pnl_usd, Decimal("3.2"))
        self.assertEqual(performance.matched_sell_fills, 1)
        self.assertEqual(performance.winning_sell_fills, 1)
        self.assertEqual(performance.win_rate, 1.0)
        self.assertEqual(performance.average_holding_seconds, 3600.0)
        self.assertEqual(performance.open_positions_by_mint, (("mint-a", Decimal("6")),))
        self.assertEqual(performance.unmatched_sells_by_mint, ())

    def test_sell_without_known_inventory_is_reported_as_unmatched(self) -> None:
        execution = PricedExecution(
            "wallet-a", "sell", datetime(2026, 11, 1, tzinfo=timezone.utc),
            "mint-a", "sell", Decimal("5"), Decimal("1"),
        )
        performance = evaluate_wallet_performance([execution])[0]
        self.assertEqual(performance.realized_pnl_usd, Decimal("0"))
        self.assertEqual(performance.unmatched_sells_by_mint, (("mint-a", Decimal("5")),))
        self.assertIsNone(performance.win_rate)

    def test_priced_execution_rejects_naive_timestamp(self) -> None:
        with self.assertRaises(ValueError):
            PricedExecution(
                "wallet-a", "sig", datetime(2026, 11, 1), "mint-a", "buy",
                Decimal("1"), Decimal("1"),
            )


class WalletIntelligenceStoreTests(unittest.TestCase):
    def test_persists_optional_priced_performance_when_supplied(self) -> None:
        start = datetime(2026, 11, 1, tzinfo=timezone.utc)
        executions = [
            PricedExecution("wallet-a", "buy", start, "mint-a", "buy", Decimal("2"), Decimal("1")),
            PricedExecution("wallet-a", "sell", start + timedelta(minutes=5), "mint-a", "sell", Decimal("2"), Decimal("2")),
        ]
        report = WalletIntelligenceAnalyzer().analyze([], priced_executions=executions, generated_at=start)
        with tempfile.TemporaryDirectory() as directory:
            store = WalletIntelligenceStore(Path(directory) / "history.sqlite3")
            self.assertEqual(store.save_report(report), (0, 0, 1))
            performance = store.get_latest_performance("wallet-a")
            self.assertIsNotNone(performance)
            self.assertEqual(performance["realized_pnl_usd"], "2")
            self.assertEqual(performance["metrics"]["matched_sell_fills"], 1)

    def test_persists_profile_and_relationship_snapshots(self) -> None:
        start = datetime(2026, 11, 1, tzinfo=timezone.utc)
        events = [
            ActivityEvent("wallet-a", "shared", start, "mint-a", "in", Decimal("1")),
            ActivityEvent("wallet-b", "shared", start, "mint-a", "in", Decimal("1")),
        ]
        report = WalletIntelligenceAnalyzer().analyze(events, generated_at=start)

        with tempfile.TemporaryDirectory() as directory:
            store = WalletIntelligenceStore(Path(directory) / "history.sqlite3")
            self.assertEqual(store.save_report(report), (2, 1, 0))
            latest = store.get_latest_profile("wallet-a")
            self.assertIsNotNone(latest)
            self.assertEqual(latest["metrics"]["event_count"], 1)
            relationships = store.get_latest_relationships()
            self.assertEqual(len(relationships), 1)
            self.assertEqual(relationships[0]["association_score"], 30)


if __name__ == "__main__":
    unittest.main()
