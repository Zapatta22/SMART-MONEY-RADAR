import contextlib
import io
import tempfile
import unittest
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

from smart_money_radar.cli import main
from smart_money_radar.domain.models import ActivityEvent
from smart_money_radar.storage.event_store import SQLiteEventStore


class WalletIntelligenceCliTests(unittest.TestCase):
    def test_intelligence_command_analyzes_and_reports_saved_wallet_history(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            database = Path(directory) / "history.sqlite3"
            event_store = SQLiteEventStore(database)
            timestamp = datetime(2026, 11, 16, tzinfo=timezone.utc)
            event_store.save_events([
                ActivityEvent("wallet-a", "shared-signature", timestamp, "mint-a", "in", Decimal("1")),
                ActivityEvent("wallet-b", "shared-signature", timestamp, "mint-a", "in", Decimal("2")),
            ])
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                main(["intelligence", "--database", str(database)])
            self.assertIn("Eventos analisados: 2", output.getvalue())
            self.assertIn("Carteiras: 2 | relações heurísticas: 1", output.getvalue())
            self.assertIn("score heurístico 30/100", output.getvalue())

    def test_intelligence_command_uses_local_database_without_network(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            database = Path(directory) / "empty-history.sqlite3"
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                main(["intelligence", "--database", str(database)])
            self.assertIn("Eventos analisados: 0", output.getvalue())
            self.assertIn("Snapshots gravados: 0 perfis", output.getvalue())
            self.assertTrue(database.exists())


if __name__ == "__main__":
    unittest.main()
