import unittest
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from smart_money_radar.analysis.wallet_intelligence import build_wallet_profile, WalletPerformance, WalletRelationship
from smart_money_radar.analysis.wallet_ranking import rank_wallets
from smart_money_radar.domain.models import ActivityEvent

class WalletRankingTests(unittest.TestCase):
    def profile(self, wallet, count=8):
        base=datetime(2026,1,1,tzinfo=timezone.utc)
        events=[ActivityEvent(wallet,f"s{i}",base+timedelta(days=i),"mint","in",Decimal("1")) for i in range(count)]
        return build_wallet_profile(wallet,events)
    def perf(self,wallet,fills=8,win=.75,pnl="2"):
        return WalletPerformance(wallet,fills,round(fills*win),win,Decimal(pnl),120,(),())
    def test_ranking_orders_quality_and_sample(self):
        ranked=rank_wallets([self.profile("good"),self.profile("weak")],
                            [self.perf("good",10,.8,"5"),self.perf("weak",2,.5,"-1")])
        self.assertEqual(ranked[0].wallet_address,"good")
        self.assertGreater(ranked[0].score,ranked[1].score)
        self.assertIn("amostra_insuficiente",ranked[1].risk_flags)
    def test_relationship_is_flag_not_automatic_proof(self):
        relation=WalletRelationship("good","other",50,1,1,("mint",),("evidence",))
        ranked=rank_wallets([self.profile("good")],[self.perf("good")],[relation])
        self.assertIn("relacoes_heuristicas_exigem_revisao",ranked[0].risk_flags)
        self.assertEqual(ranked[0].confidence,"baixa")
    def test_missing_performance_is_not_invented(self):
        result=rank_wallets([self.profile("new")],[])[0]
        self.assertIsNone(result.realized_pnl)
        self.assertEqual(result.closed_fills,0)
        self.assertEqual(result.confidence,"baixa")
    def test_invalid_minimum(self):
        with self.assertRaises(ValueError): rank_wallets([],[],minimum_closed_fills=0)

if __name__ == "__main__": unittest.main()
