import unittest
from datetime import datetime, timezone
from decimal import Decimal

from smart_money_radar.data_sources.transaction_parser import (
    SOL_MINT,
    parse_transaction,
)


class TransactionParserTests(unittest.TestCase):
    def setUp(self) -> None:
        self.wallet = "wallet-public-address"
        self.signature = "simulated-signature"
        self.transaction = {
            "blockTime": 1_730_000_000,
            "meta": {
                "err": None,
                "preTokenBalances": [
                    {
                        "owner": self.wallet,
                        "mint": "mint-usdc",
                        "uiTokenAmount": {"amount": "1500000", "decimals": 6},
                    },
                    {
                        "owner": "another-wallet",
                        "mint": "mint-ignored",
                        "uiTokenAmount": {"amount": "900", "decimals": 2},
                    },
                ],
                "postTokenBalances": [
                    {
                        "owner": self.wallet,
                        "mint": "mint-usdc",
                        "uiTokenAmount": {"amount": "2500000", "decimals": 6},
                    }
                ],
                "innerInstructions": [],
            },
            "transaction": {
                "message": {
                    "accountKeys": [{"pubkey": self.wallet}],
                    "instructions": [
                        {
                            "program": "system",
                            "parsed": {
                                "type": "transfer",
                                "info": {
                                    "source": self.wallet,
                                    "destination": "recipient-wallet",
                                    "lamports": 2_500_000_000,
                                },
                            },
                        }
                    ],
                }
            },
        }

    def test_extracts_token_and_sol_direction_amount_signature_and_time(self) -> None:
        events = parse_transaction(self.transaction, self.wallet, self.signature)

        by_mint = {event.token_mint: event for event in events}
        self.assertEqual(set(by_mint), {"mint-usdc", SOL_MINT})
        self.assertEqual(by_mint["mint-usdc"].direction, "in")
        self.assertEqual(by_mint["mint-usdc"].amount, Decimal("1"))
        self.assertEqual(by_mint[SOL_MINT].direction, "out")
        self.assertEqual(by_mint[SOL_MINT].amount, Decimal("2.5"))
        self.assertEqual(by_mint["mint-usdc"].signature, self.signature)
        self.assertEqual(
            by_mint["mint-usdc"].occurred_at,
            datetime.fromtimestamp(1_730_000_000, tz=timezone.utc),
        )

    def test_uses_none_when_rpc_does_not_supply_block_time(self) -> None:
        transaction = dict(self.transaction)
        transaction.pop("blockTime")

        events = parse_transaction(transaction, self.wallet, self.signature)

        self.assertTrue(events)
        self.assertTrue(all(event.occurred_at is None for event in events))

    def test_ignores_failed_transaction(self) -> None:
        transaction = dict(self.transaction)
        transaction["meta"] = {**self.transaction["meta"], "err": {"InstructionError": []}}

        self.assertEqual(
            parse_transaction(transaction, self.wallet, self.signature),
            [],
        )

    def test_ignores_ambiguous_token_owner(self) -> None:
        transaction = dict(self.transaction)
        transaction["meta"] = {
            **self.transaction["meta"],
            "postTokenBalances": [
                {
                    "mint": "mint-without-owner",
                    "uiTokenAmount": {"amount": "100", "decimals": 2},
                }
            ],
            "preTokenBalances": [],
        }
        transaction["transaction"] = {"message": {"instructions": []}}

        self.assertEqual(
            parse_transaction(transaction, self.wallet, self.signature),
            [],
        )


if __name__ == "__main__":
    unittest.main()