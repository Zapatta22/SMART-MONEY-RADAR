"""Coleta controlada de transações Solana para fixtures de auditoria.

Somente leitura. Não transmite transações, não requer chave Helius e não
normaliza nem anonimiza o payload bruto.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse
from typing import Callable


@dataclass(frozen=True, slots=True)
class FixtureResult:
    signature: str
    raw_path: Path
    sha256: str
    slot: int
    version: str | int


class RpcFixtureCollector:
    def __init__(
        self,
        endpoint: str,
        output_dir: str | Path,
        *,
        timeout: float = 20.0,
        min_interval_seconds: float = 0.25,
        opener: Callable = urllib.request.urlopen,
        sleeper: Callable[[float], None] = time.sleep,
    ) -> None:
        parsed_endpoint = urlparse(endpoint)
        if parsed_endpoint.scheme != "https" or not parsed_endpoint.hostname:
            raise ValueError("O endpoint RPC deve ser uma URL HTTPS válida.")
        if timeout <= 0 or min_interval_seconds < 0:
            raise ValueError("Timeout deve ser positivo e intervalo não negativo.")
        self.endpoint = endpoint
        self.output_dir = Path(output_dir)
        self.timeout = timeout
        self.min_interval_seconds = min_interval_seconds
        self._opener = opener
        self._sleep = sleeper
        self._last_request: float | None = None

    def collect(self, signature: str) -> FixtureResult:
        if not signature or any(ch.isspace() for ch in signature):
            raise ValueError("Assinatura Solana inválida.")
        if self._last_request is not None:
            elapsed = time.monotonic() - self._last_request
            if elapsed < self.min_interval_seconds:
                self._sleep(self.min_interval_seconds - elapsed)

        body = json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "getTransaction",
            "params": [signature, {
                "commitment": "finalized",
                "encoding": "json",
                "maxSupportedTransactionVersion": 0,
            }],
        }, separators=(",", ":")).encode("utf-8")
        request = urllib.request.Request(
            self.endpoint, data=body,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            method="POST",
        )
        try:
            self._last_request = time.monotonic()
            with self._opener(request, timeout=self.timeout) as response:
                raw_bytes = response.read()
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            # Não propaga a mensagem da biblioteca: ela pode conter a URL/token.
            raise RuntimeError(
                f"Falha RPC ao coletar {signature} ({type(exc).__name__}); verifique conectividade e endpoint."
            ) from exc

        try:
            payload = json.loads(raw_bytes)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RuntimeError("RPC retornou conteúdo que não é JSON válido.") from exc
        if payload.get("error"):
            raise RuntimeError(f"Erro RPC: {payload['error']}")
        result = payload.get("result")
        if not isinstance(result, dict):
            raise RuntimeError("Transação não encontrada ou resposta RPC sem result.")
        tx = result.get("transaction")
        signatures = tx.get("signatures", []) if isinstance(tx, dict) else []
        if signature not in signatures:
            raise RuntimeError("A assinatura solicitada não confere com o payload retornado.")
        if not isinstance(result.get("slot"), int):
            raise RuntimeError("Payload sem slot válido.")

        self.output_dir.mkdir(parents=True, exist_ok=True)
        raw_path = self.output_dir / f"{signature}.raw.json"
        # Salva exatamente os bytes recebidos; nunca sobrescreve evidência existente.
        if raw_path.exists():
            raise FileExistsError(f"Fixture já existe; preservando original: {raw_path}")
        raw_path.write_bytes(raw_bytes)
        digest = hashlib.sha256(raw_bytes).hexdigest()
        version = result.get("version", "legacy")
        manifest = {
            "signature": signature,
            "slot": result["slot"],
            "version": version,
            "commitment": "finalized",
            "encoding": "json",
            "endpoint_host": urlparse(self.endpoint).hostname,
            "raw_file": raw_path.name,
            "sha256": digest,
            "anonymized": False,
            "provenance": "Solana JSON-RPC getTransaction",
        }
        manifest_path = self.output_dir / f"{signature}.manifest.json"
        if manifest_path.exists():
            raw_path.unlink(missing_ok=True)
            raise FileExistsError(f"Manifest já existe; preservando original: {manifest_path}")
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        return FixtureResult(signature, raw_path, digest, result["slot"], version)


def endpoint_from_environment() -> str:
    endpoint = os.environ.get("SMR_SOLANA_RPC_URL", "").strip()
    if not endpoint:
        raise RuntimeError("Defina SMR_SOLANA_RPC_URL com um endpoint RPC HTTPS somente leitura.")
    return endpoint
