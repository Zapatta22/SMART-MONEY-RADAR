#!/usr/bin/env python3
"""Coleta assinaturas conhecidas via RPC HTTPS; uso: python tools/collect_solana_fixtures.py SIG [SIG...]."""
from __future__ import annotations

import argparse
from smart_money_radar.data_sources.rpc_fixture_collector import (
    RpcFixtureCollector, endpoint_from_environment,
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("signatures", nargs="+", help="Assinaturas Solana confirmadas")
    parser.add_argument("--output", default="data/fixtures/raw", help="Diretório para payloads brutos")
    args = parser.parse_args()
    collector = RpcFixtureCollector(endpoint_from_environment(), args.output)
    for signature in args.signatures:
        result = collector.collect(signature)
        print(f"OK {result.signature} slot={result.slot} sha256={result.sha256}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
