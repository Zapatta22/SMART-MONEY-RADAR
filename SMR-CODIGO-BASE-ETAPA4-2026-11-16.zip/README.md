# SMART MONEY RADAR (SMR)

Infraestrutura local para observar atividade pública de carteiras na blockchain
Solana. A integração Helius usa JSON-RPC e WebSocket padrão, enriquece
notificações com detalhes de transação e grava eventos em SQLite.

## Garantias e limites

- Somente leitura: são usados `getVersion`, `getSignaturesForAddress`,
  `getTransaction` e `logsSubscribe`. Não existe envio ou assinatura de
  transações.
- O monitor acompanha somente endereços públicos passados explicitamente.
- Nenhuma chave privada ou frase-semente é aceita ou armazenada.
- Chamadas externas ficam bloqueadas por padrão. `SMR_ALLOW_NETWORK=true` é uma
  autorização explícita para o SMR fazer requisições; antes disso, verifique os
  limites e possíveis custos do seu plano Helius. Este projeto não contrata um
  plano nem faz uma conexão automaticamente.
- A API key é lida de `HELIUS_API_KEY`, nunca impressa em logs ou incluída no
  README.
- O arquivo `.env` local e o banco SQLite são ignorados pelo Git.

## Estrutura e módulos

```text
smart-money-radar/
├── .env.example
├── README.md
├── pyproject.toml
├── src/smart_money_radar/
│   ├── cli.py
│   ├── settings.py
│   ├── analysis/metrics.py
│   ├── data_sources/
│   │   ├── base.py
│   │   ├── helius.py
│   │   ├── solana.py
│   │   └── transaction_parser.py
│   ├── domain/models.py
│   ├── services/
│   │   ├── wallet_monitor.py
│   │   └── wallet_tracker.py
│   └── storage/event_store.py
└── tests/
```

- `settings.py`: carrega ambiente/`.env`, valida cluster e bloqueia acesso de
  rede sem autorização explícita.
- `data_sources/helius.py`: cliente HTTP JSON-RPC de leitura, valida respostas
  e evita expor a URL que contém a API key.
- `data_sources/transaction_parser.py`: extrai deltas por token a partir dos
  saldos pré/pós e transferências SOL identificadas em instruções decodificadas.
  O mint sentinela `SOL` representa SOL nativo, não um mint SPL.
- `data_sources/solana.py`: mantém o nome da classe inicial e encaminha para o
  adaptador Helius quando recebe configuração.
- `services/wallet_monitor.py`: abre WebSocket com `logsSubscribe` por endereço,
  consulta detalhes das assinaturas e reconecta com backoff exponencial. O
  WebSocket envia ping periódico para manter a sessão ativa.
- `storage/event_store.py`: histórico SQLite local, com deduplicação por
  carteira, assinatura, mint e direção.
- `domain/models.py`: modelos para carteiras públicas e eventos observados.
- `analysis/metrics.py`: contagens descritivas por mint; não classifica
  carteiras nem fornece recomendação financeira.
- `services/wallet_tracker.py`: serviço existente preservado para consultas
  através de uma fonte compatível.
- `tests/`: testes `unittest` com respostas HTTP/WebSocket simuladas; não
  conectam à blockchain.

## Instalação e configuração

Na pasta `smart-money-radar`:

```bash
python -m pip install -e .
cp .env.example .env
```

Preencha `HELIUS_API_KEY` somente no arquivo local `.env` ou no mecanismo de
Secrets do ambiente. Nunca envie a chave pelo chat nem a grave no código. Para
autorizar acesso externo, revise as condições da sua conta Helius e então altere
`SMR_ALLOW_NETWORK` para `true`. O valor de exemplo é `false`.

`SOLANA_CLUSTER` aceita `mainnet` ou `devnet`. O histórico fica em
`data/smr_history.sqlite3`, salvo se `SMR_DB_PATH` apontar para outro local.

## Comandos

Sem argumentos, o SMR mostra ajuda de estado e não faz chamadas de rede:

```bash
smr
```

`check` faz uma consulta RPC `getVersion` e só informa sucesso após receber uma
resposta válida:

```bash
smr check
```

`watch` abre um monitor WebSocket para endereços públicos e grava novos eventos
no banco local. Encerre com `Ctrl+C`:

```bash
smr watch <ENDERECO_PUBLICO> [OUTRO_ENDERECO_PUBLICO ...]
```

O método padrão `logsSubscribe` aceita um endereço por assinatura; o SMR cria
uma assinatura para cada endereço informado na mesma conexão. Para eventos
confirmados, consulta `getTransaction` e extrai o mint, assinatura, horário
quando fornecido pelo RPC, direção e quantidade quando os dados permitem. SOL é
extraído apenas de instruções `system` decodificadas; taxas não são tratadas como
transferências.

Referências do protocolo:

- [Helius `logsSubscribe`](https://www.helius.dev/docs/api-reference/rpc/websocket/logssubscribe)
- [Helius endpoints RPC e WebSocket](https://www.helius.dev/docs/api-reference/endpoints)
- [Solana `getTransaction`](https://solana.com/docs/rpc/http/gettransaction)

## Testes

```bash
python -m unittest discover -s tests -v
```

Os testes simulam RPC, notificações WebSocket, reconexão, parser e SQLite. Não
fazem requisições reais e, portanto, não verificam credenciais, disponibilidade
do Helius ou conexão com a blockchain. A conexão real só deve ser verificada
executando `smr check` ou `smr watch` após habilitar a rede e configurar uma API
key válida.
## Recuperação incremental de monitoramento

O monitor mantém um checkpoint por carteira em `wallet_checkpoints`. Após uma
reconexão, consulta `getSignaturesForAddress` e recupera assinaturas posteriores
ao último checkpoint, processando-as da mais antiga para a mais recente. O
checkpoint só avança depois de a transação estar disponível e ser persistida; uma
transação temporariamente indisponível recebe até três tentativas com espera
exponencial. A recuperação é limitada a 10 páginas de até 100 assinaturas por
carteira por conexão. Se o checkpoint não for encontrado nesse limite, o
monitor interrompe a recuperação com erro explícito em vez de avançar e ocultar
uma possível lacuna. Na primeira execução, não faz varredura histórica: começa
a acompanhar notificações novas.


## Robustez do monitor — Etapa 2 (16/11/2026)

- Assinaturas que já constam como processadas para a carteira são ignoradas
  antes de consultar novamente `getTransaction`. Isso elimina a duplicação entre
  notificações WebSocket recebidas durante o backfill e o próprio backfill.
- `save_checkpoint` grava a assinatura processada e atualiza o checkpoint na
  mesma transação SQLite.
- O encerramento da CLI aguarda tarefas assíncronas e o executor padrão
  (`asyncio.to_thread`) antes de fechar o Event Store e o event loop.
- O fechamento do Event Store é idempotente para o banco em memória.
- Testes adicionais cobrem limite de páginas, esgotamento de retries, erro RPC,
  sobreposição WebSocket/backfill, encerramento normal e encerramento após erro.

Validação local da Etapa 2: 26 testes `unittest` aprovados e `compileall`
aprovado. Os testes usam doubles/mocks; não houve conexão real com Helius ou
Solana, benchmark de latência, nem implantação em Replit/VPS.


### Limites atuais do parser Solana

O parser atual é conservador e trabalha com respostas `getTransaction` em `jsonParsed`:

- calcula deltas agregados por mint usando `preTokenBalances` e `postTokenBalances` cujo `owner` corresponde à carteira monitorada;
- identifica instruções System Program `transfer` e `transferWithSeed` explicitamente decodificadas, inclusive em `innerInstructions`;
- não reconstrói a semântica completa de swaps, rotas de agregadores, pools, LP, staking, lending, criação/fechamento de contas, rent, taxas ou recompensas;
- não calcula preço, valor em USD, slippage, PnL nem atribui intenção à movimentação;
- não deve ser usado ainda como fonte única para decisão de compra/venda.

Respostas sem os dois arrays de saldos de tokens não geram deltas de token. O campo `decimals` é limitado ao intervalo u8 do SPL Token (0–255). A cobertura de programas e instruções precisa ser ampliada com fixtures reais anonimizadas e testes específicos antes de qualquer decisão automatizada.


### Arquivamento bruto e replay de parsing

Cada transação obtida com sucesso é agora registrada em `observed_transactions` junto com o payload JSON bruto, estado de parsing, versão do parser e eventual classe de erro. A gravação do payload, dos eventos derivados, da assinatura processada e do checkpoint ocorre na mesma transação SQLite. Transações sem eventos reconhecidos ficam marcadas como `no_events`; exceções do parser ficam como `parse_error`; falhas on-chain conhecidas ficam como `failed_on_chain`.

`get_raw_transaction` permite recuperar o payload para auditoria e `reprocess_observation` substitui os eventos derivados de uma observação sem mover o checkpoint. A retenção dos payloads ainda não tem política automática: o crescimento do banco deve ser medido e uma política de retenção/compactação precisa ser definida antes de operação contínua em volume.

### Estados de observação

Os estados de parsing registrados são `parsed`, `no_events`, `parse_error` e `failed_on_chain`. `no_events` não significa que a transação foi irrelevante: significa apenas que o parser atual não produziu eventos. O payload bruto é preservado para replay. `reprocess_observation` substitui os eventos derivados e atualiza a versão/estado sem alterar o checkpoint. A versão atual do parser é `PARSER_VERSION = "1"`.
