"""Adaptadores de normalização entre o parser atual e os contratos de domínio."""

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from smart_money_radar.data_sources.transaction_parser import PARSER_VERSION, SOL_MINT, parse_transaction
from smart_money_radar.domain.models import (
    ActivityEvent,
    ObservedTransaction,
    TokenBalanceDelta,
)


@dataclass(frozen=True)
class NormalizedObservation:
    """Resultado normalizado sem remover compatibilidade com ActivityEvent."""

    transaction: ObservedTransaction
    token_deltas: tuple[TokenBalanceDelta, ...]
    activity_events: tuple[ActivityEvent, ...]


def normalize_transaction(
    raw_transaction: dict[str, Any],
    wallet_address: str,
    signature: str,
    *,
    chain: str = "solana",
    observed_at: datetime | None = None,
) -> NormalizedObservation:
    """Converte uma resposta RPC em envelope e deltas tipados.

    A normalização usa o parser conservador existente. `ActivityEvent` permanece
    disponível para o pipeline legado; `TokenBalanceDelta` contém apenas mints
    SPL, pois SOL nativo é uma transferência de lamports e não um mint SPL.
    """
    if not isinstance(raw_transaction, dict):
        raise TypeError("A transação RPC deve ser um objeto JSON.")
    if not wallet_address.strip() or not signature.strip() or not chain.strip():
        raise ValueError("Chain, carteira e assinatura são obrigatórias.")

    events = tuple(parse_transaction(raw_transaction, wallet_address, signature))
    meta = raw_transaction.get("meta")
    failed = isinstance(meta, dict) and meta.get("err") is not None
    status = "failed_on_chain" if failed else ("parsed" if events else "no_events")
    block_time = raw_transaction.get("blockTime")
    occurred_at = None
    if isinstance(block_time, int) and not isinstance(block_time, bool):
        try:
            occurred_at = datetime.fromtimestamp(block_time, tz=timezone.utc)
        except (OverflowError, OSError, ValueError):
            occurred_at = None

    envelope = ObservedTransaction(
        chain=chain,
        wallet_address=wallet_address,
        signature=signature,
        observed_at=observed_at or datetime.now(timezone.utc),
        raw_transaction=raw_transaction,
        parser_version=PARSER_VERSION,
        parse_status=status,
        slot=(raw_transaction.get("slot") if isinstance(raw_transaction.get("slot"), int)
              and not isinstance(raw_transaction.get("slot"), bool)
              and raw_transaction.get("slot") >= 0 else None),
        occurred_at=occurred_at,
    )
    deltas = tuple(
        TokenBalanceDelta(
            chain=chain,
            wallet_address=event.wallet_address,
            signature=event.signature,
            token_mint=event.token_mint,
            direction=event.direction,
            amount=event.amount,
        )
        for event in events
        if event.token_mint != SOL_MINT
    )
    return NormalizedObservation(envelope, deltas, events)
