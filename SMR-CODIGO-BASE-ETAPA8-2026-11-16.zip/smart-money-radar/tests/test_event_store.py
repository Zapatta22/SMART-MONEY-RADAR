import tempfile
import unittest
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

from smart_money_radar.domain.models import ActivityEvent
from smart_money_radar.storage.event_store import SQLiteEventStore


class SQLiteEventStoreTests(unittest.TestCase):
    def test_persists_events_and_ignores_duplicates(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = SQLiteEventStore(Path(directory) / "history.sqlite3")
            event = ActivityEvent(
                wallet_address="public-wallet",
                signature="simulated-signature",
                occurred_at=datetime(2026, 11, 7, tzinfo=timezone.utc),
                token_mint="mint-a",
                direction="in",
                amount=Decimal("1.25"),
            )

            self.assertEqual(store.save_events([event]), 1)
            self.assertEqual(store.save_events([event]), 0)
            self.assertEqual(store.get_events(wallet_address="public-wallet"), [event])

    def test_memory_database_persists_across_store_operations(self) -> None:
        store = SQLiteEventStore(":memory:")
        event = ActivityEvent(
            wallet_address="public-wallet",
            signature="memory-signature",
            occurred_at=datetime(2026, 11, 7, tzinfo=timezone.utc),
            token_mint="mint-memory",
            direction="in",
            amount=Decimal("2.5"),
        )

        self.assertEqual(store.save_events([event]), 1)
        self.assertEqual(store.get_events(), [event])
        store.close()


    def test_checkpoint_also_records_processed_signature(self) -> None:
        store = SQLiteEventStore(":memory:")
        self.assertFalse(store.has_processed_signature("wallet-a", "signature-a"))
        store.save_checkpoint("wallet-a", "signature-a")
        self.assertTrue(store.has_processed_signature("wallet-a", "signature-a"))
        self.assertEqual(store.get_checkpoint("wallet-a"), "signature-a")
        store.close()

    def test_allows_unknown_time_from_rpc(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store = SQLiteEventStore(Path(directory) / "history.sqlite3")
            event = ActivityEvent(
                wallet_address="public-wallet",
                signature="simulated-signature",
                occurred_at=None,
                token_mint="mint-a",
                direction="out",
                amount=Decimal("0.5"),
            )

            store.save_events([event])

            self.assertEqual(store.get_events()[0], event)

    def test_close_is_idempotent_for_in_memory_store(self) -> None:
        store = SQLiteEventStore(":memory:")
        store.close()
        store.close()
        self.assertIsNone(store._memory_connection)

    def test_save_observation_atomically_archives_raw_payload_and_checkpoint(self) -> None:
        store = SQLiteEventStore(":memory:")
        payload = {"meta": {"err": None}, "transaction": {"message": {}}}

        store.save_observation(
            "wallet-a", "signature-a", payload, [], parse_status="no_events", parser_version="1"
        )

        self.assertEqual(store.get_raw_transaction("wallet-a", "signature-a"), payload)
        self.assertTrue(store.has_processed_signature("wallet-a", "signature-a"))
        self.assertEqual(store.get_checkpoint("wallet-a"), "signature-a")
        self.assertEqual(
            store.get_observation_metadata("wallet-a", "signature-a")["parse_status"],
            "no_events",
        )
        store.close()

    def test_save_observation_rejects_events_from_another_signature(self) -> None:
        store = SQLiteEventStore(":memory:")
        event = ActivityEvent(
            wallet_address="wallet-a", signature="other-signature", occurred_at=None,
            token_mint="mint-a", direction="in", amount=Decimal("1"),
        )
        with self.assertRaises(ValueError):
            store.save_observation(
                "wallet-a", "signature-a", {"meta": {}}, [event],
                parse_status="parsed", parser_version="1",
            )
        self.assertIsNone(store.get_checkpoint("wallet-a"))
        store.close()

    def test_reprocess_observation_replaces_derived_events_without_moving_checkpoint(self) -> None:
        store = SQLiteEventStore(":memory:")
        payload = {"meta": {"err": None}}
        store.save_observation(
            "wallet-a", "signature-a", payload, [], parse_status="no_events", parser_version="1"
        )
        event = ActivityEvent(
            wallet_address="wallet-a",
            signature="signature-a",
            occurred_at=None,
            token_mint="mint-a",
            direction="in",
            amount=Decimal("3"),
        )

        self.assertEqual(
            store.reprocess_observation(
                "wallet-a", "signature-a", [event], parse_status="parsed", parser_version="2"
            ),
            1,
        )
        self.assertEqual(store.get_events(wallet_address="wallet-a"), [event])
        self.assertEqual(store.get_checkpoint("wallet-a"), "signature-a")
        self.assertEqual(store.get_raw_transaction("wallet-a", "signature-a"), payload)
        store.close()

    def test_reprocess_requires_existing_observation(self) -> None:
        store = SQLiteEventStore(":memory:")
        with self.assertRaises(KeyError):
            store.reprocess_observation(
                "wallet-a", "missing", [], parse_status="no_events", parser_version="2"
            )
        store.close()

    def test_integrity_check_and_storage_stats(self) -> None:
        store = SQLiteEventStore(":memory:")
        store.save_checkpoint("wallet-a", "signature-a")
        self.assertEqual(store.integrity_check(), ["ok"])
        stats = store.storage_stats()
        self.assertEqual(stats["wallet_checkpoints"], 1)
        self.assertGreater(stats["database_bytes"], 0)
        store.close()

    def test_backup_restores_observations_and_checkpoints(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            source_path = Path(directory) / "source.sqlite3"
            backup_path = Path(directory) / "backups" / "smr-backup.sqlite3"
            source = SQLiteEventStore(source_path)
            payload = {"meta": {"err": None}, "transaction": {"signatures": ["sig-a"]}}
            source.save_observation(
                "wallet-a", "sig-a", payload, [], parse_status="no_events", parser_version="1"
            )

            self.assertEqual(source.backup_to(backup_path), backup_path)
            source.close()

            restored = SQLiteEventStore(backup_path)
            self.assertEqual(restored.integrity_check(), ["ok"])
            self.assertEqual(restored.get_checkpoint("wallet-a"), "sig-a")
            self.assertEqual(restored.get_raw_transaction("wallet-a", "sig-a"), payload)
            restored.close()

    def test_backup_rejects_source_database_as_destination(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "history.sqlite3"
            store = SQLiteEventStore(path)
            with self.assertRaises(ValueError):
                store.backup_to(path)
            store.close()

    def test_existing_database_reopens_with_observation_schema(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "history.sqlite3"
            first = SQLiteEventStore(path)
            first.save_checkpoint("wallet-a", "old-signature")
            first.close()

            reopened = SQLiteEventStore(path)
            self.assertEqual(reopened.get_checkpoint("wallet-a"), "old-signature")
            self.assertIsNone(reopened.get_observation_metadata("wallet-a", "old-signature"))
            reopened.close()


if __name__ == "__main__":
    unittest.main()