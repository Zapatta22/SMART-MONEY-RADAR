# Etapa 16 — pacote de recuperação Android/Termux

Data: 2026-11-16

## Proveniência

Este pacote é uma reconstrução identificada a partir do ZIP íntegro da Etapa 15 recuperado da Biblioteca. O ZIP original `SMR-CODIGO-BASE-ETAPA16-2026-11-16.zip` foi localizado, mas a exportação de seus bytes não foi autorizada pelo armazenamento nesta sessão. Portanto, este artefato NÃO é declarado como cópia idêntica do original de 97 arquivos.

## Acréscimos desta recuperação

- `tools/run_smr_android.py`: preflight `getHealth`, leitura do catálogo, coleta sequencial e retomada que valida SHA-256/assinatura sem sobrescrever evidências.
- `tools/run_smr_android.sh`: inicializador Termux, endpoint RPC público padrão e execução com `PYTHONPATH`.
- `tools/termux_setup.sh`: instalação de Python/unzip e permissão de armazenamento.
- `docs/ANDROID_TERMUX.md`: instruções e limites operacionais.
- `tests/test_android_runner_contract.py`: testes de retomada e preservação.

## Segurança

Somente leitura. Sem Helius, chaves privadas, carteiras, assinatura de transações ou envio on-chain. Nenhuma fixture real é aprovada automaticamente. A coleta depende de DNS e disponibilidade do RPC no aparelho.

## Validação deste pacote

A integridade do ZIP de origem Etapa 15 foi verificada antes da reconstrução. A suíte de testes e compilação do pacote reconstruído precisam ser executadas no ambiente de validação; a execução no Android/Termux continua pendente até o usuário rodar o script no aparelho.
