# Execução Android / Termux — pacote de recuperação da Etapa 16

## Segurança e escopo

- Coleta pública Solana por HTTPS JSON-RPC, somente leitura (`getHealth` e `getTransaction`).
- Endpoint padrão: `https://api.mainnet-beta.solana.com`; pode ser substituído por `SMR_SOLANA_RPC_URL`.
- Não usa Helius, API key, carteira, chave privada, frase-semente, assinatura ou envio de transação.
- A coleta não compra/vende tokens e não inicia operação financeira.
- O runner valida os arquivos já existentes e os preserva; pares completos com hash correto são ignorados na retomada. Arquivos parciais ou divergentes interrompem o processo sem sobrescrita.

## Preparar o Termux

```bash
bash tools/termux_setup.sh
```

Se preferir executar manualmente: `pkg update -y` e `pkg install -y python unzip`, depois `termux-setup-storage`.

## Executar

Entre na pasta do projeto extraído e rode:

```bash
bash tools/run_smr_android.sh
```

O runner verifica Python 3.11+, valida o catálogo JSON, confirma `getHealth` e só então coleta as cinco assinaturas sequencialmente. Os payloads e manifestos ficam em `data/fixtures/raw/`.

## Retomar com segurança

Execute o mesmo comando novamente. Pares bruto+manifesto existentes são validados por assinatura e SHA-256 e não são baixados de novo. Se existir apenas metade do par, ou hash divergente, o processo para e preserva os arquivos para auditoria.

## Limites

Uma resposta RPC válida não prova que a interpretação da transação está correta. Após a coleta, os JSONs precisam passar pelo auditor de fixtures e por revisão semântica antes de serem considerados fixtures aprovadas. Se o RPC público estiver indisponível, aguarde ou configure outro endpoint HTTPS público/autorizado; não coloque segredos no chat.
