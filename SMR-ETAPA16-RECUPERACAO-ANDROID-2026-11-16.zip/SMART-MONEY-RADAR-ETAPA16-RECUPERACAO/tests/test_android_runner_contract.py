import hashlib, json, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
from tools import run_smr_android

class AndroidResumeTests(unittest.TestCase):
    def test_complete_pair_with_matching_hash_is_skipped(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); sig='sig'; raw=root/f'{sig}.raw.json'; manifest=root/f'{sig}.manifest.json'
            raw.write_bytes(b'{"fixture":true}')
            manifest.write_text(json.dumps({'signature':sig,'sha256':hashlib.sha256(raw.read_bytes()).hexdigest()}))
            with patch.object(run_smr_android, 'OUTPUT', root):
                self.assertTrue(run_smr_android.already_complete(sig))
    def test_partial_pair_is_preserved_and_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); sig='sig'; raw=root/f'{sig}.raw.json'; raw.write_text('keep')
            with patch.object(run_smr_android, 'OUTPUT', root):
                with self.assertRaises(RuntimeError): run_smr_android.already_complete(sig)
            self.assertEqual(raw.read_text(), 'keep')
    def test_hash_mismatch_is_rejected_without_modification(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); sig='sig'; raw=root/f'{sig}.raw.json'; manifest=root/f'{sig}.manifest.json'
            raw.write_text('keep'); manifest.write_text(json.dumps({'signature':sig,'sha256':'wrong'}))
            with patch.object(run_smr_android, 'OUTPUT', root):
                with self.assertRaises(RuntimeError): run_smr_android.already_complete(sig)
            self.assertEqual(raw.read_text(), 'keep')

if __name__ == '__main__': unittest.main()
