#!/usr/bin/env python3
"""Etapa 16: preflight e coleta sequencial, retomável e somente leitura no Termux."""
from __future__ import annotations
import hashlib, json, os, sys, urllib.request, urllib.error
from pathlib import Path
from urllib.parse import urlparse
from smart_money_radar.data_sources.rpc_fixture_collector import RpcFixtureCollector, endpoint_from_environment

ROOT = Path(__file__).resolve().parents[1]
CANDIDATES = ROOT / "data/fixtures/candidates/solana_mainnet_candidates.json"
OUTPUT = ROOT / "data/fixtures/raw"

def rpc_health(endpoint: str) -> None:
    parsed = urlparse(endpoint)
    if parsed.scheme != "https" or not parsed.hostname:
        raise RuntimeError("Endpoint precisa ser HTTPS válido.")
    body = json.dumps({"jsonrpc":"2.0","id":1,"method":"getHealth"}).encode()
    req = urllib.request.Request(endpoint, data=body, headers={"Content-Type":"application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            payload = json.loads(response.read())
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Preflight RPC falhou ({type(exc).__name__}); nenhum dado foi coletado.") from exc
    if not isinstance(payload, dict) or payload.get("result") != "ok":
        raise RuntimeError("RPC não confirmou getHealth=ok; coleta interrompida.")

def already_complete(signature: str) -> bool:
    raw = OUTPUT / f"{signature}.raw.json"
    manifest = OUTPUT / f"{signature}.manifest.json"
    if not raw.exists() and not manifest.exists():
        return False
    if not raw.is_file() or not manifest.is_file():
        raise RuntimeError(f"Evidência parcial encontrada para {signature}; preservada, requer auditoria manual.")
    try:
        data = json.loads(manifest.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Manifesto inválido para {signature}; arquivo preservado.") from exc
    digest = hashlib.sha256(raw.read_bytes()).hexdigest()
    if data.get("signature") != signature or data.get("sha256") != digest:
        raise RuntimeError(f"Hash/assinatura divergente para {signature}; arquivo preservado.")
    return True

def main() -> int:
    if sys.version_info < (3, 11):
        print("BLOQUEADO: SMR requer Python 3.11 ou superior."); return 2
    if not CANDIDATES.is_file():
        print(f"BLOQUEADO: catálogo não encontrado: {CANDIDATES}"); return 2
    try:
        candidates = json.loads(CANDIDATES.read_text(encoding="utf-8"))
        if not isinstance(candidates, list) or not candidates:
            raise ValueError("catálogo precisa ser uma lista JSON não vazia")
        signatures=[]
        for item in candidates:
            if not isinstance(item, dict) or not isinstance(item.get("signature"), str):
                raise ValueError("cada candidato precisa ter campo signature textual")
            signatures.append(item["signature"])
        signatures=list(dict.fromkeys(signatures))
        endpoint=endpoint_from_environment()
        print("Preflight: verificando RPC público/definido (getHealth)...")
        rpc_health(endpoint)
        print("RPC OK. Iniciando coleta sequencial; arquivos existentes serão preservados.")
        collector=RpcFixtureCollector(endpoint, OUTPUT)
        OUTPUT.mkdir(parents=True, exist_ok=True)
        done=0
        for signature in signatures:
            if already_complete(signature):
                print(f"PRESERVADO/VALIDADO {signature}"); done+=1; continue
            result=collector.collect(signature)
            print(f"COLETADO {result.signature} slot={result.slot} sha256={result.sha256}")
            done+=1
        print(f"CONCLUÍDO: {done}/{len(signatures)} candidatos presentes e íntegros.")
        print("Atenção: payloads coletados ainda precisam de auditoria semântica; não são fixtures aprovadas automaticamente.")
        return 0
    except (OSError, ValueError, RuntimeError, FileExistsError) as exc:
        print(f"PARADO COM SEGURANÇA: {exc}"); return 1

if __name__ == "__main__":
    raise SystemExit(main())
