#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v python >/dev/null 2>&1; then
  echo "Python não encontrado. Execute primeiro: bash tools/termux_setup.sh"
  exit 2
fi
export PYTHONPATH="$PWD/src:$PWD${PYTHONPATH:+:$PYTHONPATH}"
if [ -z "${SMR_SOLANA_RPC_URL:-}" ]; then
  export SMR_SOLANA_RPC_URL="https://api.mainnet-beta.solana.com"
  echo "Usando RPC público padrão da Solana. Nenhuma chave Helius será usada."
fi
python tools/run_smr_android.py
