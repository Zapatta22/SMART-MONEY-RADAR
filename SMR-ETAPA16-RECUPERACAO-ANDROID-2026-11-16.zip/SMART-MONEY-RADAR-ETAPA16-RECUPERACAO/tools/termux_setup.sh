#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
pkg update -y
pkg install -y python unzip
termux-setup-storage
cat <<'EOF'
Preparação concluída. Se o Android pedir permissão de arquivos, permita.
Não apague nem mova pastas existentes. Extraia o ZIP de recuperação em uma
pasta nova e entre nela antes de executar:
  bash tools/run_smr_android.sh
EOF
