#!/usr/bin/env python3
"""Validação consolidada offline do SMR; não coleta nem altera fixtures existentes."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
TESTS = ROOT / "tests"
RAW_DIR = ROOT / "data/fixtures/raw"
CANDIDATES_FILE = ROOT / "data/fixtures/candidates/solana_mainnet_candidates.json"
REPORT_DIR = ROOT / "reports/validation"


def run_check(name: str, command: list[str], env: dict[str, str]) -> dict[str, Any]:
    try:
        proc = subprocess.run(command, cwd=ROOT, env=env, text=True,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              check=False)
        return {"name": name, "passed": proc.returncode == 0,
                "returncode": proc.returncode, "output": proc.stdout[-16000:]}
    except Exception as exc:  # report the failure and continue with independent checks
        return {"name": name, "passed": False, "returncode": -1,
                "output": f"{type(exc).__name__}: {exc}"}


def _load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _key_text(value: Any) -> str | None:
    if isinstance(value, str):
        return value
    if isinstance(value, dict) and isinstance(value.get("pubkey"), str):
        return value["pubkey"]
    return None


def _instruction_inventory(instructions: Any, keys: list[str], registry: dict[str, str], kind: str) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    if not isinstance(instructions, list):
        return found
    for position, ix in enumerate(instructions):
        if not isinstance(ix, dict):
            found.append({"position": position, "kind": kind, "error": "instruction_not_object"})
            continue
        program_id = ix.get("programId") if isinstance(ix.get("programId"), str) else None
        program = ix.get("program") if isinstance(ix.get("program"), str) else None
        index = ix.get("programIdIndex")
        if program_id is None and isinstance(index, int) and not isinstance(index, bool) and 0 <= index < len(keys):
            program_id = keys[index]
        parsed = ix.get("parsed") if isinstance(ix.get("parsed"), dict) else {}
        info = parsed.get("info") if isinstance(parsed.get("info"), dict) else {}
        raw_accounts = ix.get("accounts")
        accounts: list[str] = []
        if isinstance(raw_accounts, list):
            for item in raw_accounts:
                if isinstance(item, int) and not isinstance(item, bool) and 0 <= item < len(keys):
                    accounts.append(keys[item])
                elif isinstance(item, str):
                    accounts.append(item)
        found.append({
            "position": position, "kind": kind, "program": program,
            "program_id": program_id, "known_program": registry.get(program_id or ""),
            "program_id_index": index, "parsed_type": parsed.get("type"),
            "parsed_info": info, "accounts": accounts,
            "data_present": isinstance(ix.get("data"), str),
        })
    return found


def semantic_inventory(raw_path: Path, manifest: dict[str, Any], candidates: dict[str, dict[str, Any]], registry: dict[str, str]) -> dict[str, Any]:
    payload = _load_json(raw_path)
    if not isinstance(payload, dict):
        raise ValueError("RPC root is not an object")
    result = payload.get("result")
    if not isinstance(result, dict):
        raise ValueError("RPC result is not an object")
    tx = result.get("transaction")
    message = tx.get("message") if isinstance(tx, dict) else None
    if not isinstance(message, dict):
        raise ValueError("transaction.message is missing or invalid")
    meta = result.get("meta") if isinstance(result.get("meta"), dict) else {}
    raw_keys = message.get("accountKeys")
    keys = [_key_text(x) for x in raw_keys] if isinstance(raw_keys, list) else []
    keys = [x for x in keys if x]
    loaded = meta.get("loadedAddresses") if isinstance(meta.get("loadedAddresses"), dict) else {}
    for group in (loaded.get("writable"), loaded.get("readonly")):
        if isinstance(group, list):
            keys.extend(x for x in group if isinstance(x, str))
    header = message.get("header") if isinstance(message.get("header"), dict) else {}
    required = header.get("numRequiredSignatures", 0)
    signers = keys[:required] if isinstance(required, int) and not isinstance(required, bool) and required >= 0 else []
    top = _instruction_inventory(message.get("instructions"), keys, registry, "top_level")
    inner: list[dict[str, Any]] = []
    groups = meta.get("innerInstructions")
    if isinstance(groups, list):
        for group_index, group in enumerate(groups):
            if isinstance(group, dict):
                items = _instruction_inventory(group.get("instructions"), keys, registry, f"cpi_group_{group_index}_outer_{group.get('index')}")
                inner.extend(items)
    all_ix = top + inner
    program_ids = sorted({x["program_id"] for x in all_ix if x.get("program_id")})
    known = sorted({registry[x] for x in program_ids if x in registry})
    token_summary = {}
    for side in ("preTokenBalances", "postTokenBalances"):
        balances = meta.get(side)
        token_summary[side] = [
            {k: b.get(k) for k in ("accountIndex", "mint", "owner", "programId", "uiTokenAmount") if k in b}
            for b in balances if isinstance(b, dict)
        ] if isinstance(balances, list) else []
    sigs = tx.get("signatures") if isinstance(tx, dict) else None
    signature = manifest.get("signature")
    candidate = candidates.get(signature, {})
    candidate_protocol = candidate.get("protocol")
    envelope_errors = []
    if payload.get("jsonrpc") != "2.0":
        envelope_errors.append("jsonrpc não é 2.0")
    if "id" not in payload:
        envelope_errors.append("campo id ausente")
    if not isinstance(payload.get("result"), dict):
        envelope_errors.append("result não é objeto")
    if not isinstance(result.get("slot"), int) or isinstance(result.get("slot"), bool):
        envelope_errors.append("slot inválido")
    if not isinstance(meta, dict):
        envelope_errors.append("meta ausente/inválido")
    elif meta.get("err") is not None:
        envelope_errors.append("meta.err não é null (transação falhou on-chain)")
    candidate_slot = candidate.get("slot_reported")
    slot_matches_candidate = candidate_slot == result.get("slot") if candidate_slot is not None else None
    return {
        "signature": signature, "slot": result.get("slot"),
        "envelope_valid": not envelope_errors, "envelope_errors": envelope_errors,
        "candidate_slot_reported": candidate_slot,
        "candidate_slot_matches_reported": slot_matches_candidate,
        "manifest_sha256": manifest.get("sha256"),
        "rpc_jsonrpc": payload.get("jsonrpc"), "rpc_id": payload.get("id"),
        "meta_err": meta.get("err"), "fee_lamports": meta.get("fee"),
        "block_time": result.get("blockTime"), "transaction_version": result.get("version"),
        "signature_in_payload": isinstance(sigs, list) and signature in sigs,
        "candidate_protocol_label": candidate_protocol,
        "candidate_reported_instruction": candidate.get("instruction_reported"),
        "candidate_source": candidate.get("source"),
        "signers": signers, "account_keys_resolved_count": len(keys),
        "program_ids": program_ids, "known_programs": known,
        "top_level_instructions": top, "cpi_instructions": inner,
        "pre_balances_lamports": meta.get("preBalances"),
        "post_balances_lamports": meta.get("postBalances"),
        "token_balances": token_summary,
        "manual_review_required": True,
        "manual_review_items": [
            "confirmar protocolo/venue pelo Program ID e documentação oficial",
            "decodificar data binária de instruções não parsed quando aplicável",
            "classificar pools, vaults, mints e contas de protocolo antes de anonimizar",
            "identificar endereços pessoais adicionais e definir --anonymize/--protect",
            "não aprovar Jupiter como venue final sem examinar as CPI",
        ],
    }


def main() -> int:
    if sys.version_info < (3, 11):
        print("BLOQUEADO: Python 3.11+ é obrigatório.")
        return 2
    env = os.environ.copy()
    env["PYTHONPATH"] = f"{SRC}{os.pathsep}{ROOT}" + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    checks = [
        run_check("suite_completa", [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"], env),
        run_check("compilacao", [sys.executable, "-m", "compileall", "-q", "src", "tests", "tools"], env),
        run_check("import_parser_registry", [sys.executable, "-c", "from smart_money_radar.data_sources.transaction_parser import parse_transaction; from smart_money_radar.domain.program_registry import PROGRAMS; assert callable(parse_transaction) and PROGRAMS"], env),
    ]

    audit_results: list[dict[str, Any]] = []
    semantic_results: list[dict[str, Any]] = []
    candidates: dict[str, dict[str, Any]] = {}
    if CANDIDATES_FILE.is_file():
        try:
            candidate_data = _load_json(CANDIDATES_FILE)
            if isinstance(candidate_data, list):
                candidates = {x["signature"]: x for x in candidate_data if isinstance(x, dict) and isinstance(x.get("signature"), str)}
        except Exception as exc:
            audit_results.append({"valid": False, "error": f"catalog: {type(exc).__name__}: {exc}"})
    try:
        from smart_money_radar.data_sources.fixture_audit import audit_fixture
        from smart_money_radar.domain.program_registry import PROGRAMS
        registry = {p.program_id: p.name for p in PROGRAMS}
        manifests = sorted(RAW_DIR.glob("*.manifest.json")) if RAW_DIR.is_dir() else []
        for manifest_path in manifests:
            try:
                result = audit_fixture(manifest_path)
                row = {"manifest": str(manifest_path.relative_to(ROOT)), "signature": result.signature,
                       "slot": result.slot, "sha256": result.sha256, "valid": result.valid,
                       "errors": list(result.errors)}
                audit_results.append(row)
                if result.valid:
                    try:
                        manifest = _load_json(manifest_path)
                        semantic_results.append(semantic_inventory(result.raw_path, manifest, candidates, registry))
                    except Exception as exc:
                        semantic_results.append({"signature": result.signature, "inventory_error": f"{type(exc).__name__}: {exc}", "manual_review_required": True})
            except Exception as exc:
                audit_results.append({"manifest": str(manifest_path), "valid": False, "error": f"{type(exc).__name__}: {exc}"})
        if not manifests:
            audit_results.append({"valid": False, "error": "nenhum manifesto *.manifest.json encontrado em data/fixtures/raw"})
    except Exception as exc:
        audit_results.append({"valid": False, "error": f"auditor_import_or_run: {type(exc).__name__}: {exc}"})

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    report = {
        "project": "SMART MONEY RADAR", "stage": "Etapa 16",
        "generated_at_utc": timestamp, "mode": "offline_read_only_no_network_no_fixture_mutation",
        "checks": checks, "fixture_audits": audit_results,
        "semantic_inventory": semantic_results,
        "semantic_approval": "PENDING_MANUAL_REVIEW",
        "safety": {"network_calls": False, "collection": False, "raw_fixtures_modified": False,
                   "private_keys_used": False, "transactions_signed_or_sent": False},
    }
    json_path = REPORT_DIR / f"SMR-VALIDACAO-{timestamp}.json"
    md_path = REPORT_DIR / f"SMR-VALIDACAO-{timestamp}.md"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = ["# Relatório consolidado de validação SMR", "", f"UTC: {timestamp}", "",
             "## Testes e verificações", ""]
    for check in checks:
        lines.append(f"- {'APROVADO' if check['passed'] else 'FALHOU'} — {check['name']} (código {check['returncode']})")
    lines += ["", "## Fixtures", ""]
    for item in audit_results:
        lines.append(f"- {'ÍNTEGRA' if item.get('valid') else 'PENDENTE/FALHA'} — {item.get('signature', item.get('manifest', item.get('error', 'sem detalhe')))}")
        for error in item.get("errors", []):
            lines.append(f"  - {error}")
    for item in semantic_results:
        if item.get("envelope_errors"):
            lines.append(f"  - Envelope RPC inválido ({item.get('signature')}): {'; '.join(item['envelope_errors'])}")
    lines += ["", "## Revisão semântica", "",
              f"Transações com inventário gerado: {len(semantic_results)}",
              "**Aprovação semântica: PENDENTE DE REVISÃO HUMANA.** O relatório organiza Program IDs, instruções top-level/CPI, signers, contas e saldos; não decodifica automaticamente toda instrução binária nem decide quais contas devem ser protegidas/anônimas.",
              "", "## Segurança", "",
              "Execução offline e somente leitura. Não fez chamadas RPC, não coletou, não alterou fixtures brutas, não usou chaves privadas e não assinou/enviou transações.", ""]
    md_path.write_text("\n".join(lines), encoding="utf-8")

    print("=== SMR — VALIDAÇÃO CONSOLIDADA ===")
    for check in checks:
        print(f"{'OK' if check['passed'] else 'FALHA'}: {check['name']} (código {check['returncode']})")
    valid_count = sum(1 for x in audit_results if x.get("valid"))
    print(f"Fixtures estruturalmente íntegras: {valid_count}/{len(audit_results)}")
    print(f"Inventários semânticos gerados: {len(semantic_results)} (aprovação humana ainda necessária)")
    print(f"Relatório: {md_path.relative_to(ROOT)}")
    print(f"Dados completos: {json_path.relative_to(ROOT)}")
    failures = (any(not x["passed"] for x in checks)
                or any(not x.get("valid", False) for x in audit_results)
                or any(not x.get("envelope_valid", False) for x in semantic_results))
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
