#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v python >/dev/null 2>&1; then
  echo "Python não encontrado. Execute: bash tools/termux_setup.sh"
  exit 2
fi
export PYTHONPATH="$PWD/src:$PWD${PYTHONPATH:+:$PYTHONPATH}"
python tools/smr_validate_all.py
